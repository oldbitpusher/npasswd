
/*  --------------------------------------------------------------------  */
/*                                                                        */
/*                        Author: Tomasz Surmacz                          */
/*                   Institute of Technical Cybernetics                   */
/*                    Technical University of Wroclaw                     */
/*                                 Poland                                 */
/*                         tsurmacz@ict.pwr.wroc.pl                       */
/*                                                                        */
/* This code may be distributed freely, provided this notice is retained. */
/*                                                                        */
/*  --------------------------------------------------------------------  */

/*
 *	pw_cracklib - Wrapper for password history checking function
 *
 *	Returns:
 *		PWCK_INDICT if password exists in the history file
 *		PWCK_OK if otherwise
 */

#ifndef lint
static char sccsid[] = "@(#)pwck_history.c	1.0 12/11/93 (asic.ict.pwr.wroc.pl)";
#endif

#include "checkpasswd.h"

pwck_history(password, userid, mesg)
char	*password;	/* Password to check */
int	userid;		/* id of the user */
char	*mesg;		/* Message buffer */
{
	char *FascistHistory();        
	char *reason;
	
#ifdef	DEBUG
		printf("pwck_history: \"%s\"\n", password);
#endif
		
	reason = FascistHistory(password, userid);  /* Tomasz Surmacz's function */
	if(reason==NULL) /* reason is NULL if password good, otherwise explain why not */
		return(PWCK_OK);
	else {
		strncpy(mesg, reason, BUFSIZ-1); /* just to be sure it fits */
		return(PWCK_INDICT);
	}
}

/*	End pwck_history.c */
