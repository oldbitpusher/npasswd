
/* --------------------------------------------------------------------  */
/*                                                                       */
/*                         Author: Szymon Sokol                          */
/*                          Computer   Center                            */
/*                   University of Mining & Metallurgy                   */
/*                          Krakow, Poland                               */
/*                        szymon@uci.agh.edu.pl                          */
/*                                                                       */
/*This code may be distributed freely, provided this notice is retained. */
/*                                                                       */
/* --------------------------------------------------------------------  */
/*
 *	pw_cracklib - Wrapper for Alec Muffett's Cracklib library.
 *
 *	Returns:
 *		PWCK_CRACKABLE if password can be cracked
 *		PWCK_OK if otherwise
 */
#ifndef lint
static char sccsid[] = "@(#)pwck_cracklib.c	1.0 25/06/93 (uci.agh.edu.pl)";
#endif

#include "checkpasswd.h"



pwck_cracklib(password, userid, mesg)
char	*password;	/* Password to check */
int	userid;		/* NOTUSED */
char	*mesg;		/* Message buffer */
{
char *FascistCheck();        
char *reason;

reason = FascistCheck( password, CRACKLIB_DICTPATH ); /* Alec Muffett's function */
if(reason==NULL) /* reason is NULL if password good, otherwise explain why not */
	return(PWCK_OK);
else
{
	strncpy(mesg, reason, BUFSIZ-1); /* just to be sure it fits */
	return(PWCK_CRACKABLE);
}
}
/*	End pwck_cracklib.c */
