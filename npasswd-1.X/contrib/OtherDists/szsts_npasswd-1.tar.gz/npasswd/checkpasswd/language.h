#ifdef POLISH

#define MSG_PWCK_OK	"To haslo jest w porzadku."
#define MSG_PWCK_NULL	"Puste haslo"
#define MSG_PWCK_OBVIOUS	"To haslo jest zbyt latwe do zgadniecia"
#define MSG_PWCK_FINGER	"To haslo jest czescia informacji o tobie dostepnych przez 'finger'."
#define MSG_PWCK_INDICT	"To haslo wystepuje w slowniku"
#define MSG_PWCK_ILLCHAR	"To haslo ma w sobie niedozwolone znaki"
#define MSG_PWCK_SHORT	"To haslo jest zbyt krotkie"

#define PASS_TO_CHECK	"Haslo do sprawdzenia: "

#define MSG_DICTFOUND	"Haslo znalezione w slowniku: '%s'"
#define MSG_TOOLONGWARN	"UWAGA: Tylko %d pierwszych znakow bedzie uzyte\n"
#define MSG_TOOLONGERR 	"Zle haslo. Pierwsze %d znakow nie spelnia warunku:\n"
#define MSG_REPEATED	"To haslo zawiera %d lub wiecej powtorzone znaki"
#define MSG_NONPRINTING	"To haslo zawiera niedrukowalne znaki"
#define MSG_ILLCHAR	"Niedozwolony znak '%s' w tym hasle"
#define MSG_LOWERCASE	"Haslo nie moze skladac sie z samych malych liter"
#define MSG_UPPERCASE	"Haslo nie moze skladac sie z samych wielkich liter"

#define MSG_PASSWDINFO	"Haslo jest czescia informacji o tobie"

#else

#define MSG_PWCK_OK	"This password is ok for use"
#define MSG_PWCK_NULL	"Empty password"
#define MSG_PWCK_OBVIOUS	"This password is too easy to guess"
#define MSG_PWCK_FINGER	"This password is part of your 'finger' information"
#define MSG_PWCK_INDICT	"This password was found in a dictionary"
#define MSG_PWCK_ILLCHAR	"This password has an illegal character in it"
#define MSG_PWCK_SHORT	"This password is too short"

#define PASS_TO_CHECK	"Password to check: "

#define MSG_DICTFOUND	"Password found in dictionary '%s'"
#define MSG_TOOLONGWARN	"WARNING: Only the first %d characters of this password will be used \n"
#define MSG_TOOLONGERR 	"ERROR: The first %d characters cannot be used as password:\n"
#define MSG_REPEATED	"This password has %d or more repeated characters"
#define MSG_NONPRINTING	"This password has non-printing characters"
#define MSG_ILLCHAR	"Illegal character '%s' in this password"
#define MSG_LOWERCASE	"Lower-case only passwords not allowed"
#define MSG_UPPERCASE	"Upper-case only passwords not allowed"

#define MSG_PASSWDINFO	"Password is part of your passwd information"

#endif
