/* language.h
 *
 * This file contains translations for npasswd messages given to users.
 * If you want to put translations for your language, copy the last section
 * (from '#else' to '#endif') just after  'PUT OTHER LANGUAGES HERE' and enclose
 * it in:
 * 	#else
 *	#ifdef YOURLANGUAGE
 * 	 ...
 * 	#endif
 */

#ifdef POLISH

#define MSG_PERMDENIED	"Permission denied.\n"
#define MSG_PASSCHANGED	"Zmienione haslo uzytkownika %s\n"
#define MSG_EOFREADNEW	"EOF przy czytaniu nowego hasla. Haslo bez zmian\n"
#define MSG_EOFREADOLD	"EOF przy czytaniu hasla. Haslo bez zmian\n"
#define MSG_TOOMANYATT	"Zbyt wiele prob.\n"
#define MSG_PASSNOMATCH	"Nie zgadza sie, sprobuj jeszcze raz.\n"
#define MSG_NOHELPFILE	"Nie moge znalezc pliku z podpowiedziami"
#define MSG_CURRPASSWD	"Aktualne haslo: "
#define MSG_PASSWDINCORRECT	"Zle haslo.\n"
#define MSG_PASSWDNOTMATCH	"Haslo sie nie zgadza.\n"
#define MSG_NEWPASSPROMPT	"Nowe haslo (? -> podpowiedz): "
#define MSG_NEWPASSPROMPT_SZS	"Nowe haslo (<Enter> = podpowiedz): "
#define MSG_GETNEWAGAIN	"Nowe haslo (ponownie): "
#define MSG_MUSTBEDIFFERENT	"Nowe haslo nie moze byc takie jak stare; sprobuj jeszcze raz.\n"
#define MSG_NOUSERINFO	"Nie moge znalezc Twojego hasla.\n"
#define MSG_NOLOGINNAME	"Nie moge znalezc Twojego \'loginname\'.\n"
#define MSG_NOSUCHUSER	"Nie ma takiego uzytkownika: %s\n"
#define MSG_CHGPASSFOR	"Zmieniam haslo dla %s\n"
#define MSG_INTERRUPTED	"\nPrzerwane; Zmiany odrzucone.\n"
#define MSG_ILLPASSENT	"Uszkodzona linia w pliku passwd: \"%s\".\n"

/* PUT OTHER LANGUAGES HERE */

#else

#define MSG_PERMDENIED	"Permission denied.\n"
#define MSG_PASSCHANGED	"Password changed for %s\n"
#define MSG_EOFREADNEW	"EOF during new password read.\n"
#define MSG_EOFREADOLD	"EOF during password read.\n"
#define MSG_TOOMANYATT	"Too many attempts.\n"
#define MSG_PASSNOMATCH	"They don't match; try again.\n"
#define MSG_NOHELPFILE	"Missing help file"
#define MSG_CURRPASSWD	"Current password: "
#define MSG_PASSWDINCORRECT	"Password incorrect.\n"
#define MSG_PASSWDNOTMATCH	"Password not matched.\n"
#define MSG_NEWPASSPROMPT	"New password (? for help): "
#define MSG_NEWPASSPROMPT_SZS	"New password (<Enter> for help): "
#define MSG_GETNEWAGAIN	"New password (again): "
#define MSG_MUSTBEDIFFERENT	"New password must be different than old; try again.\n"
#define MSG_NOUSERINFO	"Cannot get your password information.\n"
#define MSG_NOLOGINNAME	"Cannot get your login name.\n"
#define MSG_NOSUCHUSER	"No such user %s\n"
#define MSG_CHGPASSFOR	"Changing password for %s\n"
#define MSG_INTERRUPTED	"\nInterrupted; changes discarded.\n"
#define MSG_ILLPASSENT	"Ill-formed passwd entry \"%s\".\n"

#endif
