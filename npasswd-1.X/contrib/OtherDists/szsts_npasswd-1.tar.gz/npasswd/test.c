#include <stdio.h>
#include <netdb.h>
#ifndef MAXHOSTNAMLEN
#define MAXHOSTNAMLEN 32
#endif
 
#define NONE    -1      /* YP not active */
#define NOT     0       /* YP active - we are not master */
#define IS      1       /* YP active - we have the password file */
 

is_yp_master()
{
        static char     known = 0,      /* We've been here */
                        answer = NOT;   /* ...and this is the answer */
        char    hostname[MAXHOSTNAMLEN];        /* Our host name */
        char    *index();
        struct hostent  *hinfo;
 
        if (known)
                return(answer);
        (void) gethostname(hostname, sizeof(hostname));
        if (yp_get_default_domain(&ypdomain)) {
/*              quit(1, "Cannot get YP domain.\n"); */
                known++;
                return(answer = NONE);          /* Assume no YP running
*/
        }
        if (yp_master(ypdomain, PASSWD_MAP, &ypmaster)) {
                known++;
                return(answer = NONE);          /* Assume no YP running
*/
        }
 
        known++;
#ifdef  FASTCHECK
        /*
         * Stupid (but fast) hostname check (first component only)
         */
        {
                char    *p;                     /* Scratch */
 
                if (p = index(ypmaster, '.')) *p = 0;
                if (p = index(hostname, '.')) *p = 0;
        }
#else
        /*
         * Compare my host name and the YP master's host name.
         * Use gethostbyname() to return the fully qualified form so that
         * a string compare can be done.
         */
        if (index(hostname, '.') == 0) {
                if ((hinfo = gethostbyname(hostname)) == 0)
                        quit(1, "Cannot get hostinfo for self.\n");
                (void) strcpy(hostname, hinfo->h_name);
        }
        if (index(ypmaster, '.') == 0) {
                static char     ypmaster_f[MAXHOSTNAMLEN];
 
                if ((hinfo = gethostbyname(ypmaster)) == 0)
                        quit(1, "Cannot get hostinfo for ypmaster.\n");
                (void) strcpy(ypmaster_f, hinfo->h_name);
                ypmaster = ypmaster_f;
        }
#endif
        if (strcmp(ypmaster, hostname) == 0)
                return(answer = IS);
        return(answer);
}

main()
{
  printf ("%d\n",is_yp_master());
}

