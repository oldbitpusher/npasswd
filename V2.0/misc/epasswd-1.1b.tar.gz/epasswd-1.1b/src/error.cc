
/******************************

  ERROR.CC
  Written by: Eric Allen Davis
              Numerical Aerospace Simulation Facility
              NASA Ames Research Center
*/


#include <iostream.h>
#include "error.h"

/*
CONSTRUCTOR
*/
Pwd_Error::Pwd_Error(int cl)
{
    crypt_length = cl;
}


/*
PW_ERR
  This function takes an error code (as listed above) and prints
  out the appropriate error message before calling exit().
*/
void Pwd_Error::pw_err(int error)
{
    switch(error) {
    case ERR_PASS_LOCK:
        cout << "ERROR: Could not lock the /etc/passwd file." << endl;
        exit(ERR_PASS_LOCK);
        break;
    case ERR_PASS_UNLOCK:
        cout << "ERROR: Could not unlock the /etc/passwd file." << endl;
        exit(ERR_PASS_UNLOCK);
        break;
    case ERR_PASS_OPEN:
        cout << "ERROR: Could not open the /etc/passwd file." << endl;
	exit(ERR_PASS_OPEN);
        break;
    case ERR_REST_OPEN:
        cout << "ERROR: Could not open the /etc/pwrestrict file." << endl;
	exit(ERR_REST_OPEN);
        break;
    case ERR_SHAD_OPEN:
        cout << "ERROR: Could not open the /etc/shadow file." << endl;
	exit(ERR_SHAD_OPEN);
        break;
    case ERR_ADJ_OPEN:
        cout << "ERROR: Could not open the /etc/security/passwd.adjunct file."
             << endl;
        exit(ERR_ADJ_OPEN);
        break;
    case ERR_T_PASS_OPEN:
	cout << "ERROR: Could not open the /etc/ptmp file." << endl;
	exit(ERR_T_PASS_OPEN);
        break;
    case ERR_T_REST_OPEN:
	cout << "ERROR: Could not open the /etc/rtmp file." << endl;
	exit(ERR_T_REST_OPEN);
        break;
    case ERR_T_SHAD_OPEN:
	cout << "ERROR: Could not open the /etc/stmp file." << endl;
	exit(ERR_T_SHAD_OPEN);
        break;
    case ERR_T_ADJ_OPEN:
        cout << "ERROR: Could not open the /etc/security/patmp file." << endl;
        exit(ERR_T_ADJ_OPEN);
        break;
    case ERR_CHOWN_T_PASS:
        cout << "ERROR: Could not chown the /etc/ptmp file." << endl;
	exit(ERR_CHOWN_T_PASS);
        break;
    case ERR_CHOWN_T_REST:
	cout << "ERROR: Could not chown the /etc/rtmp file." << endl;
	exit(ERR_CHOWN_T_REST);
        break;
    case ERR_CHOWN_T_SHAD:
	cout << "ERROR: Could not chown the /etc/stmp file." << endl;
	exit(ERR_CHOWN_T_SHAD);
        break;
    case ERR_CHOWN_T_ADJ:
        cout << "ERROR: Could not chown the /etc/security/patmp file." << endl;
        exit(ERR_CHOWN_T_ADJ);
        break;
    case ERR_PASS_CLOSE:
	cout << "ERROR: Could not close the /etc/passwd file." << endl;
	exit(ERR_PASS_CLOSE);
        break;
    case ERR_REST_CLOSE:
	cout << "ERROR: Could not close the /etc/pwrestrict file." << endl;
	exit(ERR_REST_CLOSE);
        break;
    case ERR_SHAD_CLOSE:
	cout << "ERROR: Could not close the /etc/shadow file." << endl;
	exit(ERR_SHAD_CLOSE);
        break;
    case ERR_ADJ_CLOSE:
        cout << "ERROR: Could not close the /etc/security/passwd.adjunct file."
             << endl;
        exit(ERR_ADJ_CLOSE);
        break;
    case ERR_T_PASS_CLOSE:
	cout << "ERROR: Could not close the /etc/ptmp file." << endl;
	exit(ERR_T_PASS_CLOSE);
        break;
    case ERR_T_REST_CLOSE:
	cout << "ERROR: Could not close the /etc/rtmp file." << endl;
	exit(ERR_T_REST_CLOSE);
        break;
    case ERR_T_SHAD_CLOSE:
	cout << "ERROR: Could not close the /etc/stmp file." << endl;
	exit(ERR_T_SHAD_CLOSE);
        break;
    case ERR_T_ADJ_CLOSE:
        cout << "ERROR: Could not close the /etc/security/patmp file." << endl;
        exit(ERR_T_ADJ_CLOSE);
        break;
    case ERR_DEL_PASS:
	cout << "ERROR: Could not delete the old /etc/passwd file." << endl;
	cout << "** The passwd file could be corrupted." << endl;
	exit(ERR_DEL_PASS);
        break;
    case ERR_DEL_REST:
	cout << "ERROR: Could not delete the old /etc/pwrestrict file." << endl;
	cout << "** The pwrestrict file could be corrupted." << endl;
	exit(ERR_DEL_REST);
        break;
    case ERR_DEL_SHAD:
	cout << "ERROR: Could not delete the old /etc/shadow file." << endl; 
	cout << "** The shadow file could be corrupted." << endl;
	exit(ERR_DEL_SHAD);
        break;
    case ERR_DEL_ADJ:
        cout << "ERROR: Could not delete the old /etc/security/passwd.adjunct file."
             << endl;
        cout << "** The passwd.adjunct file could be corrupted." << endl;
        exit(ERR_DEL_ADJ);
        break;
    case ERR_CRE_PASS:
	cout << "ERROR: Could not create the new /etc/passwd file." << endl;
	cout << "** The passwd file could be corrupted." << endl;
	exit(ERR_CRE_PASS);
        break;
    case ERR_CRE_REST:
	cout << "ERROR: Could not create the new /etc/pwrestrict file." << endl;
	cout << "** The pwrestrict file could be corrupted." << endl;
	exit(ERR_CRE_REST);
        break;
    case ERR_CRE_SHAD:
	cout << "ERROR: Could not create the new /etc/shadow file." << endl;
	cout << "** The shadow file could be corrupted." << endl;
	exit(ERR_CRE_SHAD);
        break;
    case ERR_CRE_ADJ:
        cout << "ERROR: Could not create the new /etc/security/passwd.adjunct file."
             << endl;
        cout << "** The passwd.adjunct file could be corrupted." << endl;
        exit(ERR_CRE_ADJ);
        break;
    case ERR_DEL_T_PASS:
	cout << "ERROR: Could not delete the /etc/ptmp file." << endl;
	cout << "** The passwd file could be corrupted." << endl;
	exit(ERR_DEL_T_PASS);
        break;
    case ERR_DEL_T_REST:
	cout << "ERROR: Could not delete the /etc/rtmp file." << endl;
	cout << "** The pwrestrict file could be corrupted." << endl;
	exit(ERR_DEL_T_REST);
        break;
    case ERR_DEL_T_SHAD:
	cout << "ERROR: Could not delete the /etc/stmp file." << endl;
	cout << "** The shadow file could be corrupted." << endl;
	exit(ERR_DEL_T_SHAD);
        break;
    case ERR_DEL_T_ADJ:
        cout << "ERROR: Could not delete the /etc/security/patmp file." << endl;
        cout << "** The passwd.adjunct file could be corrupted." << endl;
        exit(ERR_DEL_T_ADJ);
        break;
    case ERR_O_PASS_CRE:
	cout << "ERROR: Could not create the new /etc/opasswd file." << endl;
	exit(ERR_O_PASS_CRE);
        break;
    case ERR_O_REST_CRE:
	cout << "ERROR: Could not create the new /etc/orestrict file." << endl;
	exit(ERR_O_REST_CRE);
        break;
    case ERR_O_SHAD_CRE:
	cout << "ERROR: Could not create the new /etc/oshadow file." << endl;
	exit(ERR_O_SHAD_CRE);
        break;
    case ERR_O_ADJ_CRE:
        cout << "ERROR: Could not create the new /etc/security/opasswd.adjunct file."
             << endl;
        exit(ERR_O_ADJ_CRE);
        break;
    case ERR_ROOT_ONLY:
        cout << "ERROR: Only root can change the password." << endl;
	exit(ERR_ROOT_ONLY);
	break;
    case ERR_CRYPT_LENGTH:
        // cout << "ERROR: The encrypted password must be " << CRYPT_LENGTH 
        cout << "ERROR: The encrypted password must be " << 13
	     << " characters." << endl;
        exit(ERR_CRYPT_LENGTH);
        break;
    case ERR_CRYPT_CHAR:
	cout << "ERROR: The encrypted password must only contain" << endl
	     << "       characters from [./a-zA-Z0-9]." << endl;
	exit(ERR_CRYPT_CHAR);
        break;
    case ERR_MAX_DAYS:
        cout << "ERROR: The number of max days is invalid." << endl;
	exit(ERR_MAX_DAYS);
        break;
    case ERR_MIN_DAYS:
	cout << "ERROR: The number of min days cannot be less than 0." << endl;
	exit(ERR_MIN_DAYS);
        break;
    case ERR_WARN_DAYS_LOW:
        cout << "ERROR: The number of warn days cannot be less than 0." << endl;
        exit(ERR_WARN_DAYS_LOW);
        break;
    case ERR_WARN_DAYS_HIGH:
        cout << "ERROR: The number of warn days must be less than max." << endl;
        exit(ERR_WARN_DAYS_HIGH);
        break;
    case ERR_CUR_WARN_DAYS:
        cout << "ERROR: The current value of warn days is not less than max."
             << endl;
        exit(ERR_CUR_WARN_DAYS);
        break;
    case ERR_INACT_DAYS:
        cout << "ERROR: The number of inactive days is invalid." << endl;
        exit(ERR_INACT_DAYS);
        break;
    case ERR_EXPIRE_DAYS:
        cout << "ERROR: The expiration date is invalid." << endl;
        exit(ERR_EXPIRE_DAYS);
        break;
    case ERR_AGE:
        exit(ERR_AGE);
	break;
    case ERR_ROOT:
        cout << "ERROR: Permission denied." << endl;
	exit(ERR_ROOT);
	break;
    case ERR_EXEC_PASSWD:
        cout << "ERROR: Unable to exec 'mkpasswd' to create the"
	     << "       passwd database." << endl;
	exit(ERR_EXEC_PASSWD);
        break;
    case ERR_EXEC_SHADOW:
        cout << "ERROR: Unable to exec 'mkpasswd' to create the"
	     << "       shadow database." << endl;
	exit(ERR_EXEC_SHADOW);
        break;
    case ERR_EXEC_RESTRICT:
        cout << "ERROR: Unable to exec 'mkpasswd' to create the"
	     << "       pwrestrict database." << endl;
	exit(ERR_EXEC_RESTRICT);
        break;
    case ERR_BAD_DATE:
	cout << "ERROR: Bad date representation in the /etc/pwrestrict file." 
	     << endl;
	exit(ERR_BAD_DATE);
        break;
    case ERR_GET_PASS:
	exit(ERR_GET_PASS);
        break;
    case ERR_GET_REST:
        exit(ERR_GET_REST);
        break;
    case ERR_GET_SHAD:
        exit(ERR_GET_SHAD);
        break;
    case ERR_GET_ADJ:
        exit(ERR_GET_ADJ);
        break;
    case ERR_UNKNOWN: default:
        cout << "ERROR: Unexpected/Unknown error!" << endl;
	exit(ERR_UNKNOWN);
        break;
    }
}
