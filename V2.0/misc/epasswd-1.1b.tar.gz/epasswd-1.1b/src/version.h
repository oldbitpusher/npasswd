
/******************************

VERSION.H
Written by:  Eric Allen Davis
             edavis@nas.nasa.gov
	     Numerical Aerospace Simulation Facility
             NASA Ames Research Center

Revision History:
1.0 - 07/20/97
1.1 - 08/05/97

*/

#ident "*****    EPASSWD v1.1                 "
#ident "*****    Written by: Eric Allen Davis "
const char* VERSION = "v1.1";

