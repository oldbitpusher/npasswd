
/******************************

  PASS_SUNOS.CC
  Written by: Eric Allen Davis
              Numerical Aerospace Simulation Facility
	      NASA Ames Research Center
*/

#include <iostream.h>
#include <fstream.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <strings.h>
#include "pass_sunos.h"
#define null ((void*)0)

/*
COPY_NEW_PWF
  This function rewrites a new passwd file updating the changes
  that were made.  The files in question here are determined
  by PASSWD_FILE, TEMP_PASSWD_FILE.  The PASSWD_FILE is parsed line
  by line.  Each line gets written to the TEMP_PASSWD_FILE.  If the
  current line is the one that needs to be changed then the updates
  are made and the new line is written to TEMP_PASSWD_FILE.
  Then the file handle links are swapped in the following manner:
    A new link named OLD_PASSWD_FILE is pointed to PASSWD_FILE.
    The PASSWD_FILE name/link is deleted.
    A new link named PASSWD_FILE is pointed to TEMP_PASSWD_FILE.
    The TEMP_PASSWD_FILE name/link is deleted.
  That's all folks!
*/
void Pwd::copy_new_pwf(passwd* pw_ent)
{
    // IGNORE ALL SIGNALS - don't want a corrupted passwd file
    ignore_signals1();

    umask(0);                                     // set the umask
    int pwf_fd, temp_pfd;
    // create and lock the TEMP_PASSWD_FILE for writing only
    if ((temp_pfd = open(TEMP_PASSWD_FILE, O_CREAT|O_WRONLY|O_EXCL, PASSWD_MODE)) == -1)
	pw_err(ERR_T_PASS_OPEN);
    // open the PASSWD_FILE for reading only
    if ((pwf_fd = open(PASSWD_FILE, O_RDONLY)) == -1) pw_err(ERR_PASS_OPEN);
    // chown the TEMP_PASSWD_FILE to root.root
    if (fchown(temp_pfd, root_uid, root_gid) == -1) pw_err(ERR_CHOWN_T_PASS);

    ifstream input(pwf_fd);    // new input stream for PASSWD_FILE
    ofstream output(temp_pfd); // new output stream for TEMP_PASSWD_FILE
    char buf[MAX_BUF];         // temp buffer space
    while(input.getline(buf, MAX_BUF)) {   // read each line until EOF
	char* temp = buf;
	while (*temp != ':') temp++;       // parse out the login name
	*temp = '\0';                   
	if (strcmp(pw_ent->pw_name, buf) == 0) {  // if this line is it
	    output << pw_ent->pw_name << ":"      // then write new info
                   << pw_ent->pw_passwd;
            if (*pw_ent->pw_age != '\0') output << "," << pw_ent->pw_age;
	    output << ":" << pw_ent->pw_uid << ":"
                   << pw_ent->pw_gid << ":"
                   << pw_ent->pw_gecos << ":"
                   << pw_ent->pw_dir << ":"
                   << pw_ent->pw_shell << endl;
	}
	else {                                    // else keep original stuff
	    *temp = ':';
            output << buf << endl;
        }
    }

    // close the PASSWD_FILE
    if(close(pwf_fd) == -1) pw_err(ERR_PASS_CLOSE);
    // close and delete the TEMP_PASSWD_FILE
    if(close(temp_pfd) == -1) pw_err(ERR_T_PASS_CLOSE);
    // create a name OLD_PASSWD_FILE to PASSWD_FILE
    unlink(OLD_PASSWD_FILE);                // delete if exists
    if (link(PASSWD_FILE, OLD_PASSWD_FILE) == -1) pw_err(ERR_O_PASS_CRE);
    // deleted the name/link PASSWD_FILE
    if (unlink(PASSWD_FILE) == -1) pw_err(ERR_DEL_PASS);
    // create a new link to TEMP_PASSWD_FILE named PASSWD_FILE
    if (link(TEMP_PASSWD_FILE, PASSWD_FILE) == -1) pw_err(ERR_CRE_PASS);
    // delete the name/link TEMP_PASSWD_FILE
    if (unlink(TEMP_PASSWD_FILE) == -1) pw_err(ERR_DEL_T_PASS);
}


/*
COPY_NEW_PAF
  This function rewrites a new shadow file updating the changes
  that were made.  The files in question here are determined
  by ADJUNCT_FILE, TEMP_ADJUNCT_FILE.  The ADJUNCT_FILE is parsed line
  by line.  Each line gets written to the TEMP_ADJUNCT_FILE.  If the
  current line is the one that needs to be changed then the updates
  are made and the new line is written to TEMP_ADJUNCT_FILE.
  Then the file handle links are swapped in the following manner:
    A new link named TEMP_ADJUNCT_FILE is pointed to ADJUNCT_FILE.
    The ADJUNCT_FILE name/link is deleted.
    A new link named ADJUNCT_FILE is pointed to TEMP_ADJUNCT_FILE.
    The TEMP_ADJUNCT_FILE name/link is deleted.
  That's all folks!
*/
void Pwd::copy_new_paf(passwd_adjunct* pa_ent)
{
    // IGNORE ALL SIGNALS - don't want a corrupted passwd file
    ignore_signals1();

    umask(0);                                       // set the umask
    int paf_fd, temp_pfd, temp_afd;
    // create and lock the TEMP_PASSWD_FILE
    if ((temp_pfd = open(TEMP_PASSWD_FILE, O_CREAT|O_WRONLY|O_EXCL, ADJUNCT_MODE)) == -1)
        pw_err(ERR_T_PASS_OPEN);
    // open the ADJUNCT_FILE for reading only
    if ((paf_fd = open(ADJUNCT_FILE, O_RDONLY)) == -1) pw_err(ERR_ADJ_OPEN);
    // create the TEMP_ADJUNCT_FILE file for writing only
    if ((temp_afd = open(TEMP_ADJUNCT_FILE, O_CREAT|O_WRONLY|O_EXCL, ADJUNCT_MODE)) == -1)
        pw_err(ERR_T_ADJ_OPEN);
    // chown the TEMP_ADJUNCT_FILE and OLD_ADJUNCT_FILE to root.root
    if (fchown(temp_afd, root_uid, root_gid) == -1) pw_err(ERR_CHOWN_T_ADJ);

    ifstream input(paf_fd);      // new input stream for ADJUNCT_FILE
    ofstream output(temp_afd);   // new output stream for TEMP_ADJUNCT_FILE
    char buf[MAX_BUF];           // temp buffer space
    while(input.getline(buf, MAX_BUF)) {   // read each line until EOF
	char* temp = buf;
	while (*temp != ':') temp++;       // parse out the login name
	*temp = '\0';
	if (strcmp(pa_ent->pwa_name, buf) == 0) {   // if this line is it
	    /*
	    output << pa_ent->pwa_name << ":"
		   << pa_ent->pwa_passwd << ":"
		   << pa_ent->pwa_minimum << ":"
		   << pa_ent->pwa_maximum << ":"
		   << pa_ent->pwa_def << ":"
		   << pa_ent->pwa_au_always << ":"
		   << pa_ent->pwa_au_never << ":"
		   << pa_ent->pwa_version << endl;
            */
	    output << endl;
	}
	else {                                // else keep original stuff
	    *temp = ':';
            output << buf << endl;
        }
    }

    // close the ADJUNCT_FILE
    if(close(paf_fd) == -1) pw_err(ERR_ADJ_CLOSE);
    // close the TEMP_ADJUNCT_FILE
    if(close(temp_afd) == -1) pw_err(ERR_T_ADJ_CLOSE);
    // create a named OLD_ADJUNCT_FILE to ADJUNCT_FILE
    unlink(OLD_ADJUNCT_FILE);                // delete if exists
    if (link(ADJUNCT_FILE, OLD_ADJUNCT_FILE) == -1) pw_err(ERR_O_ADJ_CRE);
    // deleted the name/link ADJUNCT_FILE
    if (unlink(ADJUNCT_FILE) == -1) pw_err(ERR_DEL_ADJ);
    // create a new link to TEMP_ADJUNCT_FILE named ADJUNCT_FILE
    if (link(TEMP_ADJUNCT_FILE, ADJUNCT_FILE) == -1) pw_err(ERR_CRE_ADJ);
    // delete the name/link TEMP_ADJUNCT_FILE
    if (unlink(TEMP_ADJUNCT_FILE) == -1) pw_err(ERR_DEL_T_ADJ);
    // close and delete the TEMP_PASSWD_FILE
    if (close(temp_pfd) == -1) pw_err(ERR_T_PASS_CLOSE);
    if (unlink(TEMP_PASSWD_FILE) == -1) pw_err(ERR_DEL_T_PASS);
}


/*
PRINT_USER_INFO
  This function prints out the passwd entry info specified
  in the argument pw_ent.
*/
void Pwd::print_user_info(passwd* pw_ent)
{
    cout.flags(ios::left);
    cout.width(12); cout << pw_ent->pw_name;
    cout.width(5);
    if (adjunct_exists()) {
        passwd_adjunct* pa_ent = getpwanam(pw_ent->pw_name);
        if (pa_ent == null) {
	    cout.width(0);
            cout << "ERROR: Could not retrieve shadow entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_ADJ);
        }
        if (*pa_ent->pwa_passwd == '\0') cout << "NP";
        else if ((strcmp(pa_ent->pwa_passwd, LOCK_STRING1) == 0) ||
                 (strcmp(pa_ent->pwa_passwd, LOCK_STRING2) == 0)) cout << "LK";
        else cout << "PS";
    }
    else {
        if (*pw_ent->pw_passwd == '\0') cout << "NP";
        else if ((strcmp(pw_ent->pw_passwd, LOCK_STRING1) == 0) ||
                 (strcmp(pw_ent->pw_passwd, LOCK_STRING2) == 0)) cout << "LK";
        else cout << "PS";
    }
    cout.width(10); cout << pw_ent->pw_uid;
    cout.width(10); cout << pw_ent->pw_gid;
    cout.width(20); cout << pw_ent->pw_dir;
    cout.width(0); cout << pw_ent->pw_shell << endl;
}


/*
CONSTRUCTOR
  This is a constructor for class Pwd.
*/
Pwd::Pwd() : Pwd_Common()
{
}


/*
CONSTRUCTOR
  This is a constructor for class Pwd.
*/
Pwd::Pwd(char* name, char* crypt) : Pwd_Common(name, crypt)
{
}


/*
DESTRUCTOR
  This is the destructor for class Pwd.
*/
Pwd::~Pwd()
{
}


/*
ADJUNCT_EXISTS
  This function returns 1 if shadow passwds are being used and
  0 otherwise.
*/
int Pwd::adjunct_exists()
{
    struct stat stat_buf;
    if (stat(ADJUNCT_FILE, &stat_buf) == 0) return 1;
    else return 0;
}


/*
CHANGE_PASSWORD
  This function does all the dirty work in changing a password.
*/
void Pwd::change_password(uid_t user_uid, uid_t change_uid, int security_hole)
{
    passwd* pw_ent = getpwuid(change_uid);  // get user entry
    if (pw_ent == null) {
        cout << "ERROR: Could not retrieve password entry for UID '"
             << change_uid << "'." << endl;
        pw_err(ERR_GET_PASS);
    }
    cout << "Changing password for " << pw_ent->pw_name << endl;
    if (adjunct_exists()) {   // if using shadow passwords
        passwd_adjunct* pa_ent = getpwanam(pw_ent->pw_name); // get user entry
        if (pa_ent == null) {
            cout << "ERROR: Could not retrieve shadow entry for '"
	         << pw_ent->pw_name << "'." << endl;
            pw_err(ERR_GET_ADJ);
        }
	// get the new password from the user
        char* new_crypt_password = get_new_password(pa_ent->pwa_passwd, pa_ent->pwa_name, user_uid, security_hole);
        if (new_crypt_password != null) { // Password successfully changed!
            bzero(pa_ent->pwa_passwd, strlen(pa_ent->pwa_passwd)); //wipe memory
            pa_ent->pwa_passwd = new_crypt_password;         // set new passwd
            copy_new_paf(pa_ent);             // rewrite new shadow file
        }
        else {
	    // The moron could not enter in a decent password or their own!
            cout << "Password not changed, try again later." << endl;
	    exit(ERR_UNCHANGED);
        }
    }
    else {  // not using shadow passwds
	// get the new password from the user
        char* new_crypt_password = get_new_password(pw_ent->pw_passwd, pw_ent->pw_name, user_uid, security_hole);
        if (new_crypt_password != null) { // Password successfully changed!
            bzero(pw_ent->pw_passwd, strlen(pw_ent->pw_passwd)); // wipe out
            pw_ent->pw_passwd = new_crypt_password;    // set new passwd
	    copy_new_pwf(pw_ent);   // rewrite the new passwd file
        }
        else {
	    // The moron could not enter in a decent password or their own!
            cout << "Password not changed, try again later." << endl;
	    exit(ERR_UNCHANGED);
        }
    }
}


/*
PRINT_INFO_NAME
  This function prints out the passwd entry information for a user.
  If the argument user_name is null then all user entries are printed.
  else just user_name is printed.
*/
void Pwd::print_info_name(char* user_name)
{
    if (user_name != null) {  // print out user_name only
        passwd* pw_ent = getpwnam(user_name);  // get user entry
        if (pw_ent == null) {
            cout << "ERROR: Could not retrieve password entry for '"
	         << user_name << "'." << endl;
            pw_err(ERR_GET_PASS);
        }
        print_user_info(pw_ent);   // print it out
    }
    else {
        passwd* pw_ent;
	// for each user in the passwd file print the info
        while ((pw_ent = getpwent()) != null) print_user_info(pw_ent);  
    }
}


/*
PRINT_INFO_UID                                                
  This function prints out the passwd entry information for a user.
*/
void Pwd::print_info_uid(uid_t uid)
{                                                             
    passwd* pw_ent = getpwuid(uid);  // get user entry        
    if (pw_ent == null) {                                     
        cout << "ERROR: Could not retrieve password entry for uid '"
             << uid << "'." << endl;                          
        pw_err(ERR_GET_PASS);                                 
    }                                                         
    print_user_info(pw_ent);   // print it out                
}                                                             


/*
LOCK_USER
  This function locks the user out of their account by '*'ing the passwd.
*/
void Pwd::lock_user()
{
    if (adjunct_exists()) {  // if shadow passwords are being used
        passwd_adjunct* pa_ent = getpwanam(login_name);  // get user entry
        if (pa_ent == null) {
            cout << "ERROR: Could not retrieve shadow entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_ADJ);
        }
        bzero(pa_ent->pwa_passwd, strlen(pa_ent->pwa_passwd)); // wipe memory
        pa_ent->pwa_passwd = LOCK_STRING1;                   // lock passwd
        copy_new_paf(pa_ent);                             // rewrite adjunct
    }
    else {    // not using shadow passwords
        passwd* pw_ent = getpwnam(login_name); // get user entry
        if (pw_ent == null) {
            cout << "ERROR: Could not retrieve password entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_PASS);
        }
        bzero(pw_ent->pw_passwd, strlen(pw_ent->pw_passwd)); // wipe out memory
        pw_ent->pw_passwd = LOCK_STRING1;                    // lock passwd
        copy_new_pwf(pw_ent);                                // rewrite passwd
    }
}


/*
CRYPT_USER
  This function inserts a new encrypted password for the user.
*/
void Pwd::crypt_user()
{
    // the length of the encrypted passwd must be valid
    if (!chkcryptlength()) pw_err(ERR_CRYPT_LENGTH);
    // all characters must be valid in the encrypted passwd
    if (!chkcrypt()) pw_err(ERR_CRYPT_CHAR);
    if (adjunct_exists()) {  // if using shadow passwords
        passwd_adjunct* pa_ent = getpwanam(login_name);  // get user entry
        if (pa_ent == null) {
            cout << "ERROR: Could not retrieve shadow entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_ADJ);
        }
        bzero(pa_ent->pwa_passwd, strlen(pa_ent->pwa_passwd)); // wipe memory
        pa_ent->pwa_passwd = crypt_pw;                       // set new passwd
        copy_new_paf(pa_ent);                             // rewrite shadow
    }
    else {   // not using shadow passwords
        passwd* pw_ent = getpwnam(login_name);  // get user entry
        if (pw_ent == null) {
            cout << "ERROR: Could not retrieve password entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_PASS);
        }
        bzero(pw_ent->pw_passwd, strlen(pw_ent->pw_passwd)); // wipe out memory
        pw_ent->pw_passwd = crypt_pw;                        // set new passwd
        copy_new_pwf(pw_ent);                                // rewrite passwd
    }
}

