
/******************************

  PASS_SOLARIS.H
  Written by: Eric Allen Davis
              Numerical Aerospace Simulation Facility
	      NASA Ames Research Center


** PRIVATE MEMBERS:
long max_age -
  The max age of the password. (in days) How long the
  password can be used before expiration.
long min_age -
  The min age of the password. (in days) The min amount
  of time between passowrd changes.
long warn_age -
  The number of days before the password expires in which
  the user is to be warned.
long inact_age -
  The number of days of inactivity allowed for the account.
long expire_age -
  The absolute date (in days since Jan 1 1970) when the
  account expires and can no longer be used.

** PROTECTED MEMBERS:
void copy_new_pwf(passwd* pw_ent) -
  This function takes a password entry structure and rewrites a 
  new passwd file with that specific password entry updated.
void copy_new_shf(spwd* sp_ent) -
  This function takes a shadow entry structure and rewrites a 
  new shadow file with that specific shadow entry updated.
void convert_age_from_string(char* pw_age, time_t& max_weeks,
                             time_t& min_weeks, time_t& last) -
  This function takes a character string and unmashes it
  to the max age, min age, and last changed age.  See man a64l().
void convert_age_to_long(long& age, time_t& max_weeks,
                         time_t& min_weeks, long& now) -
  This function take the current date, max age, and min age and
  smashes them together into the long integer age.
void print_user_info(passwd* pw_ent) -
  This function take a password entry and prints the 
  necessary information to stdout.

** PUBLIC MEMBERS:
Pwd() -
  Constructor for Pwd.
Pwd(char* name, char* crypt, long max, long min, long warn,
    long inact, long expire) -
  Constructor for Pwd.
~Pwd() -
  Destructor for Pwd.
int shadow_exists() -
  This function checks to see if shadow passwords are be used.
void change_password(uid_t uid, uid_t change_uid) -
  This function is the heart of the Pwd class.  It checks
  the age of the original password and forces the user
  to enter in the old password, then has the user enter in
  the new password (twice), then rewrites the passwd or
  shadow file with the new password and updated ages.
void print_info_name(char* user_name) -
  This function prints out the necessary password entry info
  for the user_name argument.  If user_name is null and the
  user is root then all password entries are printed.
void print_info_uid(uid_t uid) -
  This function prints out the necessary password entry info
  for the uid argument.
void force_user() -
  This function zeroes the password age thus forcing the user
  to change their password during their next login session.
void lock_user() -
  This function deletes the user's password and inserts the
  string "*LK*" in the password field thus locking the
  user out of their account.
void crypt_user() -
  This function deletes teh user's password and inserts the
  encrypted password string pointed to by the private member
  crypt_pw.  Checks are also made to ensure that crypt_pw
  is the right length and contains the correct characters.
void set_age(short flags, short x_bit, short n_bit, short w_bit) -
  This function sets the new age fields for the user.
void set_inactive() -
  This function sets the inactive field for the user. (shadow only)
void set_expire() -
  This function sets the expire fielf for the user. (shadow only)
void expire() -
  This function expires the user's account immediately. (shadow only)

*/


#ifndef PWD_CLASS
#define PWD_CLASS

#include <pwd.h>
#include <shadow.h>
#include "passwd.h"

const char* const PASSWD_FILE = "/etc/passwd";
const char* const TEMP_PASSWD_FILE = "/etc/ptmp";
const char* const OLD_PASSWD_FILE = "/etc/opasswd";
const char* const SHADOW_FILE = "/etc/shadow";
const char* const TEMP_SHADOW_FILE = "/etc/stmp";
const char* const OLD_SHADOW_FILE = "/etc/oshadow";
const mode_t PASSWD_MODE = 0444;           // file mode of /etc/passwd
const mode_t SHADOW_MODE = 0400;           // file mode of /etc/shadow
const char* const LOCK_STRING1 = "*LK*";   // locked account
const char* const LOCK_STRING2 = "*";
const char* const FORCE_STRING = "..";        // force change next login
const char* const ROOT_CHANGE_STRING = "./";  // force root only change
const char* const ROOT = "root";              // root login name
const int MAX_BUF = 1000;                  // maximum temp buffer space
const int DAYS_WEEK = 7;                       // number of days in a week
const int MAX_CHAR_WEEK = 63;             // max number of weeks radix 64

class Pwd: public Pwd_Common
{
private:

    long max_age;
    long min_age;
    long warn_age;
    long inact_age;
    long expire_age;

protected:

    void copy_new_pwf(passwd* pw_ent);
    void copy_new_shf(spwd* sp_ent);
    void convert_age_from_string(char* pw_age, time_t& max_weeks,
                                 time_t& min_weeks, time_t& last);
    void convert_age_to_long(long& age, time_t& max_weeks,
                             time_t& min_weeks, long& now);
    void print_user_info(passwd* pw_ent);

public:

    Pwd();
    Pwd(char* name, char* crypt, long max, long min, long warn,
        long inact, long expire);
    ~Pwd();
    int shadow_exists();
    void change_password(uid_t uid, uid_t change_uid, int security_hole);
    void print_info_name(char* user_name);
    void print_info_uid(uid_t uid);
    void force_user();
    void lock_user();
    void crypt_user();
    void set_age(short flags, short x_bit, short n_bit, short w_bit);
    void set_inactive();
    void set_expire();
    void expire();

};

#endif
