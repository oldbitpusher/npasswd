
/******************************

  PASSWD.H
  Written By: Eric Allen Davis
              Numerical Aerospace Simulation Facility
	      NASA Ames Research Center


** PRIVATE MEMBERS:
Test* tests -
  A pointer to an instance of the Test class for testing password
  construction requirements.

** PROTECTED MEMBERS:
char* login_name -
  The login name of the user for which the password is
  going to be changed.
char* crypt_pw -
  The 13 character encrypted password to be installed for
  the login name
uid_t root_uid -
  The uid of the system's super-user.
uid_t root_gid -
  The gid of the system's super-user.
int chkroot(uid_t uid) -
  This function checks if the user executing the application
  is the super-user.
int chkcryptlength() -
  This function checks if the encrypted password in crypt_pw is
  13 characters in length.
int chkcrypt() -
  This function checks if the encrypted password in crypt_pw
  only contains the valid password characters: [./a-zA-Z0-9].
void generate_salt(char salt[SALT_SIZE]) -
  This function generate a random SALT_SIZE character salt.
void ignore_signals1() -
  This function ignores all possible signals to prevent
  corrupted files and core dumps.
void ignore_signals2() -
  This function ignores all possible signals except SIGINT
  to prevent corrupted files and core dumps.
int check_old(char* pw_passwd, char* old_pass) -
  This function makes the user enter in their original password
  to ensure that they are able to change the password.  If
  the user is root then they are not prompted to enter in
  the original password.
char* get_new_password(char* pw_passwd, char* pw_name, uid_t uid) -
  This function gets the new password from the user.  The user is
  prompted twice for the new password to ensure that the password
  was entered correctly.  Then the password is tested for
  the construction requirements.

** PUBLIC MEMBERS:
Pwd_Common() -
  Constructor for Pwd.
Pwd_Common(char* name, char* crypt)
  Constructor for Pwd.
~Pwd_Common() -
  Destructor for Pwd.
uid_t get_uid() -
  This function returns the uid of the user specified in
  the private member login_name.
long get_days() -
  This function returns the number of days since Jan 1 1970.
long get_weeks() -
  This function returns the number of weeks since Jan 1 1970.
void user_root_exit(uid_t uid) -
  This function tests if the user uid is the same as root.
int user_root(uid_t uid) -
  This function tests if the user uid is the same as root.

*/


#ifndef PWD_COMMON_CLASS
#define PWD_COMMON_CLASS

#include <sys/types.h>
#include "error.h"
#include "tests.h"

const int LOGNAME_MAX = 8; // max number of characters in a login name
const int CRYPT_LENGTH = 13; // length of an encrypted passwd
const int MAX_PASSWD_BUF = 9; // getpass collects at most 8 chars + '\0'
const int LAST_PASSWD_CHAR = 8; // last char in a passwd buf
const long SECONDS_WEEK = (7 * 24 * 60 * 60); // number of seconds in a week
const long SECONDS_DAY = (24 * 60 * 60); // number seconds in a day
const int SALT_SIZE = 2; // must be 2 for the crypt system call

class Pwd_Common: public Pwd_Error
{
private:

    Test* tests;

protected:

    char login_name[LOGNAME_MAX+1];
    char crypt_pw[CRYPT_LENGTH+1];
    uid_t root_uid;
    gid_t root_gid;
    int chkroot(uid_t uid);
    int chkcryptlength();
    int chkcrypt();
    void generate_salt(char salt[SALT_SIZE]);
    void ignore_signals1();
    void ignore_signals2();
    int check_old(char* pw_passwd, char* old_pass);
    char* get_new_password(char* pw_passwd, char* pw_name, uid_t uid,
                           int security_hole);

public:

    Pwd_Common();
    Pwd_Common(char* name, char* crypt);
    ~Pwd_Common();
    uid_t get_uid();
    long get_days();
    long get_weeks();
    void user_root_exit(uid_t uid);
    int user_root(uid_t uid);

};

#endif
