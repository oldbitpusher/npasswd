/******************************

  MAIN.CC
  Written by: Eric Allen Davis
              Numerical Aerospace Simulation Facility
	      NASA Ames Research Center


  epasswd uses a bit array to denote the proper command line
  usage across different OS platforms.  The following bit value
  combinations represent the possible arguments for each OS which
  are allowed.  Argument v represents the rightmost bit (see usage).

IRIX:
  possible command line options: p E i e n x w c f l s a h v  = decimal
  acceptable bit masks/values:   0 0 0 0 0 0 0 0 0 0 0 0 0 0  = 0
				 1 0 0 0 0 0 0 0 0 0 0 0 0 0  = 8192
				 0 1 0 0 0 0 0 0 0 0 0 0 0 0  = 4096 
                                 0 0 1 0 0 0 0 0 0 0 0 0 0 0  = 2048
                                 0 0 0 1 0 0 0 0 0 0 0 0 0 0  = 1024
                                 0 0 0 0 0 1 0 0 0 0 0 0 0 0  = 256
                                 0 0 0 0 0 1 1 0 0 0 0 0 0 0  = 384
                                 0 0 0 0 1 1 0 0 0 0 0 0 0 0  = 768
                                 0 0 0 0 1 1 1 0 0 0 0 0 0 0  = 896
                                 0 0 0 0 0 0 0 1 0 0 0 0 0 0  = 64
                                 0 0 0 0 0 0 0 0 1 0 0 0 0 0  = 32
                                 0 0 0 0 0 0 0 0 0 1 0 0 0 0  = 16
                                 0 0 0 0 0 0 0 0 0 0 1 0 0 0  = 8
                                 0 0 0 0 0 0 0 0 0 0 1 1 0 0  = 12
                                 0 0 0 0 0 0 0 0 0 0 0 0 0 1  = 1
                                 0 0 0 0 0 0 0 0 0 0 0 0 1 0  = 2
                                 0 0 0 0 0 0 0 0 0 0 0 0 1 1  = 3

SUNOS:
  possible command line options: p             c   l s a h v  = decimal
  acceptable bit masks/values:   0 x x x x x x 0 x 0 0 0 0 0  = 0
				 1 x x x x x x 0 x 0 0 0 0 0  = 8192
				 x x x x x x x x x x x x x x  = 4096 
                                 x x x x x x x x x x x x x x  = 2048
                                 x x x x x x x x x x x x x x  = 1024
                                 x x x x x x x x x x x x x x  = 256
                                 x x x x x x x x x x x x x x  = 384
                                 x x x x x x x x x x x x x x  = 768
                                 x x x x x x x x x x x x x x  = 896
                                 0 x x x x x x 1 x 0 0 0 0 0  = 64
                                 0 x x x x x x 0 x 0 0 0 0 0  = 32
                                 0 x x x x x x 0 x 1 0 0 0 0  = 16
                                 0 x x x x x x 0 x 0 1 0 0 0  = 8
                                 0 x x x x x x 0 x 0 1 1 0 0  = 12
                                 0 x x x x x x 0 x 0 0 0 0 1  = 1
                                 0 x x x x x x 0 x 0 0 0 1 0  = 2
                                 0 x x x x x x 0 x 0 0 0 1 1  = 3

SOLARIS:
  possible command line options: p E i e n x w c f l s a h v  = decimal
  acceptable bit masks/values:   0 0 0 0 0 0 0 0 0 0 0 0 0 0  = 0
				 1 0 0 0 0 0 0 0 0 0 0 0 0 0  = 8192
				 0 1 0 0 0 0 0 0 0 0 0 0 0 0  = 4096 
                                 0 0 1 0 0 0 0 0 0 0 0 0 0 0  = 2048
                                 0 0 0 1 0 0 0 0 0 0 0 0 0 0  = 1024
                                 0 0 0 0 0 1 0 0 0 0 0 0 0 0  = 256
                                 0 0 0 0 0 1 1 0 0 0 0 0 0 0  = 384
                                 0 0 0 0 1 1 0 0 0 0 0 0 0 0  = 768
                                 0 0 0 0 1 1 1 0 0 0 0 0 0 0  = 896
                                 0 0 0 0 0 0 0 1 0 0 0 0 0 0  = 64
                                 0 0 0 0 0 0 0 0 1 0 0 0 0 0  = 32
                                 0 0 0 0 0 0 0 0 0 1 0 0 0 0  = 16
                                 0 0 0 0 0 0 0 0 0 0 1 0 0 0  = 8
                                 0 0 0 0 0 0 0 0 0 0 1 1 0 0  = 12
                                 0 0 0 0 0 0 0 0 0 0 0 0 0 1  = 1
                                 0 0 0 0 0 0 0 0 0 0 0 0 1 0  = 2
                                 0 0 0 0 0 0 0 0 0 0 0 0 1 1  = 3


CONVEX:
  possible command line options: p       n x   c f l s a h v  = decimal
  acceptable bit masks/values:   0 x x x 0 0 x 0 0 0 0 0 0 0  = 0
				 1 x x x 0 0 x 0 0 0 0 0 0 0  = 8192
				 x x x x x x x x x x x x x x  = 4096
                                 x x x x x x x x x x x x x x  = 2048
                                 x x x x x x x x x x x x x x  = 1024
                                 0 x x x 0 1 x 0 0 0 0 0 0 0  = 256
                                 x x x x x x x x x x x x x x  = 384
                                 0 x x x 1 1 x 0 0 0 0 0 0 0  = 768
                                 x x x x x x x x x x x x x x  = 896
                                 0 x x x 0 0 x 1 0 0 0 0 0 0  = 64
                                 0 x x x 0 0 x 0 1 0 0 0 0 0  = 32
                                 0 x x x 0 0 x 0 0 1 0 0 0 0  = 16
                                 0 x x x 0 0 x 0 0 0 1 0 0 0  = 8
                                 0 x x x 0 0 x 0 0 0 1 1 0 0  = 12
                                 0 x x x 0 0 x 0 0 0 0 0 0 1  = 1
                                 0 x x x 0 0 x 0 0 0 0 0 1 0  = 2
                                 0 x x x 0 0 x 0 0 0 0 0 1 1  = 3


******************************/

#include "version.h"
#include <iostream.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/utsname.h>
#ifdef __irix__
#include "pass_irix.h"
#elif __sunos__
#include "pass_sunos.h"
#elif __solaris__
#include "pass_solaris.h"
#elif __convex__
#include "pass_convex.h"
#endif /* __irix__ */
#define null ((void*)0)

#define SUCCESS 0

extern char* optarg;
extern int optind;

/*
  The following constants define the bits associated for each
  argument flag.  A bitmask array is used for denoting the
  proper command line usage.
*/
#ifdef __MINOR_HOLE__
const short P_BIT = 8192;
#endif
#if defined(__irix__) || defined(__solaris__)
const short E_BIT = 4096;
const short I_BIT = 2048;
const short e_BIT = 1024;
#endif /* __irix__ || __solaris__ */
#ifndef __sunos__
const short N_BIT = 512;
const short X_BIT = 256;
#endif
#if defined(__irix__) || defined(__solaris__)
const short W_BIT = 128;
#endif /* __irix__ || __solaris__ */
const short C_BIT = 64;
#ifndef __sunos__
const short F_BIT = 32;
#endif /* __sunos__ */
const short L_BIT = 16;
const short S_BIT = 8;
const short A_BIT = 4;
const short H_BIT = 2;
const short V_BIT = 1;
const short ZERO = 0;

/*
  The following (ugh) globals are used for storing arguments
  off the command line.
*/
#ifndef __sunos__
long PW_MAX = 0;          // MAX age for the password
long PW_MIN = 0;          // MIN age for the password
#if defined(__irix__) || defined(__solaris__)
long PW_WARN = 0;         // WARN age for the password
long PW_INACT = 0;        // number of inactive days allowed
long PW_EXPIRE = 0;       // absolute date when account expires
#endif /* __irix__ || __solaris__ */
#endif /* __sunos__ */
char PW_CRYPT[CRYPT_LENGTH+1] = "";  // crypted password from command line
char LOGIN_NAME[LOGNAME_MAX+1] = ""; // login name of password entry to change

/*
PRINT_USAGE
  This function prints the usage of the passwd application
  to stdout.
*/
void print_usage()
{
    cout << "Usage:" << endl
         << "       passwd [ name ]" << endl
#ifdef __MINOR_HOLE__
         << "       passwd -p [ name ]" << endl
#endif
#if defined(__irix__) || defined(__solaris__)
	 << "       passwd -x max [ -n min ] [ -w warn ] name" << endl
#elif __convex__
	 << "       passwd -x max [ -n min ] name" << endl
#endif /* __irix__ || __solaris__ */
	 << "       passwd -c crypt name" << endl
#ifdef __sunos__
	 << "       passwd -l name" << endl
#else
	 << "       passwd [ -f | -l ] name" << endl
#endif /* __sunos__ */
#if defined(__irix__) || defined(__solaris__)
	 << "       passwd -i inactive name" << endl
	 << "       passwd -e expire name" << endl
	 << "       passwd -E name" << endl
#endif /* __irix__ || __solaris__ */
	 << "       passwd -s [ -a | name ]" << endl
	 << "       passwd [ -h ] [ -v ]" << endl;
}


/*
  This following constants are used as exit error codes.
*/
const int ERR_GETOPT = 2;
const int ERR_USAGE = 3;
const int ERR_LOGIN = 4;
const int ERR_SHADOW = 5;
const int ERR_COMBO = 6;
const int ERR_UNAME = 7;
// ERR_UNKNOWN is defined in error.h
// const int ERR_UNKNOWN = 100;

/*
ERR_QUIT
  This function takes an error exit code, prints the
  appropriate error message and exits.
*/
void err_quit(int error)
{
    switch(error) {
    case ERR_GETOPT:
	print_usage();
        exit(ERR_GETOPT);
	break;
    case ERR_USAGE:
	cout << "ERROR: Incorrect usage -" << endl;
	print_usage();
        exit(ERR_USAGE);
        break;
    case ERR_LOGIN:
	cout << "ERROR: Must specify a login name." << endl;
	print_usage();
        exit(ERR_LOGIN);
        break;
    case ERR_SHADOW:
	cout << "ERROR: Shadow passwords are not being utilized." << endl;
        exit(ERR_SHADOW);
        break;
    case ERR_COMBO:
	cout << "ERROR: Invalid combination of options -" << endl;
	print_usage();
        exit(ERR_COMBO);
        break;
    case ERR_UNAME:
        cout << "ERROR: Could not figure out the machine's uname." << endl;
        exit(ERR_UNAME);
        break;
    default:
	cout << "ERROR: Unexpected/Unknown error!" << endl;
        exit(ERR_UNKNOWN);
        break;
    }
}


/*
PRINT_VERBOSE
  This following function prints out useful system information
  that is used by the passwd application.  This information
  contains the following:
    - passwd version
    - uname
    - if shadow passwords are being used
    - number of days/weeks from Jan 1 1970
*/
void print_verbose(int shadow, int days, int weeks)
{
    struct utsname u;
    if (uname(&u) == -1) err_quit(ERR_UNAME);
    cout << "  passwd version: " << VERSION << endl;
    cout << "  uname: " << u.sysname << " " << u.nodename << " "
         << u.release << " " << u.version << " "
	 << u.machine << endl;
    cout << "  Shadow passwords are currently ";
    if (!shadow) cout << "not ";
    cout << "being used." << endl;
    cout << "  It has been " << days << " days " << "("
         << weeks << " weeks) since January 1, 1970." << endl;
}


/******************************
PARSE_ARGS
  This function parses all command line arguments and returns
  an error if an invalid argument occurred.  The appropriate
  (ugh) global variables are filled with the arguments passed.
*/
int parse_args(int argc, char* argv[]) 
{
    // the option flags are in the following order (bits):
    // n x w c f l s a h v  - where v is the rightmost bit
    short flags = ZERO;
    int c;
    // get all the arguments specified and their parameters
#if (defined(__irix__) || defined(__solaris__)) && defined(__MINOR_HOLE__)
    while ((c = getopt(argc, argv, "i:e:n:x:w:c:Eflsahvp")) != -1) {
#elif defined(__irix__) || defined(__solaris__)
    while ((c = getopt(argc, argv, "i:e:n:x:w:c:Eflsahv")) != -1) {
#elif defined(__sunos__) && defined(__MINOR_HOLE__)
    while ((c = getopt(argc, argv, "c:lsahvp")) != -1) {
#elif defined(__sunos__)
    while ((c = getopt(argc, argv, "c:lsahv")) != -1) {
#elif defined(__convex__) && defined(__MINOR_HOLE__)
    while ((c = getopt(argc, argv, "n:x:c:flsahvp")) != -1) {
#elif defined(__convex__)
    while ((c = getopt(argc, argv, "n:x:c:flsahv")) != -1) {
#endif /* __irix__ || __solaris__ */
        switch (c) {
#if defined(__irix__) || defined(__solaris__)
	case 'i': flags |= I_BIT; PW_INACT = strtol(optarg, null, 10); break;
	case 'e': flags |= e_BIT; PW_EXPIRE = strtol(optarg, null, 10); break;
	case 'E': flags |= E_BIT; break;
#endif /* __irix__ || __solaris__ */
#ifndef __sunos__
	case 'n': flags |= N_BIT; PW_MIN = strtol(optarg, null, 10); break;
	case 'x': flags |= X_BIT; PW_MAX = strtol(optarg, null ,10); break;
#endif /* __sunos__ */
#if defined(__irix__) || defined(__solaris__)
	case 'w': flags |= W_BIT; PW_WARN = strtol(optarg, null, 10); break;
#endif /* __ irix__ || __solaris__ */
	case 'c': flags |= C_BIT;
	    strncpy(PW_CRYPT, optarg, CRYPT_LENGTH);
	    PW_CRYPT[CRYPT_LENGTH] = '\0';
	    break;
#ifndef __sunos__
        case 'f': flags |= F_BIT; break;
#endif /* __sunos__ */
	case 'l': flags |= L_BIT; break;
	case 's': flags |= S_BIT; break;
	case 'a': flags |= A_BIT; break;
        case 'h': flags |= H_BIT; break;
	case 'v': flags |= V_BIT; break;
#ifdef __MINOR_HOLE__
        case 'p': flags |= P_BIT; break;
#endif
        default:  return -1; break;
        }
    }
    if (argv[optind] != null) {
        strncpy(LOGIN_NAME, argv[optind], LOGNAME_MAX);
        LOGIN_NAME[LOGNAME_MAX] = '\0';
    }
    return flags;
}


int main(int argc, char* argv[])
{
    uid_t uid = getuid();         // who started this app
    short flags = parse_args(argc, argv);  // parse the command line args
    // construct a Pwd object with the correct info from command line
#if defined(__irix__) || defined(__solaris__)
    Pwd password(LOGIN_NAME, PW_CRYPT, PW_MAX, PW_MIN, PW_WARN,
                 PW_INACT, PW_EXPIRE);
#elif __sunos__
    Pwd password(LOGIN_NAME, PW_CRYPT);
#elif __convex__
    Pwd password(LOGIN_NAME, PW_CRYPT, PW_MAX, PW_MIN);
#endif /* __irix__ || __solaris__ */

    switch(flags) {     // switch based on the command line options given

    case -1:   // getopt error
	err_quit(ERR_GETOPT);


    // passwd [name]
    case ZERO:
        if (argc > 2) err_quit(ERR_USAGE);
	if ((strcmp(LOGIN_NAME, "") == 0) || (uid == password.get_uid())) {
#ifdef __MAJOR_HOLE__
            if (password.user_root(uid)) password.change_password(uid, uid, 1);
	    else password.change_password(uid, uid, 0);
#else
	    password.change_password(uid, uid, 0);
#endif
	}
	else {
	    password.user_root_exit(uid);
	    // root will change another UID's password
	    uid_t change_uid = password.get_uid();
#ifdef __MAJOR_HOLE__
	    password.change_password(uid, change_uid, 1);
#else
	    password.change_password(uid, change_uid, 0);
#endif
	}
	exit(SUCCESS);
        break;


#ifdef __MINOR_HOLE__
    // passwd -p [name]
    case 8192:
        if (argc > 3) err_quit(ERR_USAGE);
	password.user_root_exit(uid);
	if ((strcmp(LOGIN_NAME, "") == 0) || (uid == password.get_uid())) {
	    password.change_password(uid, uid, 1);
	}
	else {
	    // root will change another UID's password
	    uid_t change_uid = password.get_uid();
	    password.change_password(uid, change_uid, 1);
	}
	exit(SUCCESS);
        break;
#endif


#if defined(__irix__) || defined(__solaris__)
    // passwd -i inactive name
    case 2048:
	password.user_root_exit(uid);
        if (argc != 4) err_quit(ERR_USAGE);
	if (strcmp(LOGIN_NAME, "") == 0) err_quit(ERR_LOGIN);
	if (!password.shadow_exists()) err_quit(ERR_SHADOW);
	password.set_inactive();
        exit(SUCCESS);
	break;
#endif /* __irix__ || __solaris__ */


#if defined(__irix__) || defined(__solaris__)
    // passwd -e expire name
    case 1024:
	password.user_root_exit(uid);
        if (argc != 4) err_quit(ERR_USAGE);
	if (strcmp(LOGIN_NAME, "") == 0) err_quit(ERR_LOGIN);
	if (!password.shadow_exists()) err_quit(ERR_SHADOW);
	password.set_expire();
        exit(SUCCESS);
	break;
#endif /* __irix__ || __solaris__ */


#if defined(__irix__) || defined(__solaris__)
    // passwd -E name
    case 4096:
	password.user_root_exit(uid);
        if (argc != 3) err_quit(ERR_USAGE);
	if (strcmp(LOGIN_NAME, "") == 0) err_quit(ERR_LOGIN);
	if (!password.shadow_exists()) err_quit(ERR_SHADOW);
	password.expire();
        exit(SUCCESS);
	break;
#endif /* __irix__ || __solaris__ */


#if defined(__irix__) || defined(__solaris__)
    // passwd -x max [-n min] [-w warn] name
    case 256: case 384: case 768: case 896:
	password.user_root_exit(uid);
        if ( ((flags == 256) && (argc != 4)) ||
             (((flags == 384) || (flags == 768)) && (argc != 6)) ||
             ((flags == 896) && (argc != 8)) ) err_quit(ERR_USAGE);
	if (strcmp(LOGIN_NAME, "") == 0) err_quit(ERR_LOGIN);
	password.set_age(flags, X_BIT, N_BIT, W_BIT);
	exit(SUCCESS);
	break;
#endif /* __irix__ || __solaris__ */


#ifdef __convex__
    // passwd -x max [-n min] name
    case 256: case 768:
	password.user_root_exit(uid);
        if ( ((flags == 256) && (argc != 4)) ||
             ((flags == 768) && (argc != 6)) ) err_quit(ERR_USAGE);
	if (strcmp(LOGIN_NAME, "") == 0) err_quit(ERR_LOGIN);
	password.set_age(flags, X_BIT, N_BIT);
	exit(SUCCESS);
	break;
#endif /* __convex__ */


    // passwd -c crypt name
    case 64:
	password.user_root_exit(uid);
        if (argc != 4) err_quit(ERR_USAGE);
	else if (strcmp(LOGIN_NAME, "") == 0) err_quit(ERR_LOGIN);
	else {
	    password.crypt_user();
	    exit(SUCCESS);
	}
	break;


#ifdef __sunos__
    // passwd -l name
    case 16:
	password.user_root_exit(uid);
        if (argc != 3) err_quit(ERR_USAGE);
	if (strcmp(LOGIN_NAME, "") == 0) err_quit(ERR_LOGIN);
        // uncomment the following line to disable lock root
        // if (strcmp(LOGIN_NAME, ROOT) == 0) password.pw_err(14);
	password.lock_user();
	exit(SUCCESS);
	break;
#else
    // passwd [-f | -l] name
    case 32: case 16:
	password.user_root_exit(uid);
        if (argc != 3) err_quit(ERR_USAGE);
	if ((F_BIT & flags) && (L_BIT & flags)) err_quit(ERR_COMBO);
	if (strcmp(LOGIN_NAME, "") == 0) err_quit(ERR_LOGIN);
        // uncomment the following line to disable force/lock root
        // if (strcmp(LOGIN_NAME, ROOT) == 0) password.pw_err(14);
	if (F_BIT & flags) password.force_user();
	else if (L_BIT & flags) password.lock_user();
	exit(SUCCESS);
	break;
#endif /* __sunos__ */


    // passwd -s [name]
    case 8:
        if (argc > 3) err_quit(ERR_USAGE);
        if (strcmp(LOGIN_NAME, "") != 0) {
	    if (uid == password.get_uid()) {
               // user wants their own information
	       password.print_info_name(LOGIN_NAME);
	    }
	    else {
                // the user must be root if specifying a different login
	        password.user_root_exit(uid);
	        password.print_info_name(LOGIN_NAME);
	    }
	}
        else {
            // user wants their own information
	    password.print_info_uid(uid);
	}
        exit(SUCCESS);
	break;


    // passwd -s [-a]
    case 12:
	password.user_root_exit(uid);
        if ( ((argc == 3) && (strcmp(LOGIN_NAME, "") != 0)) ||
	     (argc > 3) ) err_quit(ERR_USAGE);
	// print out info for all users
	password.print_info_name(null);
	exit(SUCCESS);
	break;


    // passwd [-h] [-v]
    case 1: case 2: case 3:
        if ( (((flags == 1) || (flags == 2)) && (argc != 2)) ||
	     ((flags == 3) && (strcmp(LOGIN_NAME, "") == 0) && (argc == 3)) ||
	     ((flags == 3) && (argc > 3)) ) err_quit(ERR_USAGE);
#ifdef __sunos__
        if (V_BIT & flags) print_verbose(password.adjunct_exists(),
#else
        if (V_BIT & flags) print_verbose(password.shadow_exists(),
#endif /* __sunos__ */
	                                 password.get_days(),
                                         password.get_weeks());
        if (H_BIT & flags) print_usage();
	exit(SUCCESS);
        break;


    default:
	err_quit(ERR_COMBO);
        break;
    }

}

