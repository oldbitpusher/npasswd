
/******************************

  PASS_SOLARIS.CC
  Written by: Eric Allen Davis
              Numerical Aerospace Simulation Facility
	      NASA Ames Research Center
*/

#include <iostream.h>
#include <fstream.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <ctype.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <crypt.h>
#include "pass_solaris.h"
#define null ((void*)0)

/*
COPY_NEW_PWF
  This function rewrites a new passwd file updating the changes
  that were made.  The files in question here are determined
  by PASSWD_FILE, TEMP_PASSWD_FILE.  The PASSWD_FILE is parsed line
  by line.  Each line gets written to the TEMP_PASSWD_FILE.  If the
  current line is the one that needs to be changed then the updates
  are made and the new line is written to TEMP_PASSWD_FILE.
  Then the file handle links are swapped in the following manner:
    A new link named OLD_PASSWD_FILE is pointed to PASSWD_FILE.
    The PASSWD_FILE name/link is deleted.
    A new link named PASSWD_FILE is pointed to TEMP_PASSWD_FILE.
    The TEMP_PASSWD_FILE name/link is deleted.
  That's all folks!
*/
void Pwd::copy_new_pwf(passwd* pw_ent)
{
    // IGNORE ALL SIGNALS - don't want a corrupted passwd file
    ignore_signals1();

    if (lckpwdf() == -1) pw_err(ERR_PASS_LOCK);   // lock the file
    umask(0);                                     // set the umask
    int pwf_fd, temp_pfd;
    // create the TEMP_PASSWD_FILE for locking and writing only
    if ((temp_pfd = open(TEMP_PASSWD_FILE, O_CREAT|O_WRONLY|O_EXCL, PASSWD_MODE)) == -1)
	pw_err(ERR_T_PASS_OPEN);
    // open the PASSWD_FILE for reading only
    if ((pwf_fd = open(PASSWD_FILE, O_RDONLY)) == -1) pw_err(ERR_PASS_OPEN);
    // chown the TEMP_PASSWD_FILE to root.root
    if (fchown(temp_pfd, root_uid, root_gid) == -1) pw_err(ERR_CHOWN_T_PASS);

    ifstream input(pwf_fd);    // new input stream for PASSWD_FILE
    ofstream output(temp_pfd); // new output stream for TEMP_PASSWD_FILE
    char buf[MAX_BUF];         // temp buffer space
    while(input.getline(buf, MAX_BUF)) {   // read each line until EOF
	char* temp = buf;
	while (*temp != ':') temp++;       // parse out the login name
	*temp = '\0';                   
	if (strcmp(pw_ent->pw_name, buf) == 0) {  // if this line is it
	    output << pw_ent->pw_name << ":"      // then write new info
                   << pw_ent->pw_passwd;
            if (*pw_ent->pw_age != '\0') output << "," << pw_ent->pw_age;
	    output << ":" << pw_ent->pw_uid << ":"
                   << pw_ent->pw_gid << ":"
                   << pw_ent->pw_gecos << ":"
                   << pw_ent->pw_dir << ":"
                   << pw_ent->pw_shell << endl;
	}
	else {                                    // else keep original stuff
	    *temp = ':';
            output << buf << endl;
        }
    }

    // close the PASSWD_FILE
    if(close(pwf_fd) == -1) pw_err(ERR_PASS_CLOSE);
    // close the TEMP_PASSWD_FILE
    if(close(temp_pfd) == -1) pw_err(ERR_T_PASS_CLOSE);
    // create a name OLD_PASSWD_FILE to PASSWD_FILE
    unlink(OLD_PASSWD_FILE);                // delete if exists
    if (link(PASSWD_FILE, OLD_PASSWD_FILE) == -1) pw_err(ERR_O_PASS_CRE);
    // deleted the name/link PASSWD_FILE
    if (unlink(PASSWD_FILE) == -1) pw_err(ERR_DEL_PASS);
    // create a new link to TEMP_PASSWD_FILE named PASSWD_FILE
    if (link(TEMP_PASSWD_FILE, PASSWD_FILE) == -1) pw_err(ERR_CRE_PASS);
    // delete the name/link TEMP_PASSWD_FILE
    if (unlink(TEMP_PASSWD_FILE) == -1) pw_err(ERR_DEL_T_PASS);
    if (ulckpwdf() == -1) pw_err(ERR_PASS_UNLOCK);     // unlock the file
}


/*
COPY_NEW_SHF
  This function rewrites a new shadow file updating the changes
  that were made.  The files in question here are determined
  by SHADOW_FILE, TEMP_SHADOW_FILE.  The SHADOW_FILE is parsed line
  by line.  Each line gets written to the TEMP_SHADOW_FILE.  If the
  current line is the one that needs to be changed then the updates
  are made and the new line is written to TEMP_SHADOW_FILE.
  Then the file handle links are swapped in the following manner:
    A new link named TEMP_SHADOW_FILE is pointed to SHADOW_FILE.
    The SHADOW_FILE name/link is deleted.
    A new link named SHADOW_FILE is pointed to TEMP_SHADOW_FILE.
    The TEMP_SHADOW_FILE name/link is deleted.
  That's all folks!
*/
void Pwd::copy_new_shf(spwd* sp_ent)
{
    // IGNORE ALL SIGNALS - don't want a corrupted passwd file
    ignore_signals1();

    if (lckpwdf() == -1) pw_err(ERR_PASS_LOCK);     // lock the file
    umask(0);                                       // set the umask
    int shf_fd, temp_pfd, temp_sfd;
    // create the TEMP_PASSWD_FILE for locking and writing
    if ((temp_pfd = open(TEMP_PASSWD_FILE, O_CREAT|O_WRONLY|O_EXCL, PASSWD_MODE)) == -1)
        pw_err(ERR_T_PASS_OPEN);
    // create the TEMP_SHADOW_FILE file for locking and writing only
    if ((temp_sfd = open(TEMP_SHADOW_FILE, O_CREAT|O_WRONLY|O_EXCL, SHADOW_MODE)) == -1)
        pw_err(ERR_T_SHAD_OPEN);
    // open the SHADOW_FILE for reading only
    if ((shf_fd = open(SHADOW_FILE, O_RDONLY)) == -1) pw_err(ERR_SHAD_OPEN);
    // chown the TEMP_SHADOW_FILE and OLD_SHADOW_FILE to root.root
    if (fchown(temp_sfd, root_uid, root_gid) == -1) pw_err(ERR_CHOWN_T_SHAD);

    ifstream input(shf_fd);      // new input stream for SHADOW_FILE
    ofstream output(temp_sfd);   // new output stream for TEMP_SHADOW_FILE
    char buf[MAX_BUF];           // temp buffer space
    while(input.getline(buf, MAX_BUF)) {   // read each line until EOF
	char* temp = buf;
	while (*temp != ':') temp++;       // parse out the login name
	*temp = '\0';
	if (strcmp(sp_ent->sp_namp, buf) == 0) {   // if this line is it
	    output << sp_ent->sp_namp << ":" << sp_ent->sp_pwdp << ":";
            if (sp_ent->sp_lstchg != -1) output << sp_ent->sp_lstchg;
	    output << ":";
            if (sp_ent->sp_min != -1) output << sp_ent->sp_min;
	    output << ":";
            if (sp_ent->sp_max != -1) output << sp_ent->sp_max;
	    output << ":";
            if (sp_ent->sp_warn != -1) output << sp_ent->sp_warn;
	    output << ":";
            if (sp_ent->sp_inact != -1) output << sp_ent->sp_inact;
	    output << ":";
            if (sp_ent->sp_expire != -1) output << sp_ent->sp_expire; 
	    output << ":";
            if (sp_ent->sp_flag != -1) output << sp_ent->sp_flag;
	    output << endl;
	}
	else {                                // else keep original stuff
	    *temp = ':';
            output << buf << endl;
        }
    }

    // close the SHADOW_FILE
    if(close(shf_fd) == -1) pw_err(ERR_SHAD_CLOSE);
    // close the TEMP_SHADOW_FILE
    if(close(temp_sfd) == -1) pw_err(ERR_T_SHAD_CLOSE);
    // create a named OLD_SHADOW_FILE to SHADOW_FILE
    unlink(OLD_SHADOW_FILE);                // delete if exists
    if (link(SHADOW_FILE, OLD_SHADOW_FILE) == -1) pw_err(ERR_O_SHAD_CRE);
    // deleted the name/link SHADOW_FILE
    if (unlink(SHADOW_FILE) == -1) pw_err(ERR_DEL_SHAD);
    // create a new link to TEMP_SHADOW_FILE named SHADOW_FILE
    if (link(TEMP_SHADOW_FILE, SHADOW_FILE) == -1) pw_err(ERR_CRE_SHAD);
    // delete the name/link TEMP_SHADOW_FILE
    if (unlink(TEMP_SHADOW_FILE) == -1) pw_err(ERR_DEL_T_SHAD);
    // close and remove the TEMP_PASSWD_FILE
    if (close(temp_pfd) == -1) pw_err(ERR_T_PASS_CLOSE);
    if (unlink(TEMP_PASSWD_FILE) == -1) pw_err(ERR_DEL_T_PASS);
    if (ulckpwdf() == -1) pw_err(ERR_PASS_UNLOCK);    // unlock the file
}


/*
CONVERT_AGE_FROM_STRING
  This function tages a character string age and unmashes is to
  the max age, min age, and last changed age.
*/
void Pwd::convert_age_from_string(char* pw_age, time_t& max_weeks,
                                  time_t& min_weeks, time_t& last)
{
    // convert from the string
    long age = a64l(pw_age);
    // get the radix 64 number - first 6 bits
    max_weeks = (age & 077);
    // get the radix 64 number - second 6 bits
    min_weeks = ((age >> 6) & 077);
    // the remaining bits are the age when changed
    last = (age >> 12);
}


/*
CONVERT_AGE_TO_LONG
  This function takes the current date, max age, and min age and 
  smashes them together into the long integer age.
*/
void Pwd::convert_age_to_long(long& age, time_t& max_weeks, time_t& min_weeks,
                              long& now)
{
    age = max_weeks + (min_weeks << 6) + (now << 12);
}


/*
PRINT_USER_INFO
  This function prints out the passwd entry info specified
  in the argument pw_ent.
*/
void Pwd::print_user_info(passwd* pw_ent)
{
    cout.flags(ios::left);
    cout.width(12); cout << pw_ent->pw_name;
    cout.width(5);
    if (shadow_exists()) {
        spwd* sp_ent = getspnam(pw_ent->pw_name);
        if (sp_ent == null) {
	    cout.width(0);
            cout << "ERROR: Could not retrieve shadow entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_SHAD);
        }
        if (*sp_ent->sp_pwdp == '\0') cout << "NP";
        else if ((strcmp(sp_ent->sp_pwdp, LOCK_STRING1) == 0) ||
                 (strcmp(sp_ent->sp_pwdp, LOCK_STRING2) == 0)) cout << "LK";
        else cout << "PS";
    }
    else {
        if (*pw_ent->pw_passwd == '\0') cout << "NP";
        else if ((strcmp(pw_ent->pw_passwd, LOCK_STRING1) == 0) ||
                 (strcmp(pw_ent->pw_passwd, LOCK_STRING2) == 0)) cout << "LK";
        else cout << "PS";
    }
    cout.width(10); cout << pw_ent->pw_uid;
    cout.width(10); cout << pw_ent->pw_gid;
    cout.width(20); cout << pw_ent->pw_dir;
    cout.width(0); cout << pw_ent->pw_shell << endl;
}


/*
CONSTRUCTOR
  This is a constructor for class Pwd.
*/
Pwd::Pwd() : Pwd_Common()
{
    max_age = min_age = warn_age = inact_age = expire_age = 0;
}


/*
CONSTRUCTOR
  This is a constructor for class Pwd.
*/
Pwd::Pwd(char* name, char* crypt, long max, long min, long warn,
         long inact, long expire) : Pwd_Common(name, crypt)
{
    max_age = max;
    min_age = min;
    warn_age = warn;
    inact_age = inact;
    expire_age = expire;
}


/*
DESTRUCTOR
  This is the destructor for class Pwd.
*/
Pwd::~Pwd()
{
    max_age = min_age = warn_age = inact_age = expire_age = -1;
}


/*
SHADOW_EXISTS
  This function returns 1 if shadow passwds are being used and
  0 otherwise.
*/
int Pwd::shadow_exists()
{
    struct stat stat_buf;
    if (stat(SHADOW_FILE, &stat_buf) == 0) return 1;
    else return 0;
}


/*
CHANGE_PASSWORD
  This function does all the dirty work in changing a password.
*/
void Pwd::change_password(uid_t user_uid, uid_t change_uid, int security_hole)
{
    passwd* pw_ent = getpwuid(change_uid);  // get user entry
    if (pw_ent == null) {
        cout << "ERROR: Could not retrieve password entry for UID '"
             << change_uid << "'." << endl;
        pw_err(ERR_GET_PASS);
    }
    cout << "Changing password for " << pw_ent->pw_name << endl;
    if (shadow_exists()) {   // if using shadow passwords
        spwd* sp_ent = getspnam(pw_ent->pw_name);  // get shadow user entry
        if (sp_ent == null) {
            cout << "ERROR: Could not retrieve shadow entry for '"
	         << pw_ent->pw_name << "'." << endl;
            pw_err(ERR_GET_SHAD);
        }
	// remember that if min is set then so is max
	// if min is greater than max then only root can change the passwd
	if ((sp_ent->sp_min != -1) && (sp_ent->sp_min > sp_ent->sp_max) &&
	    !chkroot(user_uid)) pw_err(ERR_ROOT_ONLY);
	// check that the minimum age has passed since last change
        if ((sp_ent->sp_min != -1) || (sp_ent->sp_min != 0)) {
	    long now = get_days();  // shadow passwords age in days
            if ((sp_ent->sp_lstchg + sp_ent->sp_min) > now) {
                cout << "Sorry: It has been less than " << sp_ent->sp_min 
		     << " days since last change." << endl;
	        pw_err(ERR_AGE);
	    }
	}
	// get the new password from the user
        char* new_crypt_password = get_new_password(sp_ent->sp_pwdp, sp_ent->sp_namp, user_uid, security_hole);
        if (new_crypt_password != null) { // Password successfully changed!
            bzero(sp_ent->sp_pwdp, strlen(sp_ent->sp_pwdp)); // wipe out memory
            sp_ent->sp_pwdp = new_crypt_password;            // set new passwd
            // if min > max and root is changing then turn off aging here
	    if ((sp_ent->sp_min > sp_ent->sp_max) && chkroot(user_uid)) {
	            sp_ent->sp_max = -1;
		    sp_ent->sp_min = -1;
	    }
	    sp_ent->sp_lstchg = get_days();   // reset last changed date
            copy_new_shf(sp_ent);             // rewrite new shadow file
        }
        else {
	    // The moron could not enter in a decent password or their own!
            cout << "Password not changed, try again later." << endl;
	    exit(ERR_UNCHANGED);
        }
    }
    else {  // not using shadow passwds
        long age;
	time_t max_weeks, min_weeks, last;
	long now = get_weeks();          // age in weeks
        if (*pw_ent->pw_age != '\0') {   // if an age exists
	    // get the ages specified
            convert_age_from_string(pw_ent->pw_age, max_weeks, min_weeks, last);
	    // if min is greater than max then only root can change
	    if ((min_weeks > max_weeks) && !chkroot(user_uid)) 
	        pw_err(ERR_ROOT_ONLY);
	    // check that the min age has passwd since last change
            if ((last + min_weeks) > now) {
                cout << "Sorry: It has been less than " << min_weeks 
		     << " weeks since last change." << endl;
	        pw_err(ERR_AGE);
	    }
	}
	// get the new password from the user
        char* new_crypt_password = get_new_password(pw_ent->pw_passwd, pw_ent->pw_name, user_uid, security_hole);
        if (new_crypt_password != null) { // Password successfully changed!
            bzero(pw_ent->pw_passwd, strlen(pw_ent->pw_passwd)); // wipe out
            pw_ent->pw_passwd = new_crypt_password;    // set new passwd
            // if min > max and root is changing then turn off aging here
	    if ((min_weeks > max_weeks) && chkroot(user_uid)) {
		    *pw_ent->pw_age = '\0';
	    }
	    else if (*pw_ent->pw_age != '\0') {
		// get the specified ages
                convert_age_from_string(pw_ent->pw_age, max_weeks,
		                        min_weeks, last);
		// if it was a forced passwd then deleted the age
		if ((max_weeks == 0) && (min_weeks == 0)) {
		    *pw_ent->pw_age = '\0';
                }
		else {
		    // smash the ages together
                    convert_age_to_long(age, max_weeks, min_weeks, now);
		    pw_ent->pw_age = l64a(age);  // get the age string
                }
	    }
	    copy_new_pwf(pw_ent);   // rewrite the new passwd file
        }
        else {
	    // The moron could not enter in a decent password or their own!
            cout << "Password not changed, try again later." << endl;
	    exit(ERR_UNCHANGED);
        }
    }
}


/*
PRINT_INFO_NAME
  This function prints out the passwd entry information for a user.
  If the argument user_name is null then all user entries are printed.
  else just user_name is printed.
*/
void Pwd::print_info_name(char* user_name)
{
    if (user_name != null) {  // print out user_name only
        passwd* pw_ent = getpwnam(user_name);  // get user entry
        if (pw_ent == null) {
            cout << "ERROR: Could not retrieve password entry for '"
	         << user_name << "'." << endl;
            pw_err(ERR_GET_PASS);
        }
        print_user_info(pw_ent);   // print it out
    }
    else {
        passwd* pw_ent;
	// for each user in the passwd file print the info
        while ((pw_ent = getpwent()) != null) print_user_info(pw_ent);  
    }
}


/*
PRINT_INFO_UID
  This function prints out the passwd entry information for a user.
*/
void Pwd::print_info_uid(uid_t uid)
{
    passwd* pw_ent = getpwuid(uid);  // get user entry
    if (pw_ent == null) {
        cout << "ERROR: Could not retrieve password entry for uid '"
             << uid << "'." << endl;
        pw_err(ERR_GET_PASS);
    }
    print_user_info(pw_ent);   // print it out
}


/*
FORCE_USER
  This function forces the user to change their passwd the next time
  they login.
*/
void Pwd::force_user()
{
    if (shadow_exists()) {   // if shadow passwords are being used
        spwd* sp_ent = getspnam(login_name);   // get user entry
        if (sp_ent == null) {
            cout << "ERROR: Could not retrieve shadow entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_SHAD);
        }
        sp_ent->sp_lstchg = 0;     // reset last changed age
        copy_new_shf(sp_ent);      // rewrite the new shadow file
    }
    else {   // shadow passwds are not being used
        passwd* pw_ent = getpwnam(login_name);  // get user entry
        if (pw_ent == null) {
            cout << "ERROR: Could not retrieve password entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_PASS);
        }
	pw_ent->pw_age = FORCE_STRING;   // reset age
        copy_new_pwf(pw_ent);            // rewrite the new passwd file
    }
}


/*
LOCK_USER
  This function locks the user out of their account by '*'ing the passwd.
*/
void Pwd::lock_user()
{
    if (shadow_exists()) {  // if shadow passwords are being used
        spwd* sp_ent = getspnam(login_name);  // get user entry
        if (sp_ent == null) {
            cout << "ERROR: Could not retrieve shadow entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_SHAD);
        }
        bzero(sp_ent->sp_pwdp, strlen(sp_ent->sp_pwdp));  // wipe out memory
        sp_ent->sp_pwdp = LOCK_STRING1;                   // lock passwd
        copy_new_shf(sp_ent);                             // rewrite shadow
    }
    else {    // not using shadow passwords
        passwd* pw_ent = getpwnam(login_name); // get user entry
        if (pw_ent == null) {
            cout << "ERROR: Could not retrieve password entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_PASS);
        }
        bzero(pw_ent->pw_passwd, strlen(pw_ent->pw_passwd)); // wipe out memory
        pw_ent->pw_passwd = LOCK_STRING1;                    // lock passwd
        copy_new_pwf(pw_ent);                                // rewrite passwd
    }
}


/*
CRYPT_USER
  This function inserts a new encrypted password for the user.
*/
void Pwd::crypt_user()
{
    // the length of the encrypted passwd must be valid
    if (!chkcryptlength()) pw_err(ERR_CRYPT_LENGTH);
    // all characters must be valid in the encrypted passwd
    if (!chkcrypt()) pw_err(ERR_CRYPT_CHAR);
    if (shadow_exists()) {  // if using shadow passwords
        spwd* sp_ent = getspnam(login_name);  // get user entry
        if (sp_ent == null) {
            cout << "ERROR: Could not retrieve shadow entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_SHAD);
        }
        bzero(sp_ent->sp_pwdp, strlen(sp_ent->sp_pwdp));  // wipe out memory
        sp_ent->sp_pwdp = crypt_pw;                       // set new passwd
        copy_new_shf(sp_ent);                             // rewrite shadow
    }
    else {   // not using shadow passwords
        passwd* pw_ent = getpwnam(login_name);  // get user entry
        if (pw_ent == null) {
            cout << "ERROR: Could not retrieve password entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_PASS);
        }
        bzero(pw_ent->pw_passwd, strlen(pw_ent->pw_passwd)); // wipe out memory
        pw_ent->pw_passwd = crypt_pw;                        // set new passwd
        copy_new_pwf(pw_ent);                                // rewrite passwd
    }
}


/*
SET_AGE
  This function sets the new age for the user.
*/
void Pwd::set_age(short flags, short x_bit, short n_bit, short w_bit)
{
    // We know that the x_bit must be set to enter this function
    // We know that the n_bit can only be set if the x_bit is set
    // We know that the w_bit can only be set if the x_bit is set
    // if max_age is less than 0 then turn off aging for login_name
    // if min_age > max_age then only root can change the password
    // if min_age >= max_age then we don't care what warn_age is
    // if min_age == max_age then the user is forced to changed their password
    // min_age must be greater 0 (0 is the default)
    // warn_age must be greater then 0 and less then max_age
    // If shadow passwords are not being used then warn_age is ignored

    if ((max_age <= 0) && (max_age != -1)) pw_err(ERR_MAX_DAYS);
    if ((max_age != -1) && (n_bit & flags) && (min_age < 0))
        pw_err(ERR_MIN_DAYS);
    if ((max_age != -1) && (w_bit & flags) && (warn_age <= 0)) 
        pw_err(ERR_WARN_DAYS_LOW);
    if ((max_age != -1) && (w_bit & flags) && (warn_age >= max_age)) 
        pw_err(ERR_WARN_DAYS_HIGH);
    if (shadow_exists()) {  // if using shadow passwords
        spwd* sp_ent = getspnam(login_name);   // get user entry
        if (sp_ent == null) {
            cout << "ERROR: Could not retrieve shadow entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_SHAD);
        }
	if (max_age == -1) {          // turn off all aging
	    cout << "Turning off aging for " << login_name << "." << endl;
            sp_ent->sp_max = -1;
            sp_ent->sp_min = -1;
            sp_ent->sp_warn = -1;
	}
	else if (!(w_bit & flags) && (sp_ent->sp_warn >= max_age)) 
	    pw_err(ERR_CUR_WARN_DAYS);
        else {                        // set the ages as specified
            if (sp_ent->sp_max == -1) sp_ent->sp_lstchg = 0;
            sp_ent->sp_max = max_age;
	    if (n_bit & flags) sp_ent->sp_min = min_age;
	    else sp_ent->sp_min = 0;
            if (w_bit & flags) sp_ent->sp_warn = warn_age;
        }
        copy_new_shf(sp_ent);    // rewrite the new shadow file
    }
    else {    // not using shadow passwords
        passwd* pw_ent = getpwnam(login_name);  // get user entry
        if (pw_ent == null) {
            cout << "ERROR: Could not retrieve password entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_PASS);
        }
	if (max_age == -1) {             // turn off all aging
	    cout << "Turning off aging for " << login_name << "." << endl;
	    *pw_ent->pw_age = '\0';
	}
	else if ((n_bit & flags) && (min_age > max_age)) {
	    // only root can change the password
	    pw_ent->pw_age = ROOT_CHANGE_STRING;
	}
        else {
	    if ((max_age % DAYS_WEEK) != 0) {    // convert the max to weeks
                max_age /= DAYS_WEEK;
	        max_age++;
	    }
	    else {
	        max_age /= DAYS_WEEK;
	    }
	    max_age = (max_age > MAX_CHAR_WEEK) ? MAX_CHAR_WEEK : max_age;
            long age;
	    time_t max_weeks, min_weeks, last;
	    // get the ages from the string
            convert_age_from_string(pw_ent->pw_age, max_weeks, min_weeks, last);
            max_weeks = max_age;
	    if (n_bit & flags) {
                if ((min_age % DAYS_WEEK) != 0) {  // convert the min to weeks
		    min_age /= DAYS_WEEK;
		    min_age++;
		}
		else {
		    min_age /= DAYS_WEEK;
		}
                min_age = (min_age > MAX_CHAR_WEEK) ? MAX_CHAR_WEEK : min_age;
	        min_weeks = min_age;
	    }
	    // preserve age of when password was last changed
	    // smash the ages together
            convert_age_to_long(age, max_weeks, min_weeks, last);
	    // convert it to a string
	    pw_ent->pw_age = l64a(age);
        }
        copy_new_pwf(pw_ent);  // rewrite the new passwd file
    }
}


/*
SET_INACTIVE
  This function sets the number of inactive days allowed for the user.
*/
void Pwd::set_inactive()
{
    // the date specified must be valid
    if ((inact_age <= 0) && (inact_age != -1)) pw_err(ERR_INACT_DAYS);
    if (shadow_exists()) {       // shadow passwords must be used for aging
        spwd* sp_ent = getspnam(login_name);   // get user entry
        if (sp_ent == null) {
            cout << "ERROR: Could not retrieve shadow entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_SHAD);
        }
        sp_ent->sp_inact = inact_age;     // set the inactive age
        copy_new_shf(sp_ent);             // rewrite the new shadow file
    }
}


/*
SET_EXPIRE
  This function sets the expiration date for the user account.
*/
void Pwd::set_expire()
{
    // the date specified must be valid
    if ((expire_age <= 0) && (expire_age != -1)) pw_err(ERR_EXPIRE_DAYS);
    if (shadow_exists()) {   // shadow passwords must be used to expire
        spwd* sp_ent = getspnam(login_name);    // get user entry
        if (sp_ent == null) {
            cout << "ERROR: Could not retrieve shadow entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_SHAD);
        }
        sp_ent->sp_expire = expire_age;     // set the expiration date
        copy_new_shf(sp_ent);               // rewrite the new shadow file
    }
}


/*
EXPIRE
  This function expires the user account immediately.
*/
void Pwd::expire()
{
    if (shadow_exists()) {      // shadow password must be used to expire
        spwd* sp_ent = getspnam(login_name);   // get user entry
        if (sp_ent == null) {
            cout << "ERROR: Could not retrieve shadow entry for '"
	         << login_name << "'." << endl;
            pw_err(ERR_GET_SHAD);
        }
        sp_ent->sp_expire = 1;    // nuke the account
        copy_new_shf(sp_ent);     // rewrite the new shadow file
    }
}

