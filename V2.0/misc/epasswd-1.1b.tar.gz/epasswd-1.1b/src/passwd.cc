
/******************************

  PASSWD.CC
  Written by: Eric Allen Davis
              Numerical Aerospace Simulation Facility
              NASA Ames Research Center
*/

#include <pwd.h>
#include <iostream.h>
#include <ctype.h>
#include <sys/time.h>
#include <time.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include "passwd.h"
#define null ((void*)0)

/*
CHKROOT
  This function returns 1 if the given uid is equal to root's
  and 0 otherwise.
*/
int Pwd_Common::chkroot(uid_t uid)
{
    if (uid == root_uid) return 1;
    else return 0;
}


/*
CHKCRYPTLENGTH
  This function returns 1 if the length of the string pointed to
  by the member crypt_pw is equal to CRYPT_LENGTH and 0 otherwise.
*/
int Pwd_Common::chkcryptlength()
{
    if (crypt_pw == null) return 0;
    else if (strlen(crypt_pw) == CRYPT_LENGTH) return 1;
    else return 0;
}


/*
CHKCRYPT
    This function checks to ensure that all the characters in the string
    are of the set [a-z, A-Z, 0-9, ., /] and returns the following:
      0 if an invalid character is found
      1 if all characters are OK
*/
int Pwd_Common::chkcrypt()
{
    char* temp = crypt_pw;
    for (int i = 0 ; i < CRYPT_LENGTH ; i++) {
        if ((*temp == '.') || (*temp == '/') || isalnum(*temp)) temp++;
        else return 0;
    }
    return 1;
}


/*
GENERATE_SALT
  This function generates a SALT_SIZE char salt that is used by the
  crypt function.  It returns the SALT_SIZE characters in the salt
  array in which it was passed.
  This is a clone of Matt Bishop's makesalt function within passwd+.
*/
void Pwd_Common::generate_salt(char salt[SALT_SIZE])
{
    struct timeval* tv = new timeval;
    gettimeofday(tv, null);
    long temp_rand = ((tv->tv_usec & 0xa5ef8741) | (getpid() << 0x3 ));
    for(int i = 0 ; i < SALT_SIZE ; i++) {
        salt[i] = (temp_rand & 0x3f) + '.';
        if (salt[i] > '9') salt[i] += 7;
        if (salt[i] > 'Z') salt[i] += 6;
        temp_rand >>= 5;
    }
}


/*
IGNORE_SIGNALS1
  This function sets SIG_IGN for all signals.  We don't want
  any core dumps and corrupted passwd files.
*/
void Pwd_Common::ignore_signals1()
{
    for(int i = 0; i < NSIG; i++) {
        (void) signal(i, SIG_IGN);
    }
    // don't care that errno was set because SIGKILL can not be ignored
}


/*
IGNORE_SIGNALS2
  This function sets SIG_IGN for all signals.  We don't want
  any core dumps and corrupted passwd files.
  The difference between this function and IGNORE_SIGNALS2 is
  that this one does not ignore SIGINT.
*/
void Pwd_Common::ignore_signals2()
{
    // allow SIGINT
    for(int i = 0; i < NSIG; i++) {
        if (i != SIGINT) (void) signal(i, SIG_IGN);
    }
    // don't care that errno was set because SIGKILL can not be ignored
}


/*
CHECK_OLD
  This function ensures that the user is who they say they are.
  It takes as arguments the passwd entry for the user uid and
  a storage buffer for the non-encrypted original passwd which the
  user must enter to prove themselves.  This function returns
  1 if the user entered in the correct original password and
  0 otherwise.
*/
int Pwd_Common::check_old(char* pw_passwd, char* old_pass)
{
    char old_salt[SALT_SIZE];                  // storage for the salt
    for(int i = 0 ; i < SALT_SIZE ; i++) {
        old_salt[i] = pw_passwd[i];            // get the original salt
    }
    strncpy(old_pass, getpass("Old password:"), MAX_PASSWD_BUF);
    old_pass[LAST_PASSWD_CHAR] = '\0';
    if (old_pass == null) {                      // error in getpass
        cout << "ERROR: getpass() could not read in password." << endl;
        return 0;
    }
    char* old_crypt = crypt(old_pass, old_salt); // crypt the passwd
    if (strcmp(old_crypt, pw_passwd) != 0) {     // is it the same?
        cout << "Incorrect, you imposter." << endl;   // IMPOSTER!
        bzero(old_pass, strlen(old_pass));       // wipe out memory
        bzero(old_crypt, strlen(old_crypt));     // wipe out memory
        return 0;
    }
    else {
        bzero(old_crypt, strlen(old_crypt));     // wipe out memory
        return 1;                                // user is a friendly
    }
}


/*
GET_NEW_PASSWORD
  This function gets the new passwd from the user and does the checking
  to ensure the passwd passes all the characteristics specified in the
  Makefile.
  Note that this function is super-paranoid in that it constantly
  zeroes out memory as soon as it does not need a passwd string.
*/
char* Pwd_Common::get_new_password(char* pw_passwd, char* pw_name, uid_t uid,
                            int security_hole)
{
    char old_pass[MAX_PASSWD_BUF];            // temp storage
    *old_pass = '\0';                         // initialize
    char new_pass1[MAX_PASSWD_BUF];           // temp storage
    char new_pass2[MAX_PASSWD_BUF];           // temp storage
    // if user is not root then they must prove they can change the passwd
    if (!chkroot(uid) && !check_old(pw_passwd, old_pass)) return null;
    for (int i = 0; i < MAX_NUM_ATTEMPTS; i++) {      // user gets 3 tries
        strncpy(new_pass1, getpass("New password:"), MAX_PASSWD_BUF);
        new_pass1[LAST_PASSWD_CHAR] = '\0';
        if (new_pass1 == null) {                      // error
            cout << "ERROR: getpass() could not read in password." << endl;
            bzero(old_pass, strlen(old_pass));  // wipe out memory
            return null;
        }

        if (!security_hole) {
            // Do all the password checks/tests here!!
            { // force the scope of class Test
                tests = new Test(old_pass, new_pass1, pw_name, root_uid, chkroot(uid));
                if (!tests->do_tests()) {
                    bzero(new_pass1, strlen(new_pass1));  // wipe out memory
                    continue;
                }
            }
        }

        // Make the user re-enter the password
        strncpy(new_pass2, getpass("Re-enter new password:"), MAX_PASSWD_BUF);
        new_pass2[LAST_PASSWD_CHAR] = '\0';
        if (new_pass2 == null) {                  // error
            cout << "ERROR: getpass() could not read in password." << endl;
            bzero(old_pass, strlen(old_pass));    // wipe out memory
            bzero(new_pass1, strlen(new_pass1));  // wipe out memory
            return null;
        }
        // the two passwords entered must be the same
        if (strcmp(new_pass1, new_pass2) == 0) {
            // GOT IT - now clean up memory and return crypted password
            bzero(old_pass, strlen(old_pass));   // wipe out memory
            bzero(new_pass2, strlen(new_pass2)); // wipe out memory
            char new_salt[SALT_SIZE];            // new salt storage
            generate_salt(new_salt);             // get a new salt
            char* new_crypt_pass = crypt(new_pass1, new_salt);  // crypt it
            bzero(new_pass1, strlen(new_pass1)); // wipe out memory
            if (security_hole) {
                cout << "The password has been accepted but it may be" << endl
                     << "insecure because no checks were made." << endl;
            }
            return new_crypt_pass;
        }
        else cout << "They don't match." << endl;   // IDIOT!
        bzero(new_pass1, strlen(new_pass1));     // wipe out memory
        bzero(new_pass2, strlen(new_pass2));     // wipe out memory
    }
    bzero(old_pass, strlen(old_pass));           // wipe out memory
    cout << "Too many failures." << endl;        // IDIOT!
    return null;
}


/*
CONSTRUCTOR
*/
Pwd_Common::Pwd_Common() : Pwd_Error(CRYPT_LENGTH)
{
    strncpy(login_name, "", (LOGNAME_MAX+1));
    strncpy(crypt_pw, "", (CRYPT_LENGTH+1));
    root_uid = 0;
    root_gid = 0;
}


/*
CONSTRUCTOR
*/
Pwd_Common::Pwd_Common(char* name, char* crypt) : Pwd_Error(CRYPT_LENGTH)
{
    if (strcmp(name, "") != 0) {
        strncpy(login_name, name, LOGNAME_MAX);
        login_name[LOGNAME_MAX] = '\0';
    }
    else strncpy(login_name, "", (LOGNAME_MAX+1));
    if (strcmp(crypt, "") != 0) {
        strncpy(crypt_pw, crypt, CRYPT_LENGTH);
        crypt_pw[CRYPT_LENGTH] = '\0';
    }
    else strncpy(crypt_pw, "", (CRYPT_LENGTH+1));
    root_uid = 0;
    root_gid = 0;
}


/*
DESTRUCTOR
*/
Pwd_Common::~Pwd_Common()
{
    if (strcmp(login_name, "") != 0) strncpy(login_name, "", (LOGNAME_MAX+1));
    if (strcmp(crypt_pw, "") != 0) strncpy(crypt_pw, "", (CRYPT_LENGTH+1));
}


/*
GET_UID
  This function returns the uid of the user in login name.
*/
uid_t Pwd_Common::get_uid()
{
    passwd* pw_ent = getpwnam(login_name);  // get user entry
    if (pw_ent == null) {
        cout << "ERROR: Could not retrieve password entry for '"
             << login_name << "'." << endl;
        pw_err(ERR_GET_PASS);
    }
    return pw_ent->pw_uid;   // return the uid
}


/*
GET_DAYS
  This function returns the number of days since Jan 1. 1970
*/
long Pwd_Common::get_days()
{
    return (long)(time(null) / SECONDS_DAY);
}


/*
GET_WEEKS
 This function returns the number of weeks since Jan 1. 1970
*/
long Pwd_Common::get_weeks()
{
    return (long)(time(null) / SECONDS_WEEK);
}


/*
USER_ROOT_EXIT
  This function checks if the user has permission to execute
  any of the root only options.  If the user is root then
  the function exits normally else it calls pw_err to print
  out the error message and exit.
*/
void Pwd_Common::user_root_exit(uid_t uid)
{
    if (!chkroot(uid)) pw_err(ERR_ROOT);
}


/*
USER_ROOT
  This function checks if the user has permission to execute
  any of the root only options.
*/
int Pwd_Common::user_root(uid_t uid)
{
    return chkroot(uid);
}

