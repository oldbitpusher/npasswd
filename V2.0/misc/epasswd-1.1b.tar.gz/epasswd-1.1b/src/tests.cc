
/******************************

  TESTS.CC
  Written by: Eric Allen Davis
              Numerical Aerospace Simulation Facility
	      NASA Ames Research Center
*/

#include "tests.h"
#include <iostream.h>
#include <ctype.h>
#include <string.h>
#define null ((void*)0)

/*
CHKUPPER
  This function checks that there is at least min upper case 
  characters in the string and returns the following:
    1 if there is >= min upper case chars
    0 if there is <  min upper case chars

  If NUM_MIDDLE == 1 then a numeric character must exist in the
  middle of the password somewhere.
*/
int Test::chkupper(char* string, int min)
{
    char* temp = string;
    int middle_count = 0;
    int total_count = 0;
    if (UCASE_MIDDLE) {    // check first character
	if (isupper(*temp)) total_count++;
        temp++;
    }
    while (*temp != '\0') {
        if (isupper(*temp)) {
	    if (UCASE_MIDDLE) middle_count++;
	    total_count++;
	}
        temp++;
    }
    if (UCASE_MIDDLE) {    // check last character
    	temp--;
    	if (isupper(*temp)) middle_count--;
        if (middle_count && (total_count >= min)) return 1;
        else return 0;
    }
    else {
        if (total_count >= min) return 1;
        else return 0;
    }
}


/*
CHKLOWER
  This function checks that there is at least min lower case 
  characters in the string and returns the following:
    1 if there is >= min lower case chars
    0 if there is <  min lower case chars
*/
int Test::chklower(char* string, int min)
{
    char* temp = string;
    int count = 0;
    while (*temp != '\0') {
        if (islower(*temp)) count++;
        temp++;
    }
    if (count >= min) return 1;
    else return 0;
}


/*
CHKNUM
  This function checks that there is at least min number
  characters in the string and returns the following:
    1 if there is >= min number chars
    0 if there is <  min number chars

  If NUM_MIDDLE == 1 then a numeric character must exist in the
  middle of the password somewhere.
*/
int Test::chknum(char* string, int min)
{
    char* temp = string;
    int middle_count = 0;
    int total_count = 0;
    if (NUM_MIDDLE) {    // check first character
	if (isdigit(*temp)) total_count++;
        temp++;
    }
    while (*temp != '\0') {
        if (isdigit(*temp)) {
	    if (NUM_MIDDLE) middle_count++;
	    total_count++;
	}
        temp++;
    }
    if (NUM_MIDDLE) {    // check last character
    	temp--;
    	if (isdigit(*temp)) middle_count--;
        if (middle_count && (total_count >= min)) return 1;
        else return 0;
    }
    else {
        if (total_count >= min) return 1;
        else return 0;
    }
}


/*
CHKSPEC
  This function checks that there is at least min special
  characters in the string and returns the following:
    1 if there is >= min special chars
    0 if there is <  min special chars
  Special characters consist of the following set of 32 chars:
  ~`!@$%^&*()-_+={}[]|\;:'"<>,./?<space>
  Note that the '#' character was left out.  This is because
  some systems rsh daemons interpret this character weirdly.

  If NUM_MIDDLE == 1 then a numeric character must exist in the
  middle of the password somewhere.
*/
int Test::chkspec(char* string, int min)
{
    char* temp = string;
    int middle_count = 0;
    int total_count = 0;
    if (SPEC_MIDDLE) {    // check first character
	// ~`!@$%^&*()_-+={}[]|\;:'"<>,./? and a the space character
	// leave the # char out
	switch (*temp) {
        case '~': case '`': case '!': case '@': case '$': case '%':
	case '^': case '&': case '*': case '(': case ')': case '_':
	case '-': case '+': case '=': case '{': case '}': case '[':
	case ']': case '|': case '\\': case '\;': case ':': case '\'':
	case '"': case '<': case '>': case ',': case '.': case '/':
	case '?': case ' ':
	    total_count++;
	    break;
        default:
	    break;
	}
        temp++;
    }
    while (*temp != '\0') {
	// ~`!@$%^&*()_-+={}[]|\;:'"<>,./? and a the space character
	// leave the # char out
	switch (*temp) {
        case '~': case '`': case '!': case '@': case '$': case '%':
	case '^': case '&': case '*': case '(': case ')': case '_':
	case '-': case '+': case '=': case '{': case '}': case '[':
	case ']': case '|': case '\\': case '\;': case ':': case '\'':
	case '"': case '<': case '>': case ',': case '.': case '/':
	case '?': case ' ':
	    if (SPEC_MIDDLE) middle_count++;
	    total_count++;
	    break;
        default:
	    break;
	}
        temp++;
    }
    if (SPEC_MIDDLE) {    // check last character
    	temp--;
	// ~`!@$%^&*()_-+={}[]|\;:'"<>,./? and a the space character
	// leave the # char out
	switch (*temp) {
        case '~': case '`': case '!': case '@': case '$': case '%':
	case '^': case '&': case '*': case '(': case ')': case '_':
	case '-': case '+': case '=': case '{': case '}': case '[':
	case ']': case '|': case '\\': case '\;': case ':': case '\'':
	case '"': case '<': case '>': case ',': case '.': case '/':
	case '?': case ' ':
	    middle_count--;
	    break;
        default:
	    break;
	}
        if (middle_count && (total_count >= min)) return 1;
        else return 0;
    }
    else {
        if (total_count >= min) return 1;
        else return 0;
    }
}


/*
CMPSTR
  This function compares the two strings and returns the following:
    1 if strings are the same
    0 if they are different
  What is unique about this function is that an upper case
  character is treated as being equal to its equivalent lower
  case and vice-versa. ('a' = 'A')

  I have two different versions of the function below.  One that
  dereferences pointers/arrays and one that traverses using pointers.
  The later is much faster so that is the one that is used.
*/
/*
int Test::cmpstr(char* string1, char* string2)
{
    int i = 0;
    for( ; (string1[i] != '\0') || (string2[i] != '\0') ; i++) {
        if (string1[i] == string2[i]) {
	    continue;
	}
        else if (isupper(string1[i])) {
            if ((char)(string1[i]+32) == string2[i]) {
		continue;
	    }
	    else return 0;
	}
        else if (islower(string1[i])) {
            if ((char)(string1[i]-32) == string2[i]) {
		continue;
	    }
	    else return 0;
	}
        else return 0;
    }
    if ((string1[i] == '\0') && (string2[i] == '\0')) return 1;
    else return 0;
}
*/
int Test::cmpstr(char* string1, char* string2)
{
    char* temp1 = string1;
    char* temp2 = string2;
    while ((*temp1 != '\0') && (*temp2 != '\0')) {
        if (*temp1 == *temp2) {
	    temp1++; temp2++;
	    continue;
	}
        else if (isupper(*temp1)) {
            if ((char)(*temp1+32) == *temp2) {
		temp1++; temp2++;
		continue;
	    }
	    else return 0;
	}
        else if (islower(*temp1)) {
            if ((char)(*temp1-32) == *temp2) {
		temp1++; temp2++;
		continue;
	    }
	    else return 0;
	}
        else return 0;
    }
    if ((*temp1 == '\0') && (*temp2 == '\0')) return 1;
    else return 0;
}


/*
CHKLOGIN
  This function checks all circular shifts of the login name with
  the pass string.  The following is returned:
    1 if pass is unequal to all circular shifts of the login name
    0 if pass is equal to some circular shift of the login name
*/
int Test::chklogin(char* login, char* pass)
{
    char* temp = strdup(login);
    int login_length = strlen(temp);
    for (int i = 0 ; i < login_length ; i++) {
        if (!cmpstr(temp, pass)) {
            char c = *temp;
	    for(int x = 1 ; x < login_length ; x++) temp[x-1] = temp[x]; 
	    temp[login_length-1] = c;    
	}
        else return 0;
    }
    return 1;
}


/*
CHKDIFF
  This function checks the number of characters that are different
  in the two strings.  The following is returned;
    1 if the number of different chars is >= min
    0 if the number of different chars is <  min
*/
int Test::chkdiff(char* string1, char* string2, int min)
{
    char* temp1 = string1;
    char* temp2 = string2;
    int count = 0;
    while ((*temp1 != '\0') && (*temp2 != '\0')) {
        if (*temp1 == *temp2) ; // do nothing
        else if (isupper(*temp1)) {
            if ((char)(*temp1+32) == *temp2) ; // do nothing
	    else count++;
	}
        else if (islower(*temp1)) {
            if ((char)(*temp1-32) == *temp2) ; // do nothing
	    else count++;
	}
        else count++;
	temp1++; temp2++;
    }
    // at the end of one of the strings and all
    // extra characters count as a diff
    while (*temp1 != '\0') {
	count++;
        temp1++;
    }
    while (*temp2 != '\0') {
        count++;
	temp2++;
    }
    // Crypt only cares about the first 8 chars so if the new string
    // had the same eaight chars and say 4 extra one added on the
    // end then the two strings would be crytped the same.
    if (count >= min) return 1;
    else return 0;
}


/*
REVSTRING
    This function simply reverses the charactars in string.
*/
void Test::revstring(char* string)
{
    char* temp = strdup(string);
    int length = strlen(string);
    for (int i = 0, j = (length-1); i < length ; i++, j--) {
        string[j] = temp[i];
    }
}


/*
CONSTRUCTOR
  This is a constructor for class Test.
*/
Test::Test(char* old_pw, char* new_pw, char* name, uid_t root, uid_t user)
{
    if (old_pw != null) old_password = strdup(old_pw);
    if (new_pw != null) new_password = strdup(new_pw);
    if (name != null) user_name = strdup(name);
    root_uid = root;
    user_uid = user;
}


/*
CONSTRUCTOR
  This is a constructor for class Test.
*/
Test::Test()
{
    old_password = null;
    new_password = null;
    user_name = null;
    root_uid = -1;
    user_uid = -1;
}


/*
DESTRUCTOR
  This is a destructor for class Test.
*/
Test::~Test()
{
    if (old_password != null) {
	bzero(old_password, strlen(old_password));
        delete[] old_password;
    }
    if (new_password != null) {
	bzero(new_password, strlen(new_password));
        delete[] new_password;
    }
    if (user_name != null) {
	bzero(user_name, strlen(user_name));
        delete[] user_name;
    }
    old_password = new_password = user_name = null;
    root_uid = -1;
    user_uid = -1;
}


/*
DO_TESTS
  This function does all the tests on the new password to ensure
  it is reasonably safe based on the construction requirements.
*/
int Test::do_tests()
{
    if ((old_password == null) || (new_password == null) || (user_uid == -1))
        return 0;
    // check the min passwd length
    if (strlen(new_password) < MIN_PASSWORD_LENGTH) {
        cout << "Password is too short, it must be at least "
             << MIN_PASSWORD_LENGTH << " characters." << endl;
        bzero(new_password, strlen(new_password));
        return 0;
    }
    // check for instances of the login string within the passwd
    if (!chklogin(user_name, new_password)) {
        cout << "Password cannot be circular shift of your login name." 
             << endl;
        bzero(new_password, strlen(new_password));
        return 0;
    }
    char* rev_login = strdup(user_name);
    revstring(rev_login);                // reverse the login name
    // check for instances of the reverse login string within the passwd
    if (!chklogin(rev_login, new_password)) {
        cout << "Password cannot be circular shift of your reversed login name." << endl;
        bzero(new_password, strlen(new_password));
        return 0;
    }
    delete[] rev_login; rev_login = null;
    // passwd needs to pass a minimum number of the following
    // four tests (lower case, upper case, numbers, special)
    int pass_upper = 0;
    int pass_lower = 0;
    int pass_num = 0;
    int pass_spec = 0;
    // check the number of uppper case chars
    if (MIN_CHARS_UCASE) pass_upper = chkupper(new_password, MIN_CHARS_UCASE);
    // check the number of lower case chars
    if (MIN_CHARS_LCASE) pass_lower = chklower(new_password, MIN_CHARS_LCASE);
    // check the number of numeric chars
    if (MIN_CHARS_NUM) pass_num = chknum(new_password, MIN_CHARS_NUM);
    // check the number of special chars
    if (MIN_CHARS_SPEC) pass_spec = chkspec(new_password, MIN_CHARS_SPEC);
    // the passwd must pass at least MIN_CASES_PASS for the
    // passwd to be valid - if not then the nuke it and return
    if ((pass_upper + pass_lower + pass_num + pass_spec) < MIN_CASES_PASS) {
        if (MIN_CHARS_UCASE && !pass_upper && UCASE_MIDDLE) {
            cout << "Password must contain at least one upper case character"
                 << endl << "in the middle of the password." << endl;
            bzero(new_password, strlen(new_password));
            return 0;
        }
        else if (MIN_CHARS_UCASE && !pass_upper) {
            cout << "Password must contain at least "
                 << MIN_CHARS_UCASE << " upper case characters." << endl;
            bzero(new_password, strlen(new_password));
            return 0;
        }
        else if (MIN_CHARS_NUM && !pass_num && NUM_MIDDLE) {
            cout << "Password must contain at least one numeric character"
                 << endl << "in the middle of the password." << endl;
            bzero(new_password, strlen(new_password));
            return 0;
        }
        else if (MIN_CHARS_NUM && !pass_num) {
            cout << "Password must contain at least "
                 << MIN_CHARS_NUM << " numeric characters." << endl;
            bzero(new_password, strlen(new_password));
            return 0;
        }
        else if (MIN_CHARS_SPEC && !pass_spec && SPEC_MIDDLE) {
            cout << "Password must contain at least one special character"
                 << endl << "in the middle of the password." << endl;
            bzero(new_password, strlen(new_password));
            return 0;
        }
        else if (MIN_CHARS_SPEC && !pass_spec) {
            cout << "Password must contain at least "
                 << MIN_CHARS_SPEC << " special characters." << endl;
            bzero(new_password, strlen(new_password));
            return 0;
        }
        else if (MIN_CHARS_LCASE && !pass_lower) {
            cout << "Password must contain at least "
                 << MIN_CHARS_LCASE << " lower case characters." << endl;
            bzero(new_password, strlen(new_password));
            return 0;
        }
    }
    // check that the passwd differs from the old by some number of chars
    if ((user_uid == root_uid) && !chkdiff(new_password, old_password,
                                           NUM_DIFF_CHARS)) {
        cout << "Password must differ from the old by at least "
             << NUM_DIFF_CHARS << " characters." << endl;
        bzero(new_password, strlen(new_password));
        return 0;
    }
    // if we get here then the password is tollerable ;-)
    return 1;
}


