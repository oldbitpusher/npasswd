
/******************************

  ERROR.H
  Written by: Eric Allen Davis
              Numerical Aerospace Simulation Facility
              NASA Ames Research Center


** PRIVATE MEMBERS:
int crypt_length -
  This variable specifies the length of an encrypted password.

** PROTECTED MEMBERS:

** PUBLIC MEMBERS:
Pwd_Error() -
  Constructor for Pwd_Error.
Pwd_Error(int cl) -
  Constructor for Pwd.
~Pwd() -
  Destructor for Pwd.
void pw_err(int error) - 
  This function prints an appropriate error message and
  exits the application with a certain error code.

*/


#ifndef ERROR
#define ERROR

const int ERR_UNCHANGED = 1;
const int ERR_PASS_LOCK = 8;
const int ERR_PASS_UNLOCK = 9;
const int ERR_PASS_OPEN = 10;
const int ERR_REST_OPEN = 11;
const int ERR_SHAD_OPEN = 12;
const int ERR_ADJ_OPEN = 13;
const int ERR_T_PASS_OPEN = 14;
const int ERR_T_REST_OPEN = 15;
const int ERR_T_SHAD_OPEN = 16;
const int ERR_T_ADJ_OPEN = 17;
const int ERR_CHOWN_T_PASS = 18;
const int ERR_CHOWN_T_REST = 19;
const int ERR_CHOWN_T_SHAD = 20;
const int ERR_CHOWN_T_ADJ = 21;
const int ERR_PASS_CLOSE = 22;
const int ERR_REST_CLOSE = 23;
const int ERR_SHAD_CLOSE = 24;
const int ERR_ADJ_CLOSE = 25;
const int ERR_T_PASS_CLOSE = 26;
const int ERR_T_REST_CLOSE = 27; 
const int ERR_T_SHAD_CLOSE = 28;
const int ERR_T_ADJ_CLOSE = 29;
const int ERR_DEL_PASS = 30;
const int ERR_DEL_REST = 31;
const int ERR_DEL_SHAD = 32;
const int ERR_DEL_ADJ = 33;
const int ERR_CRE_PASS = 34;
const int ERR_CRE_REST = 35;
const int ERR_CRE_SHAD = 36;
const int ERR_CRE_ADJ = 37;
const int ERR_DEL_T_PASS = 38;
const int ERR_DEL_T_REST = 39;
const int ERR_DEL_T_SHAD = 40;
const int ERR_DEL_T_ADJ = 41;
const int ERR_O_PASS_CRE = 42;
const int ERR_O_REST_CRE = 43;
const int ERR_O_SHAD_CRE = 44;
const int ERR_O_ADJ_CRE = 45;
const int ERR_ROOT_ONLY = 46;
const int ERR_CRYPT_LENGTH = 47;
const int ERR_CRYPT_CHAR = 48;
const int ERR_MAX_DAYS = 49;
const int ERR_MIN_DAYS = 50;
const int ERR_WARN_DAYS_LOW = 51;
const int ERR_WARN_DAYS_HIGH = 52;
const int ERR_CUR_WARN_DAYS = 53;
const int ERR_INACT_DAYS = 54;
const int ERR_EXPIRE_DAYS = 55;
const int ERR_AGE = 56;
const int ERR_ROOT = 57;
const int ERR_EXEC_PASSWD = 58;
const int ERR_EXEC_RESTRICT = 59;
const int ERR_EXEC_SHADOW = 60;
const int ERR_BAD_DATE = 61;
const int ERR_GET_PASS = 62;
const int ERR_GET_REST = 63;
const int ERR_GET_SHAD = 64;
const int ERR_GET_ADJ = 65;
const int ERR_UNKNOWN = 100;

class Pwd_Error
{
private:

    int crypt_length;

protected:

public:

    Pwd_Error(int cl);
    // ~Pwd_Error();
    void pw_err(int error);

};

#endif
