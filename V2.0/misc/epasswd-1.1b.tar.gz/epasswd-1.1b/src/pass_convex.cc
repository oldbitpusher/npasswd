
/******************************

  PASS_CONVEX.CC
  Written by: Eric Allen Davis
              Numerical Aerospace Simulation Facility
              NASA Ames Research Center
*/

#include <stdio.h>
#include <iostream.h>
#include <strstream.h>
#include <fstream.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <ctype.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "pass_convex.h"
#define null ((void*)0)

/*
MKDB
  This function forks and execs the 'mkpasswd' command to create
  the database file for the passwd, shadow, or pwrestrict file.
*/
void Pwd::mkdb(int which)
{
    switch (which) {
    case PASSWD_DB: {
        cout << "Rebuilding passwd database..." << endl;
        pid_t pid = vfork();
        if (pid == 0) {
            if (execl(MKPASSWD, MKPASSWD, "-p",
                      "/etc/passwd", null) == -1) exit(ERR_EXEC_PASSWD);
        }
        int status;
        if (waitpid(pid, &status, 0) == -1) pw_err(ERR_EXEC_PASSWD);
        if (status) pw_err(ERR_EXEC_PASSWD);
        break;
    }
    case SHADOW_DB: {
        cout << "Rebuilding shadow database..." << endl;
        pid_t pid = vfork();
        if (pid == 0) {
            if (execl(MKPASSWD, MKPASSWD, "-s",
                      "/etc/shadow", null) == -1) exit(ERR_EXEC_SHADOW);
        }
        int status;
        if (waitpid(pid, &status, 0) == -1) pw_err(ERR_EXEC_SHADOW);
        if (status) pw_err(ERR_EXEC_SHADOW); 
        break;
    }
    case RESTRICT_DB: {
        cout << "Rebuilding pwrestrict database..." << endl;
        pid_t pid = vfork();
        if (pid == 0) {
            if (execl(MKPASSWD, MKPASSWD, "-r",
                      "/etc/pwrestrict", null) == -1) exit(ERR_EXEC_RESTRICT);
        }
        int status;
        if (waitpid(pid, &status, 0) == -1) pw_err(ERR_EXEC_RESTRICT);
        if (status) pw_err(ERR_EXEC_RESTRICT); 
        break;
    }
    default:
        pw_err(ERR_UNKNOWN);
        break;
    }
}


/*
GET_DATE
  This function returns a date string of the form:
   Jan 01 1970\0
  The character string returned is always 12 characters long
  including the terminating null character.
*/
char* Pwd::get_date()
{
    char* date = new char[12];  // allocate some space ("mmm dd yyyy\0")
    time_t t = time(null);      // get the time
    char* temp = ctime(&t);     // convert it to ascii
    temp += 4;                  // skip the week day
    char* prev = temp;          // start of month and day
    temp += 6;                  // skip over month and day
    *temp = '\0';               // terminate month and day
    strncpy(date, prev, 6);     // copy month and day
    date[6] = '\0';             // end the string
    strncat(date, " ", 1);      // concat a space
    date[7] = '\0';             // end the string
    temp += 10;                 // skip over the time
    prev = temp;                // start of year
    temp += 4;                  // skip over year
    *temp = '\0';               // terminate yesr
    strncat(date, prev, 4);     // concat the year
    date[11] = '\0';            // end the string
    return date;                // return it
}


/*
CONVERT_TO_WEEKS
  This function takes a character string date of the form
    mmm dd yyyy\0
  It then figures out the number of weeks since Jan 1 1970
  this date represents and returns it.
*/
long Pwd::convert_to_weeks(char* date)
{
    // from Jan 01 1970
    struct tm t; t.tm_sec = 0; t.tm_min = 0; t.tm_hour = 0;

    char* year = date;    // scan for the year
    year += 7;
    t.tm_year = (strtol(year, null, 10) - 1900);  // get it

    char* day = date;     // scan for the day
    day += 4;
    t.tm_mday = strtol(day, null, 10);  // get it

    char* month = date;   // scan for the month
    month[3] = '\0';
    if ((strcmp("Jan", month) == 0) || (strcmp("jan", month) == 0) ||
        (strcmp("JAN", month) == 0)) t.tm_mon = 0;
    else if ((strcmp("Feb", month) == 0) || (strcmp("feb", month) == 0) ||
        (strcmp("FEB", month) == 0)) t.tm_mon = 1;
    else if ((strcmp("Mar", month) == 0) || (strcmp("mar", month) == 0) ||
        (strcmp("MAR", month) == 0)) t.tm_mon = 2;
    else if ((strcmp("Apr", month) == 0) || (strcmp("apr", month) == 0) ||
        (strcmp("APR", month) == 0)) t.tm_mon = 3;
    else if ((strcmp("May", month) == 0) || (strcmp("may", month) == 0) ||
        (strcmp("MAY", month) == 0)) t.tm_mon = 4;
    else if ((strcmp("Jun", month) == 0) || (strcmp("jun", month) == 0) ||
        (strcmp("JUN", month) == 0)) t.tm_mon = 5; 
    else if ((strcmp("Jul", month) == 0) || (strcmp("jul", month) == 0) ||
        (strcmp("JUL", month) == 0)) t.tm_mon = 6;
    else if ((strcmp("Aug", month) == 0) || (strcmp("aug", month) == 0) ||
        (strcmp("AUG", month) == 0)) t.tm_mon = 7;
    else if ((strcmp("Sep", month) == 0) || (strcmp("sep", month) == 0) ||
        (strcmp("SEP", month) == 0)) t.tm_mon = 8;
    else if ((strcmp("Oct", month) == 0) || (strcmp("oct", month) == 0) ||
        (strcmp("OCT", month) == 0)) t.tm_mon = 9;
    else if ((strcmp("Nov", month) == 0) || (strcmp("nov", month) == 0) ||
        (strcmp("NOV", month) == 0)) t.tm_mon = 10;
    else if ((strcmp("Dec", month) == 0) || (strcmp("dec", month) == 0) ||
        (strcmp("DEC", month) == 0)) t.tm_mon = 11;
    else pw_err(ERR_BAD_DATE);  // bad date format

    t.tm_isdst = 1;
    return (long)(mktime(&t) / SECONDS_WEEK);   // convert it and return
}


/*
CHECK_AGE
  This function tests if the user has allowed the minimum time
  to pass before changing their password.  If the the min_age
  plus the last_changed date is greater than the current date,
  then the user is denied and 0 is returned.  Otherwise 1 is
  returned and the user is allowed to proceed.  Note: all dates
  are represented in weeks.
*/
int Pwd::check_age(char* last_changed, long min_age)
{
    if (last_changed == null) return 1;   // can't do this
    char* curr_date = get_date();         // get the current date
    long last_weeks = convert_to_weeks(last_changed);  // get the weeks
    long curr_weeks = convert_to_weeks(curr_date);     // get the weeks
    if ((convert_to_weeks(last_changed) + min_age) > 
        convert_to_weeks(curr_date)) {                 // Is age OK?
        delete[] curr_date;
        return 0;                                      // no 
    }
    delete[] curr_date;
    return 1;                                          // yes
}


/*
GET_MIN
  This function returns the min password age from the
  pwrestrict age string.
*/
long Pwd::get_min(char* age)
{
    char* min_age = strdup(age);
    char* end = min_age;
    while ((*end != ',') && (*end != '\0')) end++;
    if ((*end == ',') && (end != min_age)) {
        *end = '\0';
        long min = strtol(min_age, null, 10);
        delete[] min_age;
        return min;
    }
    delete[] min_age;
    return -1;
}


/*
GET_MAX
  This function returns the max password age from the
  pwrestrict age string.
*/
long Pwd::get_max(char* age)
{
    char* new_age = strdup(age);
    char* max_age = new_age;
    while ((*max_age != ',') && (*max_age != '\0')) max_age++;
    if (*max_age == ',') {
        max_age++;
        char* end = max_age;
        while ((*end != ',') && (*end != '\0')) end++;
        if ((*end == ',') && (end != max_age)) {
            *end = '\0';
            long max = strtol(max_age, null, 10); 
            delete[] new_age;
            return max;
        }
    }
    delete[] new_age;
    return -1;
}


/*
GET_LAST
  This function returns the date in the password age from the
  pwrestrict age string which specifies when the passowrd
  was last changed.
*/
char* Pwd::get_last(char* age)
{
    char* last_changed = new char[20];
    char* last = age;
    while ((*last != ',') && (*last != '\0')) last++;
    if (*last == ',') {
        last++;
        while ((*last != ',') && (*last != '\0')) last++;
        if (*last == ',') {
            last++;
            char* end = last;
            while (*end != '\0') end++;
            if (end != last) {
                strcpy(last_changed, last);
                return last_changed;
            }
        }
    }
    return null;
}


/*
COPY_NEW_PWF
  This function rewrites a new passwd file updating the changes
  that were made.  The files in question here are determined
  by PASSWD_FILE, TEMP_PASSWD_FILE.  The PASSWD_FILE is parsed line
  by line.  Each line gets written to the TEMP_PASSWD_FILE.  If the
  current line is the one that needs to be changed then the updates
  are made and the new line is written to TEMP_PASSWD_FILE.
  Then the file handle links are swapped in the following manner:
    A new link named OLD_PASSWD_FILE is pointed to PASSWD_FILE.
    The PASSWD_FILE name/link is deleted.
    A new link named PASSWD_FILE is pointed to TEMP_PASSWD_FILE.
    The TEMP_PASSWD_FILE name/link is deleted.
  That's all folks!
*/
void Pwd::copy_new_pwf(passwd* pw_ent)
{
    // IGNORE ALL SIGNALS - don't want a corrupted passwd file
    ignore_signals1();

    int pwf_fd, temp_pfd;
    umask(0);
    // open and lock the TEMP_PASSWD_FILE for writing only
    if ((temp_pfd = open(TEMP_PASSWD_FILE, O_CREAT|O_EXCL|O_WRONLY, PASSWD_MODE)) == -1)
	pw_err(ERR_T_PASS_OPEN);
    // open the PASSWD_FILE for reading only
    if ((pwf_fd = open(PASSWD_FILE, O_RDONLY)) == -1) pw_err(ERR_PASS_OPEN);
    // chown the TEMP_PASSWD_FILE to root.root
    if (fchown(temp_pfd, root_uid, root_gid) == -1) pw_err(ERR_CHOWN_T_PASS);

    fstream input(pwf_fd);         // new input stream for PASSWD_FILE
    fstream output(temp_pfd);      // new output stream for TEMP_PASSWD_FILE
    char buf[MAX_BUF];             // temp buffer space
    while(input.getline(buf, MAX_BUF)) {    // read each line until EOF
	char* temp = buf;
	while (*temp != ':') temp++;        // parse out the login name
	*temp = '\0';
	if (strcmp(pw_ent->pw_name, buf) == 0) {  // if this line is it
	    output << pw_ent->pw_name << ":"      // then write new info
                   << pw_ent->pw_passwd << ":"
                   << pw_ent->pw_uid << ":"
                   << pw_ent->pw_gid << ":"
                   << pw_ent->pw_gecos << ":"
                   << pw_ent->pw_dir << ":"
                   << pw_ent->pw_shell << endl;
	}
	else {                                    // else skip original stuff
	    *temp = ':';
            output << buf << endl;
        }
    }

    // close the PASSWD_FILE
    if (close(pwf_fd) == -1) pw_err(ERR_PASS_CLOSE);
    // close the TEMP_PASSWD_FILE
    if (close(temp_pfd) == -1) pw_err(ERR_T_PASS_CLOSE);
    // create a name OLD_PASSWD_FILE to PASSWD_FILE
    unlink(OLD_PASSWD_FILE);
    if (link(PASSWD_FILE, OLD_PASSWD_FILE) == -1) pw_err(ERR_O_PASS_CRE);
    // deleted the name/link PASSWD_FILE
    if (unlink(PASSWD_FILE) == -1) pw_err(ERR_DEL_PASS);
    // create a new link to TEMP_PASSWD_FILE named PASSWD_FILE
    if (link(TEMP_PASSWD_FILE, PASSWD_FILE) == -1) pw_err(ERR_CRE_PASS);
    // delete the name/link TEMP_PASSWD_FILE
    if (unlink(TEMP_PASSWD_FILE) == -1) pw_err(ERR_DEL_T_PASS);
    // make the passwd database
    mkdb(PASSWD_DB);
}

/*
COPY_NEW_SHF
  This function rewrites a new shadow file updating the changes
  that were made.  The files in question here are determined
  by SHADOW_FILE, TEMP_SHADOW_FILE.  The SHADOW_FILE is parsed line
  by line.  Each line gets written to the TEMP_SHADOW_FILE.  If the
  current line is the one that needs to be changed then the updates
  are made and the new line is written to TEMP_SHADOW_FILE.
  Then the file handle links are swapped in the following manner:
    A new link named OLD_SHADOW_FILE is pointed to SHADOW_FILE.
    The SHADOW_FILE name/link is deleted.
    A new link named SHADOW_FILE is pointed to TEMP_SHADOW_FILE.
    The TEMP_SHADOW_FILE name/link is deleted.
  That's all folks!
*/
void Pwd::copy_new_shf(passwd* sp_ent)
{
    // IGNORE ALL SIGNALS - don't want a corrupted passwd file
    ignore_signals1();
    int shf_fd, temp_pfd, temp_sfd;
    umask(0);
    // create and lock the TEMP_PASSWD_FILE
    if ((temp_pfd = open(TEMP_PASSWD_FILE, O_CREAT|O_EXCL|O_WRONLY, PASSWD_MODE)) == -1)
	pw_err(ERR_T_PASS_OPEN);
    // create and lock the TEMP_SHADOW_FILE file for writing only
    if ((temp_sfd = open(TEMP_SHADOW_FILE, O_CREAT|O_EXCL|O_WRONLY, SHADOW_MODE)) == -1)
        pw_err(ERR_T_SHAD_OPEN);
    // open the SHADOW_FILE for reading only
    if ((shf_fd = open(SHADOW_FILE, O_RDONLY)) == -1) pw_err(ERR_SHAD_OPEN);
    // chown the TEMP_SHADOW_FILE to root.root
    if (fchown(temp_sfd, root_uid, root_gid) == -1) pw_err(ERR_CHOWN_T_SHAD);

    fstream input(shf_fd);     // new input stream for SHADOW_FILE
    fstream output(temp_sfd);  // new output stream for TEMP_SHADOW_FILE
    char buf[MAX_BUF];         // temp buffer space
    while(input.getline(buf, MAX_BUF)) {    // read each line until EOF
	char* temp = buf;
	while (*temp != ':') temp++;        // parse out the login name
	*temp = '\0';
        if (strcmp(sp_ent->pw_name, buf) == 0) {  // if this line is it
	    output << sp_ent->pw_name << ":"      // write new info
                   << sp_ent->pw_passwd << ":"
                   << sp_ent->pw_uid << ":"
                   << sp_ent->pw_gid << ":"
                   << sp_ent->pw_gecos << ":"
                   << sp_ent->pw_dir << ":"
                   << sp_ent->pw_shell << endl;
        }
	else {                                    // else keep original stuff 
	    *temp = ':';
            output << buf << endl;
        }
    }

    // close the SHADOW_FILE
    if (close(shf_fd) == -1) pw_err(ERR_SHAD_CLOSE);
    // close the TEMP_SHADOW_FILE
    if (close(temp_sfd) == -1) pw_err(ERR_T_SHAD_CLOSE);
    // create a named OLD_SHADOW_FILE to SHADOW_FILE
    unlink(OLD_SHADOW_FILE);
    if (link(SHADOW_FILE, OLD_SHADOW_FILE) == -1) pw_err(ERR_O_SHAD_CRE);
    // deleted the name/link SHADOW_FILE
    if (unlink(SHADOW_FILE) == -1) pw_err(ERR_DEL_SHAD);
    // create a new link to TEMP_SHADOW_FILE named SHADOW_FILE
    if (link(TEMP_SHADOW_FILE, SHADOW_FILE) == -1) pw_err(ERR_CRE_SHAD);
    // delete the name/link TEMP_SHADOW_FILE
    if (unlink(TEMP_SHADOW_FILE) == -1) pw_err(ERR_DEL_T_SHAD);
    // close and delete the TEMP_PASS_FILE
    if (close(temp_pfd) == -1) pw_err(ERR_T_PASS_CLOSE);
    if (unlink(TEMP_PASSWD_FILE) == -1) pw_err(ERR_DEL_T_PASS);
    // make the shadow database
    mkdb(SHADOW_DB);
}


/*
COPY_NEW_RSF
  This function rewrites a new shadow file updating the changes
  that were made.  The files in question here are determined
  by RESTRICT_FILE, TEMP_RESTRICT_FILE.  The RESTRICT_FILE is parsed line
  by line.  Each line gets written to the TEMP_RESTRICT_FILE.  If the
  current line is the one that needs to be changed then the updates
  are made and the new line is written to TEMP_RESTRICT_FILE.
  Then the file handle links are swapped in the following manner:
    A new link named TEMP_RESTRICT_FILE is pointed to RESTRICT_FILE.
    The RESTRICT_FILE name/link is deleted.
    A new link named RESTRICT_FILE is pointed to TEMP_RESTRICT_FILE.
    The TEMP_RESTRICT_FILE name/link is deleted.
  That's all folks!
*/
void Pwd::copy_new_rsf(pwrestrict* rs_ent)
{
    // IGNORE ALL SIGNALS - don't want a corrupted restrict file
    ignore_signals1();
    int rest_fd, temp_pfd, temp_rfd;
    umask(0);
    // create and lock the TEMP_PASSWD_FILE
    if ((temp_pfd = open(TEMP_PASSWD_FILE, O_CREAT|O_EXCL|O_WRONLY, PASSWD_MODE)) == -1)
	pw_err(ERR_T_PASS_OPEN);
    // create the TEMP_RESTRICT_FILE file for writing only
    if ((temp_rfd = open(TEMP_RESTRICT_FILE, O_CREAT|O_EXCL|O_WRONLY,
                         RESTRICT_MODE)) == -1)
        pw_err(ERR_T_REST_OPEN);
    // open the RESTRICT_FILE for reading only
    if ((rest_fd = open(RESTRICT_FILE, O_RDWR)) == -1) pw_err(ERR_REST_OPEN);
    // chown the TEMP_RESTRICT_FILE root.root
    if (fchown(temp_rfd, root_uid, root_gid) == -1) pw_err(ERR_CHOWN_T_REST);

    fstream input(rest_fd);        // new input stream for RESTRICT_FILE
    fstream output(temp_rfd);      // new output stream for TEMP_RESTRICT_FILE
    char buf[MAX_BUF];             // temp buffer space
    while(input.getline(buf, MAX_BUF)) {   // read each line until EOF
	char* temp = buf;
	while (*temp != ':') temp++;       // parse out the login name
	*temp = '\0';
	if (strcmp(rs_ent->pwr_name, buf) == 0) {  // if this line is it
            output << rs_ent->pwr_name << ":"      // write new info
                   << rs_ent->pwr_passwd << ":"
                   << rs_ent->pwr_age << ":"
                   << rs_ent->pwr_restrict << ":"
                   << rs_ent->pwr_uid << endl;
	}
	else {                                     // else keep original stuff
	    *temp = ':';
            output << buf << endl;
        }
    }
    // close the RESTRICT_FILE
    if (close(rest_fd) == -1) pw_err(ERR_REST_CLOSE);
    // close the TEMP_RESTRICT_FILE
    if (close(temp_rfd) == -1) pw_err(ERR_T_REST_CLOSE);
    // create a named OLD_RESTRICT_FILE to RESTRICT_FILE
    unlink(OLD_RESTRICT_FILE);
    if (link(RESTRICT_FILE, OLD_RESTRICT_FILE) == -1) pw_err(ERR_O_REST_CRE);
    // deleted the name/link RESTRICT_FILE
    if (unlink(RESTRICT_FILE) == -1) pw_err(ERR_DEL_REST);
    // create a new link to TEMP_RESTRICT_FILE named RESTRICT_FILE
    if (link(TEMP_RESTRICT_FILE, RESTRICT_FILE) == -1) pw_err(ERR_CRE_REST);
    // delete the name/link TEMP_RESTRICT_FILE
    if (unlink(TEMP_RESTRICT_FILE) == -1) pw_err(ERR_DEL_T_REST);
    // make the pwrestrict database
    // close and delete the TEMP_PASSWD_FILE
    if (close(temp_pfd) == -1) pw_err(ERR_T_PASS_CLOSE);
    if (unlink(TEMP_PASSWD_FILE) == -1) pw_err(ERR_DEL_T_PASS);
    mkdb(RESTRICT_DB);
}


/*
PRINT_USER_INFO
  This function prints out the passwd entry info specified
  in the argument pw_ent.
*/
void Pwd::print_user_info(passwd* pw_ent)
{
    cout.flags(ios::left);
    cout.width(12); cout << pw_ent->pw_name;
    cout.width(5);
        if (*pw_ent->pw_passwd == '\0') cout << "NP";
        else if ((strcmp(pw_ent->pw_passwd, LOCK_STRING1) == 0) ||
                 (strcmp(pw_ent->pw_passwd, LOCK_STRING2) == 0)) cout << "LK";
        else cout << "PS";
    cout.width(10); cout << pw_ent->pw_uid;
    cout.width(10); cout << pw_ent->pw_gid;
    cout.width(20); cout << pw_ent->pw_dir;
    cout.width(0); cout << pw_ent->pw_shell << endl;
}


/*
CONSTRUCTOR
  This is a constructor for class Pwd.
*/
Pwd::Pwd() : Pwd_Common()
{
    max_age = min_age = 0;
}


/*
CONSTRUCTOR
  This is a constructor for class Pwd.
*/
Pwd::Pwd(char* name, char* crypt, long max, long min) : Pwd_Common(name, crypt)
{
    max_age = max;
    min_age = min;
}


/*
DESTRUCTOR
  This is the destructor for class Pwd.
*/
Pwd::~Pwd()
{
    max_age = min_age = -1;
}


/*
SHADOW_EXISTS
  This function returns 1 if shadow passwds are being used and
  0 otherwise.
*/
int Pwd::shadow_exists()
{
    struct stat stat_buf;
    if (stat(SHADOW_FILE, &stat_buf) == 0) return 1;
    else return 0;
}


/*
RESTRICT_EXISTS
  This function returns 1 if the pwrestrict file is being used and
  0 otherwise.
*/
int Pwd::restrict_exists()
{
    struct stat stat_buf;
    if (stat(RESTRICT_FILE, &stat_buf) == 0) return 1;
    else return 0;
}


/*
UPDATE_RESTRICT
  This function updates the pwrestrict password ages and
  rewrites the new pwrestrict file.
*/
void Pwd::update_restrict(uid_t user_uid, char* user, char* passwd)
{
    char* new_age = new char[40];
    pwrestrict* rs_ent = getpwrestnam(user);
    if (rs_ent == null) {
        cout << "ERROR: Could not retrieve restrict entry for '"
             << user << "'." << endl;
        pw_err(ERR_GET_REST);
    }
    long min_age = get_min(rs_ent->pwr_age);
    long max_age = get_max(rs_ent->pwr_age);
    if ((min_age > max_age) && chkroot(user_uid)) strcpy(new_age, ",,");
    else if ((min_age == 0) && (max_age == 0)) strcpy(new_age, ",,");
    else strcpy(new_age, rs_ent->pwr_age);
    char* temp = new_age;
    while (*temp != ',') temp++;
    temp++;
    while (*temp != ',') temp++;
    temp++;
    *temp = '\0';
    char* curr_date = get_date();
    strcat(new_age, curr_date);    // this will always copy 12 chars
    delete[] curr_date;
    rs_ent->pwr_age = new_age;
    if (!shadow_exists()) {
        bzero(rs_ent->pwr_passwd, strlen(rs_ent->pwr_passwd));
        rs_ent->pwr_passwd = passwd;
    }
    copy_new_rsf(rs_ent);
    delete[] new_age;
}


/*
CHANGE_PASSWORD
  This function does all the dirty work in changing a password.
*/
void Pwd::change_password(uid_t user_uid, uid_t change_uid, int security_hole)
{
    passwd* pw_ent = getpwuid(change_uid);     // get user entry
    if (pw_ent == null) {
        cout << "ERROR: Could not retrieve password entry for UID '"
             << change_uid << "'." << endl;
        pw_err(ERR_GET_PASS);
    }
    cout << "Changing password for " << pw_ent->pw_name << endl;
    if (restrict_exists()) {
        pwrestrict* rs_ent = getpwrestnam(pw_ent->pw_name); // get restrict
        if (rs_ent == null) {
            cout << "ERROR: Could not retrieve restrict entry for '"
                 << pw_ent->pw_name << "'." << endl;
            pw_err(ERR_GET_REST);
        }
	// remember that if min is set then so is max
	// if min is greater than max then only root can change the passwd
        long min_age = get_min(rs_ent->pwr_age);
        long max_age = get_max(rs_ent->pwr_age);
        // check for root only change
        if ((min_age != -1) && (max_age != -1) && (min_age > max_age) &&
            !chkroot(user_uid)) pw_err(ERR_ROOT_ONLY);
        // check for date last changed
        if ((min_age != -1) || (min_age != 0)) {
            char* last_changed = get_last(rs_ent->pwr_age);
	    // check that the minimum age has passed since last change
            if (!check_age(last_changed, min_age)) {
                cout << "Sorry: It has been less than " << min_age
                     << " weeks since last change." << endl;
                delete[] last_changed;
                pw_err(ERR_AGE);
            }
            delete[] last_changed;
        }
    }
    // get the new password from the user
    char* new_crypt_password = get_new_password(pw_ent->pw_passwd, pw_ent->pw_name, user_uid, security_hole);
    if (new_crypt_password != null) { // Password was successfully changed!     
        bzero(pw_ent->pw_passwd, strlen(pw_ent->pw_passwd)); // wipe out memory
        pw_ent->pw_passwd = new_crypt_password;              // set new passwd
        if (shadow_exists()) copy_new_shf(pw_ent); // rewrite shadow file
        else copy_new_pwf(pw_ent);                 // or rewrite passwd file
        // if min > max and root is changing then turn off aging here
	// aging is update in the pwrestrict file
        update_restrict(user_uid, pw_ent->pw_name, new_crypt_password);
    }
    else {
        // The moron could not enter in a decent password or their own!
        cout << "Password not changed, try again later." << endl;
	exit(ERR_UNCHANGED);
    }
}


/*
PRINT_INFO_NAME
  This function prints out the passwd entry information for a user.
  If the argument user_name is null then all user entries are printed.
  else just user_name is printed.
*/
void Pwd::print_info_name(char* user_name)
{
    if (user_name != null) {   // print out user_name only
        passwd* pw_ent = getpwnam(user_name);    // get user entry
        if (pw_ent == null) {
            cout << "ERROR: Could not retrieve password entry for '"
	         << user_name << "'." << endl;
            pw_err(ERR_GET_PASS);
        }
        print_user_info(pw_ent);   // print it out
    }
    else {
        passwd* pw_ent;
	// for each user in the passwd file print the info
        while ((pw_ent = getpwent()) != null) print_user_info(pw_ent);  
    }
}


/*
PRINT_INFO_UID                                                
  This function prints out the passwd entry information for a user.
*/
void Pwd::print_info_uid(uid_t uid)
{                                                             
    passwd* pw_ent = getpwuid(uid);  // get user entry        
    if (pw_ent == null) {                                     
        cout << "ERROR: Could not retrieve password entry for uid '"
             << uid << "'." << endl;                          
        pw_err(ERR_GET_PASS);                                 
    }                                                         
    print_user_info(pw_ent);   // print it out                
}                                                             


/*
FORCE_USER
  This function forces the user to change their passwd the next time
  they login.
*/
void Pwd::force_user()
{
    if (restrict_exists()) {   // if pwrestrict is being used
        pwrestrict* rs_ent = getpwrestnam(login_name);  // get user entry
        if (rs_ent == null) {
            cout << "ERROR: Could not retrieve restrict entry for '"
                 << login_name << "'." << endl;
            pw_err(ERR_GET_REST);
        }
        rs_ent->pwr_age = FORCE_STRING;   // reset age
        copy_new_rsf(rs_ent);             // rewrite the new passwd file
    }
    else {
        // restrict file is not being used - no aging
        cout << "The /etc/pwrestrict file does not exist." << endl;
    }
}


/*
LOCK_USER
  This function locks the user out of their account by '*'ing the passwd.
*/
void Pwd::lock_user()
{
    if (restrict_exists()) {  // if pwrestrict is being used
        pwrestrict* rs_ent = getpwrestnam(login_name);  // get user entry
        if (rs_ent == null) {
            cout << "ERROR: Could not retrieve restrict entry for '"
                 << login_name << "'." << endl;
            pw_err(ERR_GET_REST);
        }
        bzero(rs_ent->pwr_passwd, strlen(rs_ent->pwr_passwd)); // wipe memory
        rs_ent->pwr_passwd = LOCK_STRING1;              // lock passwd
        copy_new_rsf(rs_ent);                           // rewrite restrict
    }
    passwd* pw_ent = getpwnam(login_name);    // get user entry
    if (pw_ent == null) {
        cout << "ERROR: Could not retrieve password entry for '"
             << login_name << "'." << endl;
        pw_err(ERR_GET_PASS);
    }
    bzero(pw_ent->pw_passwd, strlen(pw_ent->pw_passwd));   // wipe out memory
    pw_ent->pw_passwd = LOCK_STRING1;                      // lock passwd
    if (shadow_exists()) copy_new_shf(pw_ent);             // rewrite shadow
    else copy_new_pwf(pw_ent);                             // of rewrite passwd
}


/*
CRYPT_USER
  This function inserts a new encrypted password for the user.
*/
void Pwd::crypt_user()
{
    // the length of the encrypted passwd must be valid
    if (!chkcryptlength()) pw_err(ERR_CRYPT_LENGTH);
    // all characters must be valid in the encrypted passwd
    if (!chkcrypt()) pw_err(ERR_CRYPT_CHAR);
    if (restrict_exists()) {     // if pwrestrict is being used
        pwrestrict* rs_ent = getpwrestnam(login_name);  // get user entry
        if (rs_ent == null) {
            cout << "ERROR: Could not retrieve restrict entry for '"
                 << login_name << "'." << endl;
            pw_err(ERR_GET_REST);
        }
        bzero(rs_ent->pwr_passwd, strlen(rs_ent->pwr_passwd)); // wipe memory
        rs_ent->pwr_passwd = crypt_pw;         // set new passwd
        copy_new_rsf(rs_ent);                  // rewrite pwrestrict
    }
    passwd* pw_ent = getpwnam(login_name);     // get user entry
    if (pw_ent == null) {
        cout << "ERROR: Could not retrieve password entry for '"
             << login_name << "'." << endl;
        pw_err(ERR_GET_PASS);
    }
    bzero(pw_ent->pw_passwd, strlen(pw_ent->pw_passwd));  // wipe out memory
    pw_ent->pw_passwd = crypt_pw;                // set new passwd
    if (shadow_exists()) copy_new_shf(pw_ent);   // rewrite new shadow
    else copy_new_pwf(pw_ent);                   // or rewrite new passwd
}


/*
SET_AGE
  This function sets the new age for the user.
*/
void Pwd::set_age(short flags, short x_bit, short n_bit)
{
    // We know that the x_bit must be set to enter this function
    // We know that the n_bit can only be set if the x_bit is set
    // if max_age is less than 0 then turn off aging for login_name
    // if min_age > max_age then only root can change the password
    // if min_age = max_age = 0 the user is forced to changed their password
    // min_age must be greater 0 (0 is the default)
    if ((max_age <= 0) && (max_age != -1)) pw_err(ERR_MAX_DAYS);
    else if ((max_age != -1) && (n_bit & flags) && (min_age < 0))
        pw_err(ERR_MIN_DAYS);

    if (restrict_exists()) {   // if pwrestrict is being used
        pwrestrict* rs_ent = getpwrestnam(login_name);  // get user entry
        if (rs_ent == null) {
            cout << "ERROR: Could not retrieve restrict entry for '"
                 << login_name << "'." << endl;
            pw_err(ERR_GET_REST);
        }
        char* new_age = new char[MAX_BUF];    // temp buffer space
        ostrstream ostr(new_age, MAX_BUF);    // new string stream
        if (max_age == -1) {                  // turn off aging
            cout << "Turning off aging for " << login_name
                 << "." << endl;
            rs_ent->pwr_age = NO_AGE;         // turn it off
        }
        else {                       // set the age as specified
            // make sure the age field is always ':x,x,x:'
	    // write to the string stream for conversion from number
            if (n_bit & flags) ostr << min_age;
            else ostr << 0;
            ostr << ",";
            ostr << max_age;
            ostr << ",";
            char* temp = rs_ent->pwr_age;
            while ((*temp != ',') && (*temp != '\0')) temp++;
            if (*temp == ',') {
                temp++;
                while ((*temp != ',') && (*temp != '\0')) temp++;
                if (*temp == ',') {
                   temp++;
                   ostr << temp;    // copy date last changed
                }
            }
            rs_ent->pwr_age = new_age;    // get the new age
        }
        copy_new_rsf(rs_ent);       // rewrite pwrestrict
        delete[] new_age;
    }
    else {
        // /etc/restrict file is not being used - no aging
        cout << "The /etc/pwrestrict file does not exist." << endl;
    }
}

