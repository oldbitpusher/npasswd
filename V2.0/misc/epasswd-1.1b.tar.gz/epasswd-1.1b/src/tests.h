
/******************************

  TESTS.H
  Written by: Eric Allen Davis
              Numerical Aerospace Simulation Facility
	      NASA Ames Research Center


The following constants are defined in the Makefile and 
passwd to tests.cc during compile time:

MIN_PASSWORD_LENGTH - min number of characters allowed
MAX_PASSWORD_LENGTH - max number of characters allowed
MIN_CHARS_UCASE - min number of upper case characters allowed, if it 
  is set to 0 then the case is ignored
MIN_CHARS_LCASE - min number of lower case characters allowed, if it
  is set to 0 then the case is ignored
MIN_CHARS_NUM - min number of numeric characters allowed, if it is
  set to 0 then the case is ignored
MIN_CHARS_SPEC - min number of special characters allowed, if it is
  set to 0 then the case is ignored
MIN_CASES_PASS - min number of test case that must be passed, these
  tests involve upper case, lower case, numeric, and special characters
  the Makefile enforces that MIN_CASES_PASS not be greater than
  MIN_CHARS_UCASE+MIN_CHARS_LCASE+MIN_CHARS_NUM+MIN_CHARS_SPEC
NUM_DIFF_CHARS - min number of characters that must differ between
  the old and new passwords
NUM_MIDDLE - If set to 1 then a numeric char must exist in the middle of 
  the password
SPEC_MIDDLE - If set to 1 then a special char must exist in the middle of
  the password
UCASE_MIDDLE - If set to 1 then an upper case char must exist in the middle
  of the password

** PRIVATE MEMBERS:
char* old_password - 
  This string holds the old un-encrypted password.
char* new_password - 
  This string holds the new un-encrypted password.
char* user_name - 
  This string holds the login name of the user whos
  password is going to be changed.
uid_t root_uid - 
  This uid_t holds the uid of the system's super-user.
uid_t user_uid - 
  This uid_t holds the uid of the user whos password
  is going to be changed.

** PROTECTED MEMBERS:
int chkupper(char* string, int min) - 
  This function ensures that there are at least min upper case
  characters in the string.
int chklower(char* string, int min) - 
  This function ensures that there are at least min lower case
  characters in the string.
int chknum(char* string, int min) - 
  This function ensures that there are at least min numeric
  characters in the string.
int chkspec(char* string, int min) - 
  This function ensures that there are at least min special case
  characters in the string.
int cmpstr(char* string1, char* string2) - 
  This function ensures that the two strings are not equal.  This
  is different from 'strcmp' in that upper and lower case characters
  are considered equivalent.
int chklogin(char* login, char* pass) - 
  This function ensures that the all circular shifts of the login
  name are not used as the password.
int chkdiff(char* string1, char* string2, int min) - 
  This function ensures that the two strings are different by
  at lease min characters.
void revstring(char* string) - 
  This function simply reverses all the characters in the string.

** PUBLIC MEMBERS:
Test()
  This is the constructor for class Test.
Test(char* old_pw, char* new_pw, char* name, uid_t root, uid_t user)
  This is another constructor for class Test.
~Test()
  This is the destructor for class Test.
int do_tests()
  This function performs all necessary password requirement tests.
  The private data members hold the password and all information
  needed to perform these tests.

*/


#ifndef TEST_CLASS
#define TEST_CLASS

#include <sys/types.h>

class Test
{
private:

    char* old_password;
    char* new_password;
    char* user_name;
    uid_t root_uid;
    uid_t user_uid;

protected:

    int chkupper(char* string, int min);
    int chklower(char* string, int min);
    int chknum(char* string, int min);
    int chkspec(char* string, int min);
    int cmpstr(char* string1, char* string2);
    int chklogin(char* login, char* pass);
    int chkdiff(char* string1, char* string2, int min);
    void revstring(char* string);

public:

    Test();
    Test(char* old_pw, char* new_pw, char* name, uid_t root, uid_t user);
    ~Test();
    int do_tests();

};

#endif

