

#define CPU_VENDOR_OS		"sparc-Solaris"
#define HAVE_PTHREAD_H		1
#define HAVE_STRINGS_H		1
#define HAVE_SYS_FILIO_H	1
#define HAVE_SYS_IOCTL_H	1
#define HAVE_SYS_SELECT_H	1
#define HAVE_SYS_SOCKIO_H	1
#define HAVE_SYS_SYSCTL_H	1
#define HAVE_SYS_TIME_H		1

#define TIME_WITH_SYS_TIME	1

#define HAVE_BZERO		1
#define HAVE_GETHOSTBYNAME2	1
#define HAVE_VSNPRINTF		1

#define HAVE_GETHOSTNAME_PROTO	1
#define HAVE_GETUSAGE_PROTO	1
#define HAVE_HSTRERROR_PROTO	1

#define HAVE_INET_ATON_PROTO	1
#define HAVE_INET_PTON_PROTO	1

#define HAVE_SNPRINTF_PROTO	1

#define HAVE_SOCKADDR_DL_STRUCT	1
#define HAVE_TIMESPEC_STRUCT	1

#define HAVE_SOCKADDR_SA_TCP	1
#define HAVE_MSGHDR_MSG_CONTROL	1

/*

#define uint8_t		unsigned char
#define uint16_t	unsigned short
#define uint32_t	unsigned int


#define socklen_t	unsigned int
#define sa_family_t	SA_FAMILY_T
#define SA_FAMILY_T	uint8_t

#define t_scalar_t	int32_t
#define t_uscalar_t	uint32_t

#define IPV4		1
#define IPv4		1

#define UNIXDOMAIN	1
#define UNIXdomain	1
#define MCAST		1
*/

/* END */
