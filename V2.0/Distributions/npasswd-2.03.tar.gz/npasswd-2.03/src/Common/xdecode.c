/*
 *	xdecode - Routines for interperting strings
 */

#ifndef lint
static char sccsid[] = "@(#)xdecode.c	1.1 08/07/96 (cc.utexas.edu)";
#endif

#include "compatibility.h"

int	decode_boolean _((char *));
int	decode_int _((char *));
void	decode_string _((char *, char *, int));

/*
 *	decode_boolean - decode a boolean value
 */
int
decode_boolean(s)
	char	*s;
{
	return(*s == '1'
		| (strcasecmp(s, "true") == 0)
		| (strcasecmp(s, "yes") == 0)
		| (strcasecmp(s, "on") == 0));
}

/*
 *	decode_int - decode an integer value
 */
int
decode_int(s)
	char	*s;	/* String to decode */
{
	int	t;	/* Temp */

	if (xatoi(s, (char *)0, &t))
		return(t);
	return(-1);
}

/*
 * decode_string - copy string, converting backslash escapes
 *	Can handle most C backslash escape sequences
 */
void
decode_string(dst, src, len)
	char	*dst,		/* Destination */
		*src;		/* Source */
	int	len;		/* sizeof Destination */
{
	int	t;		/* Temp */
	char	*dstx = dst;	/* Pointer to start of destination */
	char	quote = 0;	/* Quote character */

	if (*src == '"' || *src == '\'')
		quote = *src++;

#define	putxchar(P) *dst++ = (P)
	for (; *src && (dst - dstx) < len; ) {
		if (*src == '\\') {
			src++;
			switch(*src) {
			case 'a':	putxchar('\007'); src++; break;
			case 'b':	putxchar('\b'); src++; break;
			case 'f':	putxchar('\f'); src++; break;
			case 'n':	putxchar('\n'); src++; break;
			case 'r':	putxchar('\r'); src++; break;
			case 't':	putxchar('\t'); src++; break;
			case '\\':	putxchar('\\'); src++; break;
			case '0': case '1': case '2': case '3':
			case '4': case '5': case '6': case '7':
			case 'x':
				if (xatoi(src, &src, &t))
					putxchar(t & 0xff);
				break;
			default:
				if (quote && *src == quote)
					*dst++ = *src++;
				break;
			}
			continue;
		}
		if (*src == '^') {	/* ^C = control-c */
			src++;
			if (isupper(*src))
				putxchar(*src - '@');
			else if (islower(*src))
				putxchar(*src - '`');
			else switch (*src) {
			     case '[':	putxchar('\033'); break;
			     case '\\':	putxchar('\034'); break;
			     case ']':	putxchar('\035'); break;
			     case '^':	putxchar('\036'); break;
			     case '-':	putxchar('\037'); break;
			}
			src++;
			continue;
		}
		if (quote && *src == quote)
			break;
		*dst++ = *src++;
	}
#undef	putxchar
	*dst = 0;
}
/*
 * End xdecode.c
 */
