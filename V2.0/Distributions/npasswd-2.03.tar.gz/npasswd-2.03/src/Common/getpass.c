/*
 *	This program duplicates the manual page behavior of the 4.XBSD
 *	passwd(1) command.  It can be configured for use with a variety
 *	of passwd systems (/etc/passwd, /etc/shadow, databases).
 */

#include "npasswd.h"
#include "pw_svc.h"

#ifndef lint
static char sccsid[] = "@(#)getpass.c	1.4 08/17/98 (cc.utexas.edu) /usr/share/src/private/ut/share/bin/passwd/V2.0/src/Common/SCCS/s.getpass.c";
#endif

/*
 * Configuration settings
 */
Config_Value int		PasswdMatchTries = PASSWORD_MATCH_TRIES;
Config_Value unsigned int	PasswdMatchWait = PASSWORD_MATCH_WAIT;

/*
 *	get_password -- read password and check against current.
 */
public void
get_password(prompt, pwd_crypt, pwd_plain, pwlen)
	char	*prompt,
		*pwd_crypt;	/* Present password (encrypted) */
	char	*pwd_plain;	/* Present password (plain)  */
	int	pwlen;		/* Length of present password buffer */
{
	int	ntries = 0;	/* Match attempt counter */
	int	doit = 1;
	char	*px;		/* Temp */
	unsigned int naptime = PasswdMatchWait;	/* Sleep after bad entry */

	while (doit) {
		if ((px = np_getpass(prompt)) == NULL)
			die("Password unmatched.\n");
		if (*px == '\0')
			continue;
		if (!password_cmp(pwd_crypt, px)) {
			printf("Password incorrect.\n");
			if (naptime)
				sleep(naptime);
			if (ntries++ == PasswdMatchTries) {
				if (naptime)
					sleep(naptime);
				die("Password not matched.\n");
			}
			continue;
		}
		doit = 0;
	}
	(void) strncpy(pwd_plain, px, pwlen);
}

/*
 *	password_cmp - compare old and new passwords
 *
 *	Returns 1 if check = new, 0 if not
 */
public 
password_cmp(current, check)
	char	*current,
		*check;
{
	struct pw_svc	*svc = get_pwsvc();

	if (!*current)
		return(1);

	return (strcmp(current, (*svc->PasswdCrypt)(check, current)) == 0);
}

/*
 * Terminal handling code.
 *
 * The following methods are supported:
 *	termios via POSIX tc[gs]attr() routines
 *	termios via TCGETS/TCSETS
 *	termio via TCGETA/TCSETA
 *	V7 sgtty
 *
 * Configure will set only *one* of the symbols used,  so that
 * termios takes precedence over termio which suprecedes sgtty..
 *
 * This is a bloody damn mess - probably the next revision
 * will toss most of these options and only support termios
 */
#ifdef	I_TERMIOS
/*
 * Has TERMIOS
 */
# include <termios.h>
static struct termios saved_tty_mode;
# define	TTY_SAVE	termios
# define	ECHO_OFF(_b_)		_b_.c_lflag =~ ECHO
# define	ECHO_ON(_b_)		_b_.c_lflag =| ECHO
# ifdef	HAS_POSIX_TTY
#  define	GET_TTY(_fd_, _b_)	tcgetattr(_fd_, (_b_))
#  define	SET_TTY(_fd_, _b_)	tcsetattr(_fd_, TCSANOW, (_b_))
# else
#  define	GET_TTY(_fd_, _b_)	ioctl(_fd_, TCGETS, (_b_))
#  define	SET_TTY(_fd_, _b_)	ioctl(_fd_, TCSETS, (_b_))
# endif	/* HAS_POSIX_TTY */
#endif	/* I_TERMIOS */

#if	(defined(I_TERMIO) && !defined(GET_TTY))
/*
 * Has TERMIO
 */
#include <sys/termio.h>		/* SUN OS 4.0 termio */
static struct termio saved_tty_mode;
# define	TTY_SAVE	termio
# define	ECHO_OFF(_b_)		_b_.c_lflag =~ ECHO
# define	ECHO_ON(_b_)		_b_.c_lflag =| ECHO
# define	GET_TTY(_fd_, _b_)	ioctl(_fd_, TCGETA, (_b_))
# define	SET_TTY(_fd_, _b_)	ioctl(_fd_, TCSETA, (_b_))
#endif	/* I_TERMIO */

/*
 * Neither TERMIOS or TERMIO - use BSD sgtty
 */
#if	(defined(I_SGTTY) && !defined(GET_TTY))
# include <sgtty.h>		/* BSD tty */
# define	TTY_SAVE	sgttyb
# define	ECHO_OFF(_b_)		_b_.sg_flags =~ ECHO
# define	ECHO_ON(_b_)		_b_.sg_flags =| ECHO
# define	GET_TTY(_fd_, _b_)	ioctl(_fd_, TIOCGETP, (_b_))
# define	SET_TTY(_fd_, _b_)	ioctl(_fd_, TIOCSETP, (_b_))
#endif	/* I_SGTTY */

#ifndef	GET_TTY
/* # ifdef _STDC_ */
/* #	error Cannot figure out how to do tty stuff */
/* # endif */
	ERROR Cannot figure out how to do tty stuff
#endif

static struct {
	char		valid;
	struct TTY_SAVE mode;
} tty_save = { 0 };

/*
 * savetty
 *	Save terminal settings
 * Usage:
 *	savetty();
 * Effects:
 *	Stores terminal mode in the "tty_save" structure for
 *	restoration by fixtty()
 */
public void
savetty()
{
	(void) GET_TTY(0, &tty_save.mode);
	tty_save.valid++;
}

/*
 * fixtty
 *	Restore saved terminal settings
 * Usage:
 *	fixtty()
 * Effects:
 *	Changes terminal settings from the "tty_save" structure
 *	if that data is valid
 */
public void
fixtty()
{
	if (tty_save.valid)
		(void) SET_TTY(0, &tty_save.mode);
}

/*
 * np_getpass
 *	Replacement for libc getpass(3)
 * Usage:
 *	pass = np_getpass(prompt);
 * Returns:
 *	Password string
 *	NULL if EOF encountered or error
 * Comments:
 *	This routine is used instead of getpass(3):
 *
 *	1. The system getpass() throws away all but the first 8 characters
 *	   of a password string.  On some systems passwords can be longer
 *	   than 8, but getpass(3) hasn't caught up yet.
 *
 *	2. getpass(3) returns a empty string if the user input was empty
 *	   (blank line), or the /dev/tty read got an EOF or error.
 *	   There *is* a difference between those conditions and I really
 *	   want to know it and behave accordingly.  Why make a user
 *	   start over again if they hit RETURN one time too many?
 *
 *	3. The SunOS 4 getpass(3) returns an empty string if the user
 *	   sent a SIGNIT (control-c).  This is stupid behavior.
 *
 *	This code assumes that stdin is the terminal (which has been
 *	verified upstream), so /dev/tty is NOT used.
 *	Signals are caught and terminal modes reset upstream.
 */
public char	*
np_getpass(prompt)
char	*prompt;
{
	struct TTY_SAVE	saved,
			noecho;
	struct sigblk	blocked;
	static char	ib[64];		/* Input buffer */
	int	nr;

	if (!XSwitches[Xsw_UseStdin]) {
		(void) GET_TTY(0, &saved);
		noecho = saved;
		ECHO_OFF(noecho);
		(void) write(2, prompt, strlen(prompt));
		(void) SET_TTY(0, &noecho);
		block_signals(&blocked, SIGTSTP, 0);
	}
	ib[0] = 0;
	nr = read(0, ib, sizeof(ib));
	if (!XSwitches[Xsw_UseStdin]) {
		SET_TTY(0, &saved);
		unblock_signals(&blocked);
	}
	(void) write(2, "\n", 1);
	if (nr <= 0)		/* EOF or error */
		return(NULL);
	chop_nl(ib);
	return(ib);
}

/* End getpass.c */
