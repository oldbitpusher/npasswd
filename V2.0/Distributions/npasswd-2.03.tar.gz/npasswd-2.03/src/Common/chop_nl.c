/*
 * chop_nl
 *	Replace newline with null character
 * Usage
 *	(void) chop_nl(string);
 */

#include "compatibility.h"

#ifndef lint
static char sccsid[] = "@(#)chop_nl.c	1.2 08/13/96 (cc.utexas.edu) /usr/share/src/private/ut/share/bin/passwd/V2.0/src/Common/SCCS/s.chop_nl.c";
#endif

/*
 *	chop_nl - Chop off (first) newline in string
 */
void
chop_nl(str)
	char	*str;
{
	char	*nl;	/* Temp */

	if (nl = strchr(str, '\n'))
		*nl = 0;
}
/* End chop_nl.c */
