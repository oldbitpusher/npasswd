/*
 *	checkpasswd.c - Password checking library entry point
 */

#ifndef lint
static char sccsid[] = "@(#)xatoi.c	1.1 08/07/96 (cc.utexas.edu)";
#endif

#include "compatibility.h"

/*
 *	Is argument an octal digit?
 */
static int
octdigit(c)
	char	c;
{
	if (!isdigit(c)) return(0);
	switch (c) {
		case '8':
		case '9': return(0);
	}
	return(1);
}

/*
 *	Is argument a decimal digit?
 */
static int
decdigit(c)
	char	c;
{
	return (isdigit(c));
}

/*
 *	Is argument a hexidecimal digit?
 */
static int
hexdigit(c)
	char	c;
{
#ifdef	HAS_ISXDIGIT
	return (isxdigit(c));
#else
	return (decdigit(c) |
		(c >= 'a' &&  c <= 'f') |
		(c >= 'A' && c <= 'F'));
#endif
}

/*
 *	xatoi - Smart 'atoi' recognizes decimal, octal and hex constants
 */
xatoi(ip, ipp, iv)
	char	*ip,	/* Pointer to number string */
		**ipp;	/* Stash pointer to end of string */ /* RETURN VALUE */
	int	*iv;	/* RETURN VALUE */
{
	int	(*func)() = decdigit,	/* Function to check char */
		base = 10;		/* Conversion base */
	int	t = 0,			/* Return value */
		mult = 1;		/* Sign of result */
	char	*fcc = ip;		/* First char position */

	if (*ip == '-') {		/* Negative number? */
		ip++;
		mult = -1;
	}
	if (*ip == '0') { 	/* Leading '0'? */
		ip++;
		if (*ip == 'x' || *ip == 'X') {	/* Hex */
			base = 16;
			func = hexdigit;
			ip++;
		}
		else {
			base = 8;		/* Octal */
			func = octdigit;
		}
	}
	while (*ip && (*func)(*ip)) {
		t *= base;
		if (decdigit(*ip))
			t += (*ip - '0');
		else
			t += (*ip >= 'a' ? *ip - 0x57 : *ip - 0x37);
		ip++;
	}
	if (ip == fcc)		/* Nothing processed */
		return(0);
	if (ipp)		/* Stash new pointer location */
		*ipp = ip;
	*iv = (t * mult);
	return(1);
}
/*
 * End xatoi.c
 */
