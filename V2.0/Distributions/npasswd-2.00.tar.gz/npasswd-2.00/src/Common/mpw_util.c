/*
 * npasswd module mpw_util.c
 *
 * Compliation: cc -c mpw_util.c
 * Includes: npasswd.h
 */

#include "npasswd.h"

#ifndef lint
static char sccsid[] = "@(#)mpw_util.c	1.5 04/30/98 (cc.utexas.edu) /usr/share/src/private/ut/share/bin/passwd/V2.0/src/Common/SCCS/s.mpw_util.c";
#endif

/*
 * copympwent - Make a copy of a meta-passwd structure
 *
 * Usage:
 *	new_mpw = copy_mpwent(struct mpassswd *original);
 * Returns:
 *	Pointer to a unique copy of <original> 
 */
struct mpasswd *
copympwent(donor, new)
	struct mpasswd	*donor;
	struct mpasswd	*new;
{
	if (new == 0) {
		new = calloc(sizeof(struct mpasswd), 1);
		if (new == 0)
			logdie("Cannot allocate memory to clone user\n");
	}
	*new = *donor;
	(void) copypwent(&donor->pw, &new->pw);
	new->pws_name = strdup(donor->pws_name);
	new->pws_loc = strdup(donor->pws_loc);
	return(new);
}

/*
 * 	printmpwent - Dump contents of mpasswd structure
 */
public void
printmpwent(theUser)
	struct mpasswd *theUser;
{
#define	STRX(_Z_) (_Z_ ? _Z_ : "(null)")
	printf("mpw_name = %s\n", STRX(theUser->mpw_name));
	printf("mpw_passwd = %s\n", STRX(theUser->mpw_passwd));
	printf("mpw_uid = %u\n", theUser->mpw_uid);
	printf("mpw_gid = %u\n", theUser->mpw_gid);
	printf("mpw_gecos = %s\n", STRX(theUser->mpw_gecos));
	printf("mpw_shell = %s\n", STRX(theUser->mpw_shell));
	printf("mpw_dir = %s\n", STRX(theUser->mpw_dir));
#ifdef	PWAGE
	printf("mpw_age = %s\n", STRX(theUser->mpw_age));
#endif
	printf("last_change = %u\n", theUser->pwage.last_change);
	printf("min_time = %u\n", theUser->pwage.can_change);
	printf("max_time = %u\n", theUser->pwage.must_change);
	printf("key = %s\n", STRX(theUser->key));
	printf("password = %s\n", STRX(theUser->password));
	printf("where = %s\n", STRX(theUser->pws_loc));
	printf("what = %s\n", STRX(theUser->pws_name));
	printf("remote = %u\n", theUser->pws_remote);
	printf("opaque = %x\n", theUser->opaque);
#undef	STRZ
}

/* End mpw_util.c */
