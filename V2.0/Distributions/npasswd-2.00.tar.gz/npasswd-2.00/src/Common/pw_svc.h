/*
 *	Defines for using get_svc_conf()
 *
 *	@(#)pw_svc.h	1.6 07/09/98 (cc.utexas.edu)
 */
#ifndef	pw_svc_h
#define	pw_svc_h 1

#define	N_SVC	32		/* How many services in list */

/*
 * Security level names
 */
enum svc_security {		/* System security level */
	sec_std = 0,
	sec_u4upgrade,		/* Ultrix 4 'upgrade' */
	sec_u4enhanced,		/* Ultrix 4 'enhanced' */
	sec_sunC2,		/* SunOS 4 C2 security */
	sec_OSFenhanced,	/* Digital UNIX (OSF/1) enhanced */
	sec_HPtrusted		/* HP/UX trusted system */
};

/*
 * Database service names
 */
enum svc_services {
	srv_local,		/* Local file */
	srv_yp,			/* NIS map */
	srv_nisplus,		/* NIS+ table */
	srv_kerb,		/* Kerberos */
	srv_unknown,		/* Whatever's left */
	srv_last = 99		/* List end marker */
};

/*
 * Data returned
 */
struct pw_svc {	
	int  init;				/* Initialized? */
	char *(*PasswdCrypt)();			/* Password encryptor */
	enum svc_security SecurityLevel;	/* Security level */
	enum svc_services ServiceOrder[N_SVC];	/* Passwd lookup services */
};

/*
 * Function declaration
 */
void init_pwsvc _((int, char **));
struct pw_svc *get_pwsvc();

#endif
/* End pw_svc.h */
