/*
 *
 *	instring - check one string for occurance of another
 */

#ifndef lint
static char sccsid[] = "@(#)instring.c	1.1 08/07/96 (cc.utexas.edu)";
#endif

instring(searchin, searchfor)
	char	*searchin,		/* String to search in */
		*searchfor;		/* String to search for */
{
	int	l;

	for (l = strlen(searchfor); *searchin; searchin++) {
		if (strncmp(searchin, searchfor, l) == 0)
			return(1);
	}
	return(0);
}

instringcase(searchin, searchfor)
	char	*searchin,		/* String to search in */
		*searchfor;		/* String to search for */
{
	int	l;

	for (l = strlen(searchfor); *searchin; searchin++) {
		if (strncasecmp(searchin, searchfor, l) == 0)
			return(1);
	}
	return(0);
}
/* End instring.c */
