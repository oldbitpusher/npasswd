/*
 * Copyright 1998, The University of Texas at Austin ("U. T. Austin").
 * All rights reserved.
 *
 * By using this software the USER indicates that he or she has read,
 * understood and will comply with the following:
 *
 * U. T. Austin hereby grants USER permission to use, copy, modify, and
 * distribute this software and its documentation for any purpose and
 * without fee, provided that:
 *
 * 1. the above copyright notice appears in all copies of the software
 *    and its documentation, or portions thereof, and 
 * 2. a full copy of this notice is included with the software and its
 *    documentation, or portions thereof, and 
 * 3. neither the software nor its documentation, nor portions thereof,
 *    is sold for profit. Any commercial sale or license of this software,
 *    copies of the software, its associated documentation and/or
 *    modifications of either is strictly prohibited without the prior
 *    consent of U. T. Austin. 
 * 
 * Title to copyright to this software and its associated documentation
 * shall at all times remain with U. T. Austin. No right is granted to
 * use in advertising, publicity or otherwise any trademark, service
 * mark, or the name of U. T. Austin.
 * 
 * This software and any associated documentation are provided "as is,"
 * and U. T. AUSTIN MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR
 * IMPLIED, INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR
 * PURPOSE, OR THAT USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED
 * DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR
 * OTHER INTELLECTUAL PROPERTY RIGHTS OF A THIRD PARTY. U. T. Austin, The
 * University of Texas System, its Regents, officers, and employees shall
 * not be liable under any circumstances for any direct, indirect, special,
 * incidental, or consequential damages with respect to any claim by USER
 * or any third party on account of or arising from the use, or inability
 * to use, this software or its associated documentation, even if U. T.
 * Austin has been advised of the possibility of those damages.
 * 
 * Submit commercialization requests to: Office of the Executive Vice
 * President and Provost, U. T. Austin, 201 Main Bldg., Austin, Texas,
 * 78712, ATTN: Technology Licensing Specialist.
 */

/*
 * history_admin.c
 *	Utility to administer the password history database.
 *
 *	This is an extension of the npasswd password history routines,
 *	and shares a lot of state internal to that code.
 */
#ifndef lint
static char sccsid[] = "@(#)history_admin.c	1.6 07/17/98 (cc.utexas.edu) /usr/share/src/private/ut/share/bin/passwd/V2.0/src/PasswordCheck/SCCS/s.history_admin.c";
#endif

/*
 * System includes
 */
#include <stdio.h>
#include <ctype.h>
#include <grp.h>
/*
 * Npasswd includes
 */
#include "defines.h"
#include "compatibility.h"
#include "options.h"
#include "pwck_defines.h"
#include "pwck_history.h"

#ifdef	I_NDBM
# include <ndbm.h>
#endif

int	logging = 0;		/* Emit messages via syslog? */
int	verbose = 0;		/* User level verbose */
void	(*xdie)() = die;	/* Fatal error report routine */
				/* Either die() or logdie() in comobj.a */

/*
 * Program debug level table
 */
debug_table admin_debug[] = {
	{ "none",	DB_NONE,	"Debugging off" },
	{ "verbose",	DB_VERBOSE,	"Verbose" },
	{ "config",	DB_CONFIG,	"Configuration processing" },
	{ "detail",	DB_DETAIL,	"Detailed debugging" },
	{ "all",	DB_ALL,		"All debugging" },
	{ 0 },
};

char *Usage = "Usage: %s\n\
	[-a N]		Set password retention age to N days\n\
	[-c file]	Alternate npasswd configuration file\n\
	[-d N]		Set password retention depth to N\n\
	[-f file]	Set database path\n\
	[-l]		Log errors via syslog\n\
	[-m method]	Set database method\n\
	[-v]		Verbose mode\n\
	[-XDN]		Set debug level\n\
	[-Xh]		Help\n\
	function	What to do:\n\
		load - build history database from stdin\n\
		dump - dump history database to stdout\n\
		purge - remove dead users and old passwords\n\
";

/*
 * Function prototypes
 */
char	*filter_input _((char *));
int	file_dump _((char *));
int	file_load _((char *, FILE *));
int	file_purge _((char *));
#ifdef	I_NDBM
int	dbm_dump _((char *));
int	dbm_load _((char *, FILE *));
int	dbm_purge _((char *));
#endif

#define	ProgramName	"history_admin"

/*
 * main
 *	Main program
 */
main(argc, argv, envp)
	int	argc;
	char	**argv;
	char	**envp;
{
	int	opt;			/* Arg process temp */
	char	*function = 0,		/* What to do */
		*method = DEFAULT_METHOD, /* DB method */
		*dbfile = 0;		/* DB filename */
	char	*configfile = CONFIG_FILE; /* Npasswd configuration file */
	FILE	*cfp;			/* Control file */
	extern char	*optarg;	/* From getopt() */
	extern int	optind;		/* From getopt() */

	set_debug_tag(ProgramName); /* Tag for die() and warn() */
	/*
	 * Process command line arguments
	 */
	while ((opt = getopt(argc, argv, "a:c:d:f:lm:vX:")) != EOF) {
		switch (opt) {
		case 'a':	/* -a password-age */
			HistoryAge = atoi(optarg) * SEC_DAY;
			break;
		case 'c':	/* -c config-file */
			configfile = optarg;
			break;
		case 'd':	/* -d password-depth */
			HistoryDepth = atoi(optarg);
			break;
		case 'f':	/* -f history-file */
			dbfile = optarg;
			break;
		case 'l':	/* -l (logging) */
			logging = 1;
			break;
		case 'm':	/* -m history-method */
			method = optarg;
			break;
		case 'v':	/* -v (verbose) */
			verbose = 1;
			break;
		case 'X':
			switch (*optarg) {
			case 'D':
				set_debug(++optarg, admin_debug);
				break;
			case 'h': {
				debug_table *dt = admin_debug;

				printf(Usage, argv[0]);
				printf("Debug levels (-XD...):\n");
				for (; dt->name; dt++)
					printf(" %s\t%s\n", dt->name, dt->help);
				return(0);
				}
			}
		}
	}
	/*
	 * Drop syslog messages on fatal errors?
	 */
	if (logging) {
		xdie = logdie;
		openlog(ProgramName, LOG_PID, LOG_AUTH);
	}

	/*
	 * Get & verify function argument
	 */
	if (function == 0)
		function = argv[optind++];
	if (function == 0) {
		debug_table *dt = admin_debug;

		printf(Usage, argv[0]);
		printf("Debug levels (-XD...):\n");
		for (; dt->name; dt++)
			printf(" %s\t%s\n", dt->name, dt->help);
		return(1);
	}

	/*
	 * Read npasswd configuration and pick out history directives
	 */
	if (cfp = fopen(configfile, "r")) {
		char    ibuf[BUFSIZ];
		int	cfline = 0;

		while (fgets(ibuf, BUFSIZ, cfp)) {
			char	**cfv,
				*error;

			cfline++;
			chop_nl(ibuf);
			if (ibuf[0] == '#' || ibuf[0] == '\0')
				continue;
			if ((cfv = split(ibuf, 0, 0, '#')) == 0)
				continue;
			if (strcasecmp(cfv[0], "passwd.history")) {
				free((char *)cfv);
				continue;
			}
			if (error = pwck_history_configure(&cfv[1])) {
				(*xdie)("Config file error '%s' line %d; %s\n",
					configfile, ibuf, error);
			}
			free((char *)cfv);
		}
		(void) fclose(cfp);
	}
	/*
	 * Database path set on command line?
	 */
	if (dbfile) {
		char	*tmp[4];
		char	*error;

		tmp[0] = "database";
		tmp[1] = method;
		tmp[2] = dbfile;
		tmp[3] = 0;
		if (error = pwck_history_configure(tmp))
			(*xdie)(
			"Database error: file '%s' method '%s' error '%s'\n",
				dbfile, method, error);
	}

	if (get_debug()) {
		printf("History database = \"%s\"\n", HistoryDB);
		printf("History method = %s\n", HistoryMethod);
		printf("History depth = %d\n", HistoryDepth);
		printf("History age = %d days\n", HistoryAge / SEC_DAY);
	}

#define	Method_File	(strcmp(HistoryMethod, "file") == 0)
#define	Method_DBM	(strcmp(HistoryMethod, "dbm") == 0)

	/*
	 * Function 'dump' - Spew raw history to stdout
	 */
	if (instringcase(function, "dump")) {
		if (HistoryDB == 0)
			(*xdie)("No history database\n");
		if (Method_File)
			return(file_dump(HistoryDB));
#ifdef	I_NDBM
		if (Method_DBM)
			return(dbm_dump(HistoryDB));
#endif
		return(2);
	}
	/*
	 * Function 'load' - build history from stdin data
	 */
	if (instringcase(function, "load")) {
		if (HistoryDB == 0)
			(*xdie)("No history database\n");
		if (Method_File)
			return(file_load(HistoryDB, stdin));
#ifdef	I_NDBM
		if (Method_DBM)
			return(dbm_load(HistoryDB, stdin));
#endif
		return(2);
	}
	/*
	 * Function 'purge' - Clean up history
	 */
	if (instringcase(function, "purge")) {
		if (HistoryDB == 0)
			(*xdie)("No history database\n");
		if (Method_File)
			return(file_purge(HistoryDB));
#ifdef	I_NDBM
		if (Method_DBM)
			return(dbm_purge(HistoryDB));
#endif
		return(2);
	}
	/*
	 * Unknown function
	 */
	(*die)("Unknown function '%s'\n", function);
	/*NOTREACHED*/
}
#undef	Method_File
#undef	Method_DBM

/*
 * filter_input
 *	Verify history line
 *
 * Usage
 *	ptr = filter_input(string);
 * Return
 *	pointer to first non-whitespace character of <string>
 *	NULL if line is empty, a comment or malformed
 */
char *filter_input(str)
	char	*str;	/*ARGSUSED*/
{
	if (*str == '\n' || *str == '#')
		return(0);
	while (*str && isspace(*str))
		str++;
	if (*str)
		return(str);
	return(0);
}

/*
 * Routines for manipulating flat file history databases
 */

/*
 * Awk scirpt to spew the last history line for each user
 */
#define	FileIncantation \
"/bin/awk 'BEGIN {FS = \":\"} {u[$1] = $0} END {for (f in u) {print u[f]}}'"

/*
 * file_purge
 *	Clean a flat file history datbase
 *
 * Returns
 *	0 on success
 *	1 on failure
 */
file_purge(file)
	char *file;			/* History file */
{
	FILE	*file_in,		/* Input stream */
		*file_out;		/* Output stream */
	char	tempfile[MAXPATHLEN],	/* Temp history file */
		savefile[MAXPATHLEN],	/* Saved history file */
		buf[HISTORY_RECLEN];	/* Read buffer */
	int	errors = 0,		/* Error count */
		how_many = 0,		/* Record count */
		deleted = 0,		/* Deleted record count */
		t;			/* Temp */
	struct stat	stb;		/* History file stat */

	if (access(file, 0) < 0) {
		if (verbose)
			warn("No history file\n");
		return(1);
	}
	/*
	 * Invoke history file filter
	 */
	(void) sprintf(buf, "%s %s", FileIncantation, file);
	if ((file_in = popen(buf, "r")) == NULL) {
		if (verbose)
			warn("Filter popen failed\n");
		return(1);
	}
	/*
	 * Construct temporary and save file names
	 */
	(void) strcpy(tempfile, file);
	(void) strcat(tempfile, ".temp");
	(void) strcpy(savefile, file);
	(void) strcat(savefile, ".old");
	/*
	 * Create the temp file
	 */
	if ((t = MakeLockTemp(tempfile)) < 0) {
		(*xdie)("Cannot make temp file '%s', error %d\n",
			tempfile, errno);
	}
	file_out = fdopen(t, "w");		/* Get stdio pointer */

	debug(DB_VERBOSE, "purge_file: file '%s'\ntemp '%s'\nsave '%s'\n",
		file, tempfile, savefile);

	/*
 	 * Give temp file ownership and mode of the original
	 */
	(void) stat(file, &stb);
	if (chown(tempfile, stb.st_uid, stb.st_gid) < 0) {
		perror("History temp chown");
		errors++;
	}
        if (chmod(tempfile, stb.st_mode) < 0) {
		perror("History temp chmod");
		errors++;
	}

	while (fgets(buf, sizeof(buf), file_in)) {
		char	*c,		/* Temp */
			*t;		/* Temp */
		char	name[16];	/* User name temp */

		how_many++;
		c = strchr(buf, ENTRY_SEP);
		*c++ = 0;
		(void) strcpy(name, buf);
		/*
		 * What about alternate passwd maps/files?
		 */
		if (getpwnam(name) == 0) {
			if (verbose)
				printf("User '%s' removed\n", name);
			deleted++;
			continue;
		}
		t = clean_history(c, HistoryDepth, HistoryAge, 0, 0);
		debug(DB_VERBOSE, "Purge: new <%s%c%s>\n", name, ENTRY_SEP, t);
		(void) fprintf(file_out, "%s%c%s\n", name, ENTRY_SEP, t);
	}
	(void) fclose(file_in);
	(void) fclose(file_out);

	/*
	 * Install temp file as history file
	 */
	if (errors) {
		warn("History purge errors - new database left in '%s'\n",
			tempfile);
		return(1);
	}
	(void) unlink(savefile);
	if (rename(file, savefile) < 0) {	/* Move current to save */
		int xerrno = errno;

		perror("History file save failure");
		if (logging)
			logerr("History file save failure %d", xerrno);
		(void) unlink(tempfile);
		return(1);
	}
	if (rename(tempfile, file) < 0) {	/* Move new to current */
		int xerrno = errno;

		perror("History file temp rename failure");
		if (logging)
			logerr("History file temp rename failure %d", xerrno);
		(void) unlink(tempfile);
		(void) unlink(file);
		if (rename(savefile, file) < 0) {
			int xerrno = errno;
		
			perror("Saved history file putback failure");
			if (logging)
				logerr("Saved history file putback failure %d",
					xerrno);
		}
		return(1);
	}
	/*
	 * Success - confirm and finish
 	 */
	if (logging)
		syslog(LOG_INFO,
			"Password history purge: %d records %d deletions",
			how_many, deleted);
	if (verbose)
		printf("Password history purge: %d records %d deletions\n",
			how_many, deleted);
	return(0);
}

/*
 * file_dump
 *	Dump a flat file history database to standard output
 *	Entries are not run through clean_history()
 *
 * Returns
 *	0 on success
 *	1 on failure
 */
file_dump(file)
	char *file;		/* History file */
{
	FILE	*in;		/* Input stream */
	char	buf[HISTORY_RECLEN]; /* Read buffer */

	if (access(file, 0) < 0) {
		if (verbose)
			warn("No history file\n");
		return(1);
	}
	(void) sprintf(buf, "%s %s", FileIncantation, file);
	if ((in = popen(buf, "r")) == NULL) {
		if (verbose)
			warn("Filter popen failed\n");
		return(1);
	}
	while (fgets(buf, sizeof(buf), in)) {
		printf("%s", buf);
	}
	(void) fclose(in);
	return(0);
}

/*
 * file_load
 *	Build history database file from stdin data
 *
 * Returns
 *	0 on success
 *	1 on failure
 */
file_load(file, input)
	char	*file;			/* History file */
	FILE	*input;			/* Input stream */
{
	FILE	*file_out;		/* Output stream */
	char	tempfile[MAXPATHLEN],	/* Temp history file */
		savefile[MAXPATHLEN],	/* Saved history file */
		buf[HISTORY_RECLEN];	/* Read buffer */
	int	errors = 0,		/* Error count */
		how_many = 0,		/* Record count */
		new_file = 0,		/* Making new history file? */
		t;			/* Temp */
	struct stat	stb;		/* History file stat */

	/*
	 * Construct temporary file name
	 */
	(void) strcpy(tempfile, file);
	(void) strcat(tempfile, ".temp");

	/*
 	 * Give temp file ownership of the original (if present)
	 */
	if (stat(file, &stb) < 0) {
		new_file = 1;
		(void) strcpy(tempfile, file);
	}

	if ((t = MakeLockTemp(tempfile)) < 0) {
		(*xdie)("Cannot make temp file '%s', error %d\n",
			tempfile, errno);
	}

	if (new_file == 0) {
		if (chown(tempfile, stb.st_uid, stb.st_gid) < 0) {
			perror("History temp chown");
			errors++;
		}
		if (chmod(tempfile, stb.st_mode) < 0) {
			perror("History temp chmod");
			errors++;
		}
	}

	file_out = fdopen(t, "w");		/* Get stdio pointer */
	/*
	 * Read history lines from stdin and pack into the database
	 */
	while (fgets(buf, sizeof(buf), input)) {
		char	*c,		/* Temp */
			*t;		/* Temp */
		char	name[16];	/* Temp */

		chop_nl(buf);

		if ((t = filter_input(buf)) == 0)
			continue;
		if ((c = strchr(t, ENTRY_SEP)) == 0)
			continue;
		*c++ = 0;
		(void) strcpy(name, t);
		t = clean_history(c, 0, 0, 0, 0);
		(void) fprintf(file_out, "%s%c%s\n", name, ENTRY_SEP, t);
		how_many++;
	}
	(void) fclose(file_out);

	if (errors) {
		warn("History load errors - new database left as '%s'\n",
			tempfile);
		return(1);
	}
	if (new_file == 0) {
		/*
		 * Install temp file as history file
		 */
		(void) strcpy(savefile, file);
		(void) strcat(savefile, ".old");
	
		(void) unlink(savefile);
		if (rename(file, savefile) < 0) { /* Move current to save */
			int xerrno = errno;
	
			perror("History file save failure");
			if (logging)
				logerr("History file save failure %d", xerrno);
			(void) unlink(tempfile);
			return(1);
		}
		if (rename(tempfile, file) < 0) { /* Move new to current */
			int xerrno = errno;
	
			perror("History file temp rename failure");
			if (logging)
				logerr("History file temp rename failure %d", xerrno);
			(void) unlink(tempfile);
			(void) unlink(file);
			if (rename(savefile, file) < 0) {
				int xerrno = errno;
			
				perror("Saved history file putback failure");
				if (logging)
					logerr("Saved history file putback failure %d",
						xerrno);
			}
			return(1);
		}
	}
	/*
	 * Success - confirm and finish
 	 */
	if (logging)
		syslog(LOG_INFO, "Load password history to file '%s': %d records",
			file, how_many);
	if (verbose)
		printf("Loaded %d records to password history file '%s'\n",
			how_many, file);
	return(0);
}

/*
 * Routines for manipulating DBM history databases
 */

#ifdef	I_NDBM
/* 
 * dbm_purge
 *	Cleanup DBM history database
 *
 * Returns
 *	0 on success
 *	1 on failure
 */
dbm_purge(file)
	char *file;			/* History DBM file */
{
	DBM	*hdb;		/* Database pointer */
	datum	hkey;		/* DBM lookup datum */
	int	how_many = 0,	/* Entry counter */
		deleted = 0;	/* Deletion counter */

	/*
	 * Open database
	 */
	if ((hdb = dbm_open(file, O_RDWR, 0)) == 0) {
		perror("Cannot open history DBM\n");
		if (logging)
			logerr("Cannot open DBM history database");
		return(1);
	}
	/*
	 * Step through the keys in the database
	 */
	for (hkey = dbm_firstkey(hdb); hkey.dptr != NULL; hkey = dbm_nextkey(hdb)) {
		datum	hdata;		/* Data lookup temp */
		char    *new,		/* New entry temp */
			*key,		/* Key lookup temp */
			*data;		/* Data temp */

		how_many++;
		if ((key = malloc(hkey.dsize + 1)) == NULL)
			(*xdie)("No memory for DBM key copy\n");
		(void) strncpy(key, hkey.dptr, hkey.dsize);
		key[hkey.dsize] = 0;

		/*
		 * Is this user in the password file?
		 */
		if (getpwnam(key) == NULL) {
			if (verbose)
				printf("User %s not in passwd file\n", key);
			(void) dbm_delete(hdb, hkey);
			continue;
		}

		hdata = dbm_fetch(hdb, hkey);
		if ((data = malloc(hdata.dsize + 1)) == NULL)
			(*xdie)("No memory for DBM key copy\n");
		(void) strncpy(data, hdata.dptr, hdata.dsize);
		data[hdata.dsize] = 0;

		new = clean_history(data, HistoryDepth, HistoryAge, 0, 0);
		hdata.dptr = new;
		hdata.dsize = strlen(new);
		if (dbm_store(hdb, hkey, hdata, DBM_REPLACE) < 0) {
			warn("DBM replace for '%s' failed", key);
			if (logging)
				logerr("DBM replace for '%s' failed", key);
			dbm_close(hdb);
			return(1);
		}
		free(key);
		free(data);
	}
	dbm_close(hdb);
	return(0);
}

/* 
 * dbm_dump
 *	Dump DBM history database to stdout
 *
 * Returns
 *	0 on success
 *	1 on failure
 */
dbm_dump(file)
	char *file;		/* History DBM */
{
	DBM	*hdb;		/* Database pointer */
	datum	hkey;		/* DBM lookup datum */

	/*
	 * Open database
	 */
	if ((hdb = dbm_open(file, O_RDONLY, 0)) == 0) {
		if (logging)
			logerr("Cannot open DBM history database");
		return(1);
	}
	/*
	 * Step through the keys in the database
	 */
	for (hkey = dbm_firstkey(hdb); hkey.dptr != NULL; hkey = dbm_nextkey(hdb)) {
		datum	hdata;
		char	*name,
			*data;

		hdata = dbm_fetch(hdb, hkey);

		if ((name = malloc(hkey.dsize + 1)) == NULL)
			(*xdie)("No memory for DBM key copy\n");
		(void) strncpy(name, hkey.dptr, hkey.dsize);
		name[hkey.dsize] = 0;

		if ((data = malloc(hdata.dsize + 1)) == NULL)
			(*xdie)("No memory for DBM key copy\n");
		(void) strncpy(data, hdata.dptr, hdata.dsize);
		data[hdata.dsize] = 0;

		printf("%s%c%s\n", name, ENTRY_SEP, data);
		free(data);
		free(name);
	}
	dbm_close(hdb);
	return(0);
}

/* 
 * dbm_load
 *	Build history database DBM from stdin data
 *
 * Returns
 *	0 on success
 *	1 on failure
 */
dbm_load(file, input)
	char	*file;		/* History DBM file */
	FILE	*input;		/* Input stream */
{
	DBM	*hdb;			/* Database pointer */
	char	file_pag[MAXPATHLEN],	/* Database .pag file */
		file_dir[MAXPATHLEN],	/* Database .dir file */
		temp_pag[MAXPATHLEN],	/* Temp file .pag file */
		temp_dir[MAXPATHLEN],	/* Temp file .dir file */
		temp_file[MAXPATHLEN];	/* Temp file */
	char	inbuf[HISTORY_RECLEN];	/* Read buffer */
	int	new_file = 0;		/* Making new file */
	int	errors = 0;		/* Error count */
	int	how_many = 0;		/* Count of records loaded */
	struct stat stb;		/* Stat buffer */

#define	db_files(_d_,_p_,_n_) \
	(void) strcpy(_d_, _n_); (void) strcat(_d_, ".dir"); \
	(void) strcpy(_p_, _n_); (void) strcat(_p_, ".pag");

	db_files(file_dir, file_pag, file);	/* Make history DB names */

	/*
	 * Database exists?
 	 */
	if (stat(file_dir, &stb) < 0) {
		(void) strcpy(temp_file, file);
		new_file = 1;
	} else {
		(void) strcpy(temp_file, file);
		(void) strcat(temp_file, "-temp");
	}
	db_files(temp_dir, temp_pag, temp_file);	/* Make temp DB names */

	/*
	 * Open database read-write
	 */
	if ((hdb = dbm_open(temp_file, O_RDWR|O_CREAT, HISTORYDB_MODE)) == 0) {
		perror("Cannot open DBM");
		(*xdie)("Cannot make DBM '%s'\n", temp_file);
		return(1);
	}
	if (new_file == 0) {
		/*
		 * Give temp files same owner and mode as existing
		 */
		if (chown(temp_dir, stb.st_uid, stb.st_gid) < 0) {
			perror("Chown DBM dir");
			errors++;
		}
		if (chmod(temp_dir, stb.st_mode) < 0) {
			perror("Chmod DBM dir");
			errors++;
		}
		if (chown(temp_pag, stb.st_uid, stb.st_gid) < 0) {
			perror("Chown DBM pag");
			errors++;
		}
		if (chmod(temp_pag, stb.st_mode) < 0) {
			perror("Chmod DBM pag");
			errors++;
		}
	}
	/*
	 * Read history lines from stdin and pack into the database
	 */
	while (fgets(inbuf, sizeof(inbuf), input)) {
		datum	hkey,		/* DBM key */
			hdata;		/* DBM data */
		char	name[16];	/* Temp */
		char	*c,		/* Temp */
			*n,		/* Temp */
			*t;		/* Temp */

		chop_nl(inbuf);

		if ((t = filter_input(inbuf)) == 0)
			continue;

		if ((c = strchr(t, ENTRY_SEP)) == 0)
			continue;
		*c++ = 0;
		n = clean_history(c, 0, 0, 0, 0);

		hkey.dptr = t;
		hkey.dsize = strlen(t);

		hdata.dptr = n;
		hdata.dsize = strlen(n);

		/*
		 * Store new data
		 */
		if (dbm_store(hdb, hkey, hdata, DBM_REPLACE) < 0) {
				warn("DBM store failed\nHistory load errors - new database left as '%s'\n",
					temp_file);
				dbm_close(hdb);
				return(1);
			}
			how_many++;
		}
		dbm_close(hdb);

		/*
		 * Install temp file
		 */
		if (new_file == 0) {
			char	save_dir[MAXPATHLEN],	/* Save .dir file */
				save_pag[MAXPATHLEN],	/* Save .pag file */
				save_file[MAXPATHLEN];	/* Save file */

			(void) strcpy(save_file, file);
			(void) strcat(save_file, "-old");
			db_files(save_dir, save_pag, save_file);

			/*
			 * Save existing file
			 */
			if (rename(file_dir, save_dir) < 0) {
				perror("Save .dir file failure");
				errors++;
			}
			if (rename(file_pag, save_pag) < 0) {
				perror("Save .pag file failure");
				errors++;
			}

			/*
			 * Install temp file
			 */
			if (rename(temp_dir, file_dir) < 0) {
				perror("History .dir rename failure");
				errors++;
				if (rename(save_dir, file_dir) < 0)
					perror("Putback .dir failure");
			}
			if (rename(temp_pag, file_pag) < 0) {
				perror("History .pag rename failure");
				errors++;
				if (rename(save_pag, file_pag) < 0)
					perror("Putback .pag failure");
			}
			if (errors) {
				warn("History load errors - new database left as '%s'\n", temp_file);
			return(1);
		}
	}
	/*
	 * Success - confirm and finish
 	 */
	if (logging)
		syslog(LOG_INFO, "Password history load to DBM '%s': %d records",
			file, how_many);
	if (verbose)
		printf("Loaded %d records to password history DBM '%s'\n",
			how_many, file);
	return(0);
#undef	db_files
}
#endif	/* I_NDBM */

/* End history_admin.c */
