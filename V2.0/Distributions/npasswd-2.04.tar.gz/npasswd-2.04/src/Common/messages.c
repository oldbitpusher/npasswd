/*
 * Message routines used by npasswd and checkpasswd
 */
#ifndef lint
static char sccsid[] = "@(#)messages.c	1.8 07/09/98 (cc.utexas.edu) /usr/share/src/private/ut/share/bin/passwd/V2.0/src/Common/SCCS/s.messages.c";
#endif

#define	_messages_c
#include "defines.h"
#include "constants.h"
#include "compatibility.h"
#include "common.h"

private	int DebugLevel = DB_NONE;
private	char *DebugTag = "passwd";

/*
 * get_debug
 *	Fetch the debug level
 */
public
get_debug()
{
	return(DebugLevel);
}

/*
 * init_debug
 *	Initialize debug level
 */
public void
init_debug(level)
	int level;		/* Binary value (DB_xxxx) */
{
	DebugLevel = level;
}

/*
 * set_debug
 *	Decode symbolic value and set debug level
 */
public void
set_debug(arg, dtab)
	char		*arg;	/* Debug level string */
	debug_table	*dtab;	/* Debug table */
{
	if (isdigit(*arg)) {
		DebugLevel = atoi(arg);
		return;
	}
	if (dtab == 0)
		return;
	for (; dtab->name; dtab++) {
		if (strcasecmp(dtab->name, arg) == 0) {
			DebugLevel = dtab->level;
			return;
		}
	}
}

/*
 * set_debug_title
 *	Set program name tag for debugging and error messages
 */
public void
set_debug_tag(title)
	char *title;
{
	if (title)
		DebugTag = title;
	else
		DebugTag = "";
}

/*
 * debug - print debug message (contingent upon debugging level)
 */
public void
#ifdef	__STDC__
debug (int level, char *fmt, ...)
{
	va_list	args;

	if (DebugLevel < level)
		return;
	va_start(args, fmt);
	vprintf(fmt, args);
	fflush(stdout);
	va_end(args);
}
#else	/* __STDC__ */
debug (va_alist)
va_dcl
{
	va_list	args;
	int	level;
	char	*fmt;

	va_start(args);
	level = va_arg(args, int);
	fmt = va_arg(args, char *);
	if (DebugLevel >= level) {
		vprintf(fmt, args);
		fflush(stdout);
	}
	va_end(args);
}
#endif

/*
 * die - spew error and die
 */
private void (*DieCallBack)() = 0;

public void
set_die_callback(rtn)
	void (*rtn)();
{
	DieCallBack = rtn;
}

public void
die VA_DCL(char *msgs)
{
	va_list	args;
#ifdef	__STDC__
	fprintf(stderr, "%s: ", DebugTag);
	va_start(args, msgs);
	vfprintf(stderr, msgs, args);
#else	/* __STDC__ */
	char	*fmt;

	va_start(args);
	fprintf(stderr, "%s: ", DebugTag);
	fmt = va_arg(args, char *);
	vfprintf(stderr, fmt, args);
#endif	/* __STDC__ */
	va_end(args);
	fflush(stderr);
	if (DieCallBack)
		(*DieCallBack)(-1);
	exit(1);
}

/*
 * warn - spew error
 */
public void
warn VA_DCL(char *msgs)
{

	va_list	args;
#ifdef	__STDC__
	fprintf(stderr, "%s: ", DebugTag);
	va_start(args, msgs);
	vfprintf(stderr, msgs, args);
#else	/* __STDC__ */
	char	*fmt;

	va_start(args);
	fprintf(stderr, "%s: ", DebugTag);
	fmt = va_arg(args, char *);
	vfprintf(stderr, fmt, args);
#endif	/* __STDC__ */
	va_end(args);
	fflush(stderr);
}

/*
 * logdie - spew error, log message and die
 */
public void
logdie VA_DCL(char *msgs)
{
	va_list	args;
	char	*fmt;
	char	msgbuf[TMPBUFSIZ];

	VA_START(args, msgs);
#ifdef	__STDC__
	vsprintf(msgbuf, msgs, args);
#else	/* __STDC__ */
	fmt = va_arg(args, char *);
	vsprintf(msgbuf, fmt, args);
#endif	/* __STDC__ */
	va_end(args);
	fprintf(stderr, "%s: %s\n", DebugTag, msgbuf);
	fflush(stderr);
	syslog(LOG_ERR, msgbuf);
	if (DieCallBack)
		(*DieCallBack)(-1);
	exit(1);
}

/*
 * log_error - spew error and log message
 */
public void
logerr VA_DCL(char *msgs)
{
	va_list	args;
	char	*fmt;
	char	msgbuf[TMPBUFSIZ];

	VA_START(args, msgs);
#ifdef	__STDC__
	vsprintf(msgbuf, msgs, args);
#else	/* __STDC__ */
	fmt = va_arg(args, char *);
	vsprintf(msgbuf, fmt, args);
#endif	/* __STDC__ */
	va_end(args);
	syslog(LOG_ERR, msgbuf);
}
/* End messages.c */
