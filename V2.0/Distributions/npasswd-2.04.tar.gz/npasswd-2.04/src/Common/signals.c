/*
 * npasswd module signals.c
 *
 * Compliation: cc -c signals.c
 * Includes: npasswd.h
 */

#define	_signals_c
#include "npasswd.h"

#ifndef lint
static char sccsid[] = "@(#)signals.c	1.4 04/30/98 (cc.utexas.edu) /usr/share/src/private/ut/share/bin/passwd/V2.0/src/Common/SCCS/s.signals.c";
#endif

/*
 * Signal block/unblock routines.
 */
public void
block_signals VA_DCL(struct sigblk *args)
{
	va_list	fargs;
	struct sigblk *sigblk;
	int	xsig;

	VA_START(fargs, args);
#ifdef	__STDC__
	sigblk = args;
#else
	sigblk = va_arg(fargs, struct sigblk *);
#endif

#if	(SIG_TYPE == SIG_TYPE_POSIX)
	sigemptyset(&sigblk->savesigs);
	while (xsig = va_arg(fargs, int)) {
		sigaddset(&sigblk->savesigs, xsig);
	}
	sigprocmask(SIG_BLOCK, &sigblk->savesigs, &sigblk->sigvalues);
#endif

#if	(SIG_TYPE == SIG_TYPE_BSD)
	sigblk->savesigs = 0;
	while (xsig = va_arg(fargs, int)) {
		sigblk->savesigs |= sigmask(xsig);
	}
	sigblk->sigvalues = sigblock(sigblk->savesigs);
#endif

#if	(SIG_TYPE == SIG_TYPE_UNIX)
	while (xsig = va_arg(fargs, int)) {
		sigblk->sigvalues[xsig] = signal(xsig, SIG_IGN);
	}
#endif
}

public void
unblock_signals(sigblk)
	struct sigblk *sigblk;
{
#if	(SIG_TYPE == SIG_TYPE_POSIX)
	sigprocmask(SIG_UNBLOCK, &sigblk->savesigs, (sigset_t *)0);
	return;
#endif
#if	(SIG_TYPE == SIG_TYPE_BSD)
	sigsetmask(&sigblk->sigvalues);
#endif
#if	(SIG_TYPE == SIG_TYPE_UNIX)
	int	i;
	
	for (i = 0; i <= NSIG; i++) {
		if (sigblk->sigvalues[i])
			(void) signal(i, sigblk->sigvalues[i]);
	}
#endif
}

/* End signals.c */
